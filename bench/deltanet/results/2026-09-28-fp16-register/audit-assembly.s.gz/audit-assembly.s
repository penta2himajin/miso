	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx906"
	.protected	volatile_step           ; -- Begin function volatile_step
	.globl	volatile_step
	.p2align	8
	.type	volatile_step,@function
volatile_step:                          ; @volatile_step
; %bb.0:
	s_add_u32 flat_scratch_lo, s6, s9
	s_addc_u32 flat_scratch_hi, s7, 0
	s_add_u32 s0, s0, s9
	s_addc_u32 s1, s1, 0
	s_cmp_gt_u32 s8, 31
	s_cbranch_scc1 .LBB0_25
; %bb.1:
	s_movk_i32 s6, 0x7f
	v_and_b32_e32 v2, 63, v0
	v_and_b32_e32 v17, 0x7f, v0
	v_lshrrev_b32_e32 v1, 7, v0
	v_cmp_lt_u32_e64 s[14:15], s6, v0
	v_cmp_eq_u32_e64 s[6:7], 63, v2
	v_lshrrev_b32_e32 v2, 4, v0
	v_mov_b32_e32 v3, 0xa00
	s_load_dwordx16 s[16:31], s[4:5], 0x0
	s_load_dwordx4 s[36:39], s[4:5], 0x40
	s_load_dwordx2 s[34:35], s[4:5], 0x50
	s_load_dword s33, s[4:5], 0x60
	s_load_dwordx2 s[40:41], s[4:5], 0x68
	v_lshlrev_b32_e32 v18, 2, v17
	v_and_or_b32 v20, v2, 12, v3
	v_lshlrev_b32_e32 v2, 13, v1
	v_rsq_f32_e32 v92, 0x43000000
	s_movk_i32 s10, 0x80
	v_lshlrev_b32_e32 v19, 2, v0
	v_lshl_or_b32 v21, v1, 9, v18
	v_or_b32_e32 v3, v2, v17
	v_lshlrev_b32_e32 v1, 8, v1
	v_or_b32_e32 v2, v2, v0
	s_add_u32 s4, s4, 0x70
	v_or_b32_e32 v4, 0x80, v2
	v_or_b32_e32 v5, 0x180, v2
	v_or_b32_e32 v6, 0x280, v2
	v_or_b32_e32 v7, 0x380, v2
	v_or_b32_e32 v10, 0x480, v2
	v_or_b32_e32 v11, 0x580, v2
	v_or_b32_e32 v12, 0x680, v2
	v_or_b32_e32 v13, 0x780, v2
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v9, s39
	v_add_co_u32_e32 v8, vcc, s38, v19
	v_or_b32_e32 v14, 0x880, v2
	v_or_b32_e32 v15, 0x980, v2
	v_or_b32_e32 v16, 0xa80, v2
	v_or_b32_e32 v47, 0xb80, v2
	v_or_b32_e32 v49, 0xc80, v2
	v_or_b32_e32 v51, 0xd80, v2
	v_or_b32_e32 v53, 0xe80, v2
	v_or_b32_e32 v55, 0xf80, v2
	v_or_b32_e32 v57, 0x1080, v2
	v_or_b32_e32 v59, 0x1180, v2
	v_or_b32_e32 v61, 0x1280, v2
	v_or_b32_e32 v63, 0x1380, v2
	v_or_b32_e32 v65, 0x1480, v2
	v_or_b32_e32 v67, 0x1580, v2
	v_or_b32_e32 v69, 0x1680, v2
	v_or_b32_e32 v71, 0x1780, v2
	v_or_b32_e32 v73, 0x1880, v2
	v_or_b32_e32 v75, 0x1980, v2
	v_or_b32_e32 v77, 0x1a80, v2
	v_or_b32_e32 v79, 0x1b80, v2
	v_or_b32_e32 v81, 0x1c80, v2
	v_or_b32_e32 v83, 0x1d80, v2
	v_or_b32_e32 v85, 0x1e80, v2
	v_or_b32_e32 v2, 0x1f80, v2
	v_or_b32_e32 v22, 0x400, v1
	v_or_b32_e32 v23, 0x600, v1
	s_mov_b64 s[38:39], src_private_base
	v_or_b32_e32 v1, 0x100, v3
	v_or_b32_e32 v28, 0x200, v3
	v_or_b32_e32 v30, 0x300, v3
	v_or_b32_e32 v32, 0x400, v3
	v_or_b32_e32 v34, 0x500, v3
	v_or_b32_e32 v36, 0x600, v3
	v_or_b32_e32 v38, 0x700, v3
	v_or_b32_e32 v40, 0x800, v3
	v_or_b32_e32 v42, 0x900, v3
	v_or_b32_e32 v44, 0xa00, v3
	v_or_b32_e32 v46, 0xb00, v3
	v_or_b32_e32 v48, 0xc00, v3
	v_or_b32_e32 v50, 0xd00, v3
	v_or_b32_e32 v52, 0xe00, v3
	v_or_b32_e32 v54, 0xf00, v3
	v_or_b32_e32 v56, 0x1000, v3
	v_or_b32_e32 v58, 0x1100, v3
	v_or_b32_e32 v60, 0x1200, v3
	v_or_b32_e32 v62, 0x1300, v3
	v_or_b32_e32 v64, 0x1400, v3
	v_or_b32_e32 v66, 0x1500, v3
	v_or_b32_e32 v68, 0x1600, v3
	v_or_b32_e32 v70, 0x1700, v3
	v_or_b32_e32 v72, 0x1800, v3
	v_or_b32_e32 v74, 0x1900, v3
	v_or_b32_e32 v76, 0x1a00, v3
	v_or_b32_e32 v78, 0x1b00, v3
	v_or_b32_e32 v80, 0x1c00, v3
	v_or_b32_e32 v82, 0x1d00, v3
	v_or_b32_e32 v84, 0x1e00, v3
	v_or_b32_e32 v86, 0x1f00, v3
	v_or_b32_e32 v88, 0x400, v18
	v_add_u32_e32 v89, 0x600, v19
	v_cmp_gt_u32_e64 s[10:11], s10, v0
	s_addc_u32 s5, s5, 0
	s_mov_b32 s9, 0
	v_addc_co_u32_e32 v9, vcc, 0, v9, vcc
	s_mov_b32 s38, 4
	s_mov_b32 s44, 0x800000
	s_mov_b32 s45, 0x41a00000
	s_mov_b32 s46, 0x3f2aaaab
	s_mov_b32 s47, 0x3f317218
	s_mov_b32 s48, 0x7f800000
	s_mov_b32 s49, 0x33800000
	v_lshlrev_b32_e32 v24, 2, v3
	v_lshlrev_b32_e32 v25, 2, v4
	v_lshlrev_b32_e32 v26, 2, v1
	v_lshlrev_b32_e32 v27, 2, v5
	v_lshlrev_b32_e32 v28, 2, v28
	v_lshlrev_b32_e32 v29, 2, v6
	v_lshlrev_b32_e32 v30, 2, v30
	v_lshlrev_b32_e32 v31, 2, v7
	v_lshlrev_b32_e32 v32, 2, v32
	v_lshlrev_b32_e32 v33, 2, v10
	v_lshlrev_b32_e32 v34, 2, v34
	v_lshlrev_b32_e32 v35, 2, v11
	v_lshlrev_b32_e32 v36, 2, v36
	v_lshlrev_b32_e32 v37, 2, v12
	v_lshlrev_b32_e32 v38, 2, v38
	v_lshlrev_b32_e32 v39, 2, v13
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v41, 2, v14
	v_lshlrev_b32_e32 v42, 2, v42
	v_lshlrev_b32_e32 v43, 2, v15
	v_lshlrev_b32_e32 v44, 2, v44
	v_lshlrev_b32_e32 v45, 2, v16
	v_lshlrev_b32_e32 v46, 2, v46
	v_lshlrev_b32_e32 v47, 2, v47
	v_lshlrev_b32_e32 v48, 2, v48
	v_lshlrev_b32_e32 v49, 2, v49
	v_lshlrev_b32_e32 v50, 2, v50
	v_lshlrev_b32_e32 v51, 2, v51
	v_lshlrev_b32_e32 v52, 2, v52
	v_lshlrev_b32_e32 v53, 2, v53
	v_lshlrev_b32_e32 v54, 2, v54
	v_lshlrev_b32_e32 v55, 2, v55
	v_lshlrev_b32_e32 v56, 2, v56
	v_lshlrev_b32_e32 v57, 2, v57
	v_lshlrev_b32_e32 v58, 2, v58
	v_lshlrev_b32_e32 v59, 2, v59
	v_lshlrev_b32_e32 v60, 2, v60
	v_lshlrev_b32_e32 v61, 2, v61
	v_lshlrev_b32_e32 v62, 2, v62
	v_lshlrev_b32_e32 v63, 2, v63
	v_lshlrev_b32_e32 v64, 2, v64
	v_lshlrev_b32_e32 v65, 2, v65
	v_lshlrev_b32_e32 v66, 2, v66
	v_lshlrev_b32_e32 v67, 2, v67
	v_lshlrev_b32_e32 v68, 2, v68
	v_lshlrev_b32_e32 v69, 2, v69
	v_lshlrev_b32_e32 v70, 2, v70
	v_lshlrev_b32_e32 v71, 2, v71
	v_lshlrev_b32_e32 v72, 2, v72
	v_lshlrev_b32_e32 v73, 2, v73
	v_lshlrev_b32_e32 v74, 2, v74
	v_lshlrev_b32_e32 v75, 2, v75
	v_lshlrev_b32_e32 v76, 2, v76
	v_lshlrev_b32_e32 v77, 2, v77
	v_lshlrev_b32_e32 v78, 2, v78
	v_lshlrev_b32_e32 v79, 2, v79
	v_lshlrev_b32_e32 v80, 2, v80
	v_lshlrev_b32_e32 v81, 2, v81
	v_lshlrev_b32_e32 v82, 2, v82
	v_lshlrev_b32_e32 v83, 2, v83
	v_lshlrev_b32_e32 v84, 2, v84
	v_lshlrev_b32_e32 v85, 2, v85
	v_lshlrev_b32_e32 v86, 2, v86
	v_lshlrev_b32_e32 v87, 2, v2
	v_or_b32_e32 v90, 0x800, v19
	v_cndmask_b32_e64 v91, v88, v89, s[10:11]
	v_or_b32_e32 v93, 0x800, v18
	v_mov_b32_e32 v94, 0x3f2aaada
	v_mov_b32_e32 v95, 0x7fc00000
	v_mov_b32_e32 v96, 0xff800000
	v_mov_b32_e32 v11, 0
	s_branch .LBB0_3
.LBB0_2:                                ;   in Loop: Header=BB0_3 Depth=1
	s_or_b64 exec, exec, s[12:13]
	s_waitcnt vmcnt(0)
	s_barrier
	s_load_dword s12, s[4:5], 0x0
	s_waitcnt lgkmcnt(0)
	s_add_i32 s8, s12, s8
	s_cmp_lt_u32 s8, 32
	s_cbranch_scc0 .LBB0_25
.LBB0_3:                                ; =>This Inner Loop Header: Depth=1
	s_cmp_lt_u32 s8, 16
	s_cselect_b64 s[12:13], -1, 0
	v_cndmask_b32_e64 v1, 0, 1, s[12:13]
	s_lshl_b32 s50, s8, 7
	v_cmp_ne_u32_e64 s[12:13], 1, v1
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b64 s[42:43], s[14:15]
	s_xor_b64 s[42:43], exec, s[42:43]
	s_cbranch_execz .LBB0_7
; %bb.4:                                ;   in Loop: Header=BB0_3 Depth=1
	v_or_b32_e32 v1, s50, v17
	v_or_b32_e32 v1, 0x800, v1
	v_lshl_add_u32 v10, v1, 1, v1
	v_lshlrev_b64 v[14:15], 2, v[10:11]
	v_mov_b32_e32 v2, s27
	v_add_co_u32_e32 v12, vcc, s26, v14
	v_lshlrev_b32_e32 v10, 2, v1
	v_addc_co_u32_e32 v13, vcc, v2, v15, vcc
	v_lshlrev_b64 v[2:3], 2, v[10:11]
	v_mov_b32_e32 v4, s25
	v_add_co_u32_e32 v97, vcc, s24, v2
	v_mov_b32_e32 v2, v11
	v_lshlrev_b64 v[1:2], 2, v[1:2]
	v_addc_co_u32_e32 v98, vcc, v4, v3, vcc
	v_mov_b32_e32 v3, s17
	v_add_co_u32_e32 v99, vcc, s16, v1
	v_addc_co_u32_e32 v100, vcc, v3, v2, vcc
	global_load_dword v16, v[99:100], off
	global_load_dwordx4 v[1:4], v[97:98], off
	global_load_dwordx3 v[5:7], v[12:13], off
	s_and_b64 vcc, exec, s[12:13]
	s_cbranch_vccnz .LBB0_6
; %bb.5:                                ;   in Loop: Header=BB0_3 Depth=1
	v_mov_b32_e32 v10, s29
	v_add_co_u32_e32 v97, vcc, s28, v14
	v_addc_co_u32_e32 v98, vcc, v10, v15, vcc
	s_waitcnt vmcnt(0)
	global_store_dword v[97:98], v6, off
	global_load_dword v15, v[12:13], off offset:8
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v[97:98], v[15:16], off offset:4
.LBB0_6:                                ;   in Loop: Header=BB0_3 Depth=1
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v2, v2, v6
	v_fmac_f32_e32 v2, v1, v5
	v_fmac_f32_e32 v2, v3, v7
	v_fmac_f32_e32 v2, v16, v4
.LBB0_7:                                ;   in Loop: Header=BB0_3 Depth=1
	s_or_saveexec_b64 s[42:43], s[42:43]
	v_mov_b32_e32 v1, v88
	s_xor_b64 exec, exec, s[42:43]
	s_cbranch_execz .LBB0_11
; %bb.8:                                ;   in Loop: Header=BB0_3 Depth=1
	s_and_b32 s51, s50, 0x780
	v_or_b32_e32 v1, s51, v0
	v_mul_u32_u24_e32 v2, 3, v1
	v_lshlrev_b32_e32 v12, 2, v1
	v_lshlrev_b32_e32 v10, 2, v2
	v_lshlrev_b32_e32 v14, 4, v1
	global_load_dword v13, v12, s[16:17]
	global_load_dwordx4 v[1:4], v14, s[24:25]
	global_load_dwordx3 v[5:7], v10, s[26:27]
	s_and_b64 vcc, exec, s[12:13]
	s_cbranch_vccnz .LBB0_10
; %bb.9:                                ;   in Loop: Header=BB0_3 Depth=1
	v_mov_b32_e32 v12, s27
	v_add_co_u32_e32 v14, vcc, s26, v10
	v_addc_co_u32_e32 v15, vcc, 0, v12, vcc
	s_waitcnt vmcnt(0)
	global_store_dword v10, v6, s[28:29]
	global_load_dword v12, v[14:15], off offset:8
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v10, v[12:13], s[28:29] offset:4
.LBB0_10:                               ;   in Loop: Header=BB0_3 Depth=1
	v_or_b32_e32 v10, s50, v0
	v_or_b32_e32 v97, 0x1000, v10
	v_lshl_add_u32 v10, v97, 1, v97
	v_lshlrev_b64 v[101:102], 2, v[10:11]
	v_mov_b32_e32 v10, s27
	v_add_co_u32_e32 v103, vcc, s26, v101
	v_addc_co_u32_e32 v104, vcc, v10, v102, vcc
	global_load_dwordx3 v[14:16], v[103:104], off
	v_mov_b32_e32 v98, v11
	v_lshlrev_b64 v[98:99], 2, v[97:98]
	v_lshlrev_b32_e32 v10, 2, v97
	v_mov_b32_e32 v100, s17
	v_lshlrev_b64 v[105:106], 2, v[10:11]
	v_add_co_u32_e32 v97, vcc, s16, v98
	v_addc_co_u32_e32 v98, vcc, v100, v99, vcc
	v_mov_b32_e32 v12, s25
	global_load_dword v107, v[97:98], off
	v_add_co_u32_e32 v97, vcc, s24, v105
	v_addc_co_u32_e32 v98, vcc, v12, v106, vcc
	global_load_dwordx4 v[97:100], v[97:98], off
	v_mov_b32_e32 v108, s29
	v_add_co_u32_e32 v101, vcc, s28, v101
	v_addc_co_u32_e32 v102, vcc, v108, v102, vcc
	s_waitcnt vmcnt(3)
	v_mul_f32_e32 v2, v2, v6
	v_fmac_f32_e32 v2, v1, v5
	v_fmac_f32_e32 v2, v3, v7
	v_fmac_f32_e32 v2, v13, v4
	v_mul_f32_e32 v1, 0xbfb8aa3b, v2
	v_exp_f32_e32 v1, v1
	v_add_f32_e32 v1, 1.0, v1
	v_div_scale_f32 v3, s[12:13], v1, v1, v2
	v_div_scale_f32 v4, vcc, v2, v1, v2
	v_rcp_f32_e32 v5, v3
	v_fma_f32 v6, -v3, v5, 1.0
	v_fmac_f32_e32 v5, v6, v5
	v_mul_f32_e32 v6, v4, v5
	v_fma_f32 v7, -v3, v6, v4
	v_fmac_f32_e32 v6, v7, v5
	v_fma_f32 v3, -v3, v6, v4
	v_div_fmas_f32 v3, v3, v5, v6
	v_div_fixup_f32 v1, v3, v1, v2
	ds_write_b32 v89, v1
	v_mov_b32_e32 v1, v90
	s_waitcnt vmcnt(2)
	global_store_dword v[101:102], v15, off
	global_load_dword v106, v[103:104], off offset:8
	s_waitcnt vmcnt(2)
	v_mul_f32_e32 v2, v98, v15
	v_fmac_f32_e32 v2, v97, v14
	v_fmac_f32_e32 v2, v99, v16
	v_fmac_f32_e32 v2, v107, v100
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v[101:102], v[106:107], off offset:4
.LBB0_11:                               ;   in Loop: Header=BB0_3 Depth=1
	s_or_b64 exec, exec, s[42:43]
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2
	v_exp_f32_e32 v3, v3
	v_add_f32_e32 v3, 1.0, v3
	v_div_scale_f32 v4, s[12:13], v3, v3, v2
	v_div_scale_f32 v5, vcc, v2, v3, v2
	v_rcp_f32_e32 v6, v4
	v_fma_f32 v7, -v4, v6, 1.0
	v_fmac_f32_e32 v6, v7, v6
	v_mul_f32_e32 v7, v5, v6
	v_fma_f32 v10, -v4, v7, v5
	v_fmac_f32_e32 v7, v10, v6
	v_fma_f32 v4, -v4, v7, v5
	v_div_fmas_f32 v4, v4, v6, v7
	v_div_fixup_f32 v2, v4, v3, v2
	ds_write_b32 v1, v2
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	ds_read_b32 v1, v91
	v_mov_b32_e32 v2, v11
	v_mov_b32_e32 v3, v11
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v4, v1, v1
	s_nop 1
	v_mov_b32_dpp v2, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	v_fmac_f32_e32 v2, v1, v1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_half_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:15 row_mask:0xa bank_mask:0xf
	v_add_f32_e32 v2, v2, v3
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_and_saveexec_b64 s[12:13], s[6:7]
	s_cbranch_execz .LBB0_13
; %bb.12:                               ;   in Loop: Header=BB0_3 Depth=1
	v_add_f32_e32 v2, v2, v3
	ds_write_b32 v20, v2
.LBB0_13:                               ;   in Loop: Header=BB0_3 Depth=1
	s_or_b64 exec, exec, s[12:13]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[12:13], s[14:15]
	s_xor_b64 s[12:13], exec, s[12:13]
	s_cbranch_execz .LBB0_15
; %bb.14:                               ;   in Loop: Header=BB0_3 Depth=1
	ds_read_b64 v[2:3], v11 offset:2568
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v2, 0x358637bd, v2
	v_mul_f32_e32 v3, 0x4b800000, v2
	v_cmp_gt_f32_e32 vcc, s44, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_rsq_f32_e32 v2, v2
	v_mul_f32_e32 v3, 0x45800000, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_mul_f32_e32 v1, v1, v2
	ds_write_b32 v88, v1
                                        ; implicit-def: $vgpr1
.LBB0_15:                               ;   in Loop: Header=BB0_3 Depth=1
	s_andn2_saveexec_b64 s[12:13], s[12:13]
	s_cbranch_execz .LBB0_17
; %bb.16:                               ;   in Loop: Header=BB0_3 Depth=1
	ds_read_b64 v[2:3], v11 offset:2560
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v2, 0x358637bd, v2
	v_mul_f32_e32 v3, 0x4b800000, v2
	v_cmp_gt_f32_e32 vcc, s44, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_rsq_f32_e32 v2, v2
	v_mul_f32_e32 v3, 0x45800000, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_mul_f32_e32 v1, v1, v2
	v_mul_f32_e32 v1, v92, v1
	ds_write_b32 v89, v1
.LBB0_17:                               ;   in Loop: Header=BB0_3 Depth=1
	s_or_b64 exec, exec, s[12:13]
	s_lshl_b64 s[12:13], s[8:9], 2
	s_add_u32 s42, s22, s12
	s_addc_u32 s43, s23, s13
	s_add_u32 s52, s30, s12
	s_addc_u32 s53, s31, s13
	s_add_u32 s54, s20, s12
	s_addc_u32 s55, s21, s13
	s_add_u32 s12, s36, s12
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_addc_u32 s13, s37, s13
	global_load_dword v3, v11, s[54:55]
	global_load_dword v4, v11, s[12:13]
	global_load_dword v1, v11, s[42:43]
	global_load_dword v2, v11, s[52:53]
	s_waitcnt vmcnt(2)
	v_add_f32_e32 v3, v3, v4
	v_cmp_lt_f32_e32 vcc, s45, v3
	s_cbranch_vccnz .LBB0_19
; %bb.18:                               ;   in Loop: Header=BB0_3 Depth=1
	v_mul_f32_e32 v3, 0x3fb8aa3b, v3
	v_exp_f32_e32 v3, v3
	v_add_f32_e32 v4, 1.0, v3
	v_frexp_mant_f32_e32 v6, v4
	v_add_f32_e32 v5, -1.0, v4
	v_frexp_exp_i32_f32_e32 v7, v4
	v_cmp_gt_f32_e32 vcc, s46, v6
	v_sub_f32_e32 v10, v5, v4
	v_subbrev_co_u32_e32 v6, vcc, 0, v7, vcc
	v_sub_f32_e32 v5, v3, v5
	v_add_f32_e32 v10, 1.0, v10
	v_sub_u32_e32 v7, 0, v6
	v_add_f32_e32 v5, v5, v10
	v_ldexp_f32 v4, v4, v7
	v_ldexp_f32 v5, v5, v7
	v_add_f32_e32 v7, -1.0, v4
	v_add_f32_e32 v13, 1.0, v4
	v_add_f32_e32 v10, 1.0, v7
	v_add_f32_e32 v14, -1.0, v13
	v_sub_f32_e32 v10, v4, v10
	v_sub_f32_e32 v4, v4, v14
	v_add_f32_e32 v4, v5, v4
	v_add_f32_e32 v10, v5, v10
	v_add_f32_e32 v5, v13, v4
	v_rcp_f32_e32 v14, v5
	v_add_f32_e32 v12, v7, v10
	v_sub_f32_e32 v7, v12, v7
	v_sub_f32_e32 v7, v10, v7
	v_sub_f32_e32 v10, v5, v13
	v_sub_f32_e32 v4, v4, v10
	v_mul_f32_e32 v10, v12, v14
	v_mul_f32_e32 v13, v5, v10
	v_fma_f32 v15, v10, v5, -v13
	v_fmac_f32_e32 v15, v10, v4
	v_add_f32_e32 v16, v13, v15
	v_sub_f32_e32 v97, v12, v16
	v_sub_f32_e32 v12, v12, v97
	v_sub_f32_e32 v13, v16, v13
	v_sub_f32_e32 v12, v12, v16
	v_add_f32_e32 v7, v7, v12
	v_sub_f32_e32 v12, v13, v15
	v_add_f32_e32 v7, v12, v7
	v_add_f32_e32 v12, v97, v7
	v_mul_f32_e32 v13, v14, v12
	v_mul_f32_e32 v15, v5, v13
	v_fma_f32 v5, v13, v5, -v15
	v_fmac_f32_e32 v5, v13, v4
	v_sub_f32_e32 v4, v97, v12
	v_add_f32_e32 v4, v7, v4
	v_add_f32_e32 v7, v15, v5
	v_sub_f32_e32 v16, v12, v7
	v_sub_f32_e32 v12, v12, v16
	v_sub_f32_e32 v15, v7, v15
	v_sub_f32_e32 v7, v12, v7
	v_add_f32_e32 v4, v4, v7
	v_sub_f32_e32 v5, v15, v5
	v_cvt_f32_i32_e32 v6, v6
	v_add_f32_e32 v4, v5, v4
	v_add_f32_e32 v5, v10, v13
	v_add_f32_e32 v4, v16, v4
	v_sub_f32_e32 v7, v5, v10
	v_mul_f32_e32 v4, v14, v4
	v_sub_f32_e32 v7, v13, v7
	v_add_f32_e32 v4, v7, v4
	v_mul_f32_e32 v13, 0x3f317218, v6
	v_add_f32_e32 v7, v5, v4
	v_fma_f32 v14, v6, s47, -v13
	v_mul_f32_e32 v10, v7, v7
	v_mov_b32_e32 v12, 0x3ecc95a3
	v_fmac_f32_e32 v14, 0xb102e308, v6
	v_sub_f32_e32 v5, v7, v5
	v_fmac_f32_e32 v12, 0x3e9b6dac, v10
	v_sub_f32_e32 v4, v4, v5
	v_add_f32_e32 v5, v13, v14
	v_fma_f32 v12, v10, v12, v94
	v_sub_f32_e32 v6, v5, v13
	v_ldexp_f32 v13, v7, 1
	v_mul_f32_e32 v7, v7, v10
	v_mul_f32_e32 v7, v7, v12
	v_add_f32_e32 v10, v13, v7
	v_sub_f32_e32 v12, v10, v13
	v_ldexp_f32 v4, v4, 1
	v_sub_f32_e32 v7, v7, v12
	v_add_f32_e32 v4, v4, v7
	v_add_f32_e32 v7, v10, v4
	v_sub_f32_e32 v10, v7, v10
	v_sub_f32_e32 v4, v4, v10
	v_add_f32_e32 v10, v5, v7
	v_sub_f32_e32 v12, v10, v5
	v_sub_f32_e32 v13, v10, v12
	v_sub_f32_e32 v6, v14, v6
	v_sub_f32_e32 v5, v5, v13
	v_sub_f32_e32 v7, v7, v12
	v_add_f32_e32 v5, v7, v5
	v_add_f32_e32 v7, v6, v4
	v_sub_f32_e32 v12, v7, v6
	v_sub_f32_e32 v13, v7, v12
	v_sub_f32_e32 v6, v6, v13
	v_sub_f32_e32 v4, v4, v12
	v_add_f32_e32 v5, v7, v5
	v_add_f32_e32 v4, v4, v6
	v_add_f32_e32 v6, v10, v5
	v_sub_f32_e32 v7, v6, v10
	v_sub_f32_e32 v5, v5, v7
	v_add_f32_e32 v4, v4, v5
	v_add_f32_e32 v4, v6, v4
	v_cmp_eq_f32_e32 vcc, s48, v3
	v_cndmask_b32_e32 v4, v4, v3, vcc
	v_cmp_ngt_f32_e32 vcc, -1.0, v3
	v_cndmask_b32_e32 v4, v95, v4, vcc
	v_cmp_neq_f32_e32 vcc, -1.0, v3
	v_cndmask_b32_e32 v4, v96, v4, vcc
	v_cmp_lt_f32_e64 vcc, |v3|, s49
	v_cndmask_b32_e32 v3, v4, v3, vcc
.LBB0_19:                               ;   in Loop: Header=BB0_3 Depth=1
	s_lshl_b64 s[12:13], s[8:9], 16
	s_add_u32 s12, s34, s12
	s_addc_u32 s13, s35, s13
	global_load_dword v6, v24, s[12:13]
	global_load_dword v7, v25, s[12:13]
	global_load_dword v10, v26, s[12:13]
	global_load_dword v12, v27, s[12:13]
	global_load_dword v13, v28, s[12:13]
	global_load_dword v15, v29, s[12:13]
	global_load_dword v16, v30, s[12:13]
	global_load_dword v109, v31, s[12:13]
	global_load_dword v110, v32, s[12:13]
	global_load_dword v111, v33, s[12:13]
	global_load_dword v112, v34, s[12:13]
	global_load_dword v125, v35, s[12:13]
	global_load_dword v126, v36, s[12:13]
	global_load_dword v127, v37, s[12:13]
	global_load_dword v142, v38, s[12:13]
	global_load_dword v143, v39, s[12:13]
	global_load_dword v144, v40, s[12:13]
	global_load_dword v145, v41, s[12:13]
	global_load_dword v146, v42, s[12:13]
	global_load_dword v147, v43, s[12:13]
	global_load_dword v152, v44, s[12:13]
	global_load_dword v153, v45, s[12:13]
	global_load_dword v154, v46, s[12:13]
	global_load_dword v155, v47, s[12:13]
	global_load_dword v156, v48, s[12:13]
	global_load_dword v157, v49, s[12:13]
	global_load_dword v158, v50, s[12:13]
	global_load_dword v159, v51, s[12:13]
	global_load_dword v160, v52, s[12:13]
	global_load_dword v161, v53, s[12:13]
	global_load_dword v162, v54, s[12:13]
	global_load_dword v163, v55, s[12:13]
	s_waitcnt vmcnt(32)
	v_mul_f32_e32 v14, v2, v3
	v_mul_f32_e32 v14, 0x3fb8aa3b, v14
	v_exp_f32_e32 v14, v14
	ds_read_b128 v[2:5], v22
	ds_read_b128 v[97:100], v22 offset:16
	ds_read_b128 v[101:104], v22 offset:32
	ds_read_b128 v[105:108], v22 offset:48
	ds_read_b128 v[113:116], v22 offset:64
	ds_read_b128 v[117:120], v22 offset:80
	ds_read_b128 v[121:124], v22 offset:96
	ds_read_b128 v[148:151], v22 offset:112
	global_load_dword v164, v56, s[12:13]
	global_load_dword v165, v57, s[12:13]
	global_load_dword v166, v58, s[12:13]
	global_load_dword v167, v59, s[12:13]
	global_load_dword v168, v60, s[12:13]
	global_load_dword v169, v61, s[12:13]
	global_load_dword v170, v62, s[12:13]
	global_load_dword v171, v63, s[12:13]
	global_load_dword v172, v64, s[12:13]
	global_load_dword v173, v65, s[12:13]
	global_load_dword v174, v66, s[12:13]
	global_load_dword v175, v67, s[12:13]
	global_load_dword v176, v68, s[12:13]
	global_load_dword v177, v69, s[12:13]
	global_load_dword v178, v70, s[12:13]
	global_load_dword v179, v71, s[12:13]
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1
	v_exp_f32_e32 v1, v1
	s_waitcnt vmcnt(47)
	v_mul_f32_e32 v128, v6, v14
	s_waitcnt vmcnt(46)
	v_mul_f32_e32 v129, v14, v7
	s_waitcnt vmcnt(45)
	v_mul_f32_e32 v130, v14, v10
	s_waitcnt vmcnt(44)
	v_mul_f32_e32 v131, v14, v12
	s_waitcnt vmcnt(43)
	v_mul_f32_e32 v132, v14, v13
	s_waitcnt vmcnt(42)
	v_mul_f32_e32 v133, v14, v15
	s_waitcnt vmcnt(41)
	v_mul_f32_e32 v134, v14, v16
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v135, v14, v109
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v136, v14, v110
	s_waitcnt vmcnt(38)
	v_mul_f32_e32 v137, v14, v111
	s_waitcnt vmcnt(37)
	v_mul_f32_e32 v138, v14, v112
	s_waitcnt vmcnt(36)
	v_mul_f32_e32 v139, v14, v125
	s_waitcnt lgkmcnt(7)
	v_fma_f32 v125, v2, v128, 0
	global_load_dword v2, v72, s[12:13]
	global_load_dword v12, v73, s[12:13]
	global_load_dword v16, v74, s[12:13]
	v_fmac_f32_e32 v125, v129, v3
	v_fmac_f32_e32 v125, v130, v4
	v_fmac_f32_e32 v125, v131, v5
	s_waitcnt lgkmcnt(6)
	v_fmac_f32_e32 v125, v132, v97
	global_load_dword v97, v75, s[12:13]
	v_fmac_f32_e32 v125, v133, v98
	v_fmac_f32_e32 v125, v134, v99
	v_fmac_f32_e32 v125, v135, v100
	s_waitcnt lgkmcnt(5)
	v_fmac_f32_e32 v125, v136, v101
	v_fmac_f32_e32 v125, v137, v102
	v_fmac_f32_e32 v125, v138, v103
	global_load_dword v103, v76, s[12:13]
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v140, v14, v126
	v_fmac_f32_e32 v125, v139, v104
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v141, v14, v127
	s_waitcnt lgkmcnt(4)
	v_fmac_f32_e32 v125, v140, v105
	global_load_dword v105, v77, s[12:13]
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v142, v14, v142
	v_fmac_f32_e32 v125, v141, v106
	global_load_dword v106, v78, s[12:13]
	global_load_dword v110, v79, s[12:13]
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v143, v14, v143
	v_fmac_f32_e32 v125, v142, v107
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v144, v14, v144
	v_fmac_f32_e32 v125, v143, v108
	s_waitcnt vmcnt(38)
	v_mul_f32_e32 v145, v14, v145
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v125, v144, v113
	s_waitcnt vmcnt(37)
	v_mul_f32_e32 v146, v14, v146
	v_fmac_f32_e32 v125, v145, v114
	s_waitcnt vmcnt(36)
	v_mul_f32_e32 v147, v14, v147
	v_fmac_f32_e32 v125, v146, v115
	s_waitcnt vmcnt(35)
	v_mul_f32_e32 v109, v14, v152
	v_fmac_f32_e32 v125, v147, v116
	s_waitcnt vmcnt(34)
	v_mul_f32_e32 v180, v14, v153
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v112, v14, v156
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v109, v117
	global_load_dword v156, v80, s[12:13]
	v_mul_f32_e32 v181, v14, v154
	v_fmac_f32_e32 v125, v180, v118
	v_mul_f32_e32 v127, v14, v155
	v_fmac_f32_e32 v125, v181, v119
	v_fmac_f32_e32 v125, v127, v120
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v108, v14, v157
	global_load_dword v157, v81, s[12:13]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v112, v121
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v107, v14, v158
	global_load_dword v158, v82, s[12:13]
	v_fmac_f32_e32 v125, v108, v122
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v104, v14, v159
	global_load_dword v159, v83, s[12:13]
	v_fmac_f32_e32 v125, v107, v123
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v98, v14, v160
	v_fmac_f32_e32 v125, v104, v124
	s_waitcnt vmcnt(30)
	v_mul_f32_e32 v13, v14, v161
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v98, v148
	s_waitcnt vmcnt(29)
	v_mul_f32_e32 v7, v14, v162
	v_fmac_f32_e32 v125, v13, v149
	s_waitcnt vmcnt(28)
	v_mul_f32_e32 v4, v14, v163
	v_fmac_f32_e32 v125, v7, v150
	ds_read_b128 v[99:102], v22 offset:128
	v_fmac_f32_e32 v125, v4, v151
	ds_read_b128 v[148:151], v22 offset:144
	global_load_dword v160, v84, s[12:13]
	global_load_dword v161, v85, s[12:13]
	global_load_dword v162, v86, s[12:13]
	global_load_dword v163, v87, s[12:13]
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v120, v14, v164
	v_add_f32_e32 v164, 1.0, v1
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v120, v99
	s_waitcnt vmcnt(30)
	v_mul_f32_e32 v126, v14, v165
	v_div_scale_f32 v1, s[42:43], v164, v164, 1.0
	v_fmac_f32_e32 v125, v126, v100
	s_waitcnt vmcnt(29)
	v_mul_f32_e32 v124, v14, v166
	v_fmac_f32_e32 v125, v124, v101
	s_waitcnt vmcnt(28)
	v_mul_f32_e32 v123, v14, v167
	v_fmac_f32_e32 v125, v123, v102
	s_waitcnt vmcnt(27)
	v_mul_f32_e32 v118, v14, v168
	ds_read_b128 v[152:155], v22 offset:160
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v118, v148
	s_waitcnt vmcnt(26)
	v_mul_f32_e32 v115, v14, v169
	v_fmac_f32_e32 v125, v115, v149
	s_waitcnt vmcnt(25)
	v_mul_f32_e32 v113, v14, v170
	v_fmac_f32_e32 v125, v113, v150
	s_waitcnt vmcnt(24)
	v_mul_f32_e32 v111, v14, v171
	s_waitcnt vmcnt(14)
	v_mul_f32_e32 v122, v14, v12
	v_div_scale_f32 v12, vcc, 1.0, v164, 1.0
	v_fmac_f32_e32 v125, v111, v151
	ds_read_b128 v[148:151], v22 offset:176
	v_mul_f32_e32 v100, v14, v172
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v100, v152
	v_mul_f32_e32 v101, v14, v173
	v_fmac_f32_e32 v125, v101, v153
	v_mul_f32_e32 v99, v14, v174
	v_fmac_f32_e32 v125, v99, v154
	v_mul_f32_e32 v15, v14, v175
	v_fmac_f32_e32 v125, v15, v155
	v_mul_f32_e32 v10, v14, v176
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v10, v148
	v_mul_f32_e32 v6, v14, v177
	v_fmac_f32_e32 v125, v6, v149
	v_mul_f32_e32 v5, v14, v178
	v_fmac_f32_e32 v125, v5, v150
	v_mul_f32_e32 v3, v14, v179
	v_fmac_f32_e32 v125, v3, v151
	ds_read_b128 v[148:151], v22 offset:192
	ds_read_b128 v[152:155], v22 offset:208
	s_waitcnt vmcnt(12)
	v_mul_f32_e32 v117, v14, v97
	v_rcp_f32_e32 v97, v1
	v_mul_f32_e32 v2, v14, v2
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v2, v148
	v_fmac_f32_e32 v125, v122, v149
	v_fma_f32 v102, -v1, v97, 1.0
	v_mul_f32_e32 v121, v14, v16
	v_fmac_f32_e32 v97, v102, v97
	v_fmac_f32_e32 v125, v121, v150
	v_mul_f32_e32 v102, v12, v97
	v_fmac_f32_e32 v125, v117, v151
	s_waitcnt vmcnt(11)
	v_mul_f32_e32 v119, v14, v103
	v_fma_f32 v103, -v1, v102, v12
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v119, v152
	s_waitcnt vmcnt(10)
	v_mul_f32_e32 v116, v14, v105
	v_fmac_f32_e32 v102, v103, v97
	v_fmac_f32_e32 v125, v116, v153
	s_waitcnt vmcnt(9)
	v_mul_f32_e32 v114, v14, v106
	v_fma_f32 v1, -v1, v102, v12
	v_fmac_f32_e32 v125, v114, v154
	s_waitcnt vmcnt(8)
	v_mul_f32_e32 v110, v14, v110
	s_waitcnt vmcnt(7)
	v_mul_f32_e32 v16, v14, v156
	v_div_fmas_f32 v156, v1, v97, v102
	v_fmac_f32_e32 v125, v110, v155
	ds_read_b128 v[148:151], v22 offset:224
	ds_read_b128 v[152:155], v22 offset:240
	s_waitcnt vmcnt(6)
	v_mul_f32_e32 v106, v14, v157
	s_waitcnt vmcnt(5)
	v_mul_f32_e32 v105, v14, v158
	s_waitcnt vmcnt(4)
	v_mul_f32_e32 v103, v14, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v16, v148
	v_fmac_f32_e32 v125, v106, v149
	v_fmac_f32_e32 v125, v105, v150
	v_fmac_f32_e32 v125, v103, v151
	s_waitcnt vmcnt(3)
	v_mul_f32_e32 v102, v14, v160
	s_waitcnt vmcnt(2)
	v_mul_f32_e32 v97, v14, v161
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v102, v152
	s_waitcnt vmcnt(1)
	v_mul_f32_e32 v12, v14, v162
	v_fmac_f32_e32 v125, v97, v153
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v1, v14, v163
	v_fmac_f32_e32 v125, v12, v154
	v_fmac_f32_e32 v125, v1, v155
	ds_write_b32 v21, v125
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read2st64_b32 v[152:153], v18 offset1:2
	ds_read_b32 v125, v93
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b128 v[148:151], v22
	v_div_fixup_f32 v14, v156, v164, 1.0
	ds_read_b128 v[156:159], v23
	v_add_f32_e32 v152, v152, v153
	v_sub_f32_e32 v125, v125, v152
	v_mul_f32_e32 v14, v14, v125
	ds_read_b128 v[152:155], v22 offset:16
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v128, v14, v148
	v_fmac_f32_e32 v129, v14, v149
	v_fmac_f32_e32 v130, v14, v150
	v_fmac_f32_e32 v131, v14, v151
	ds_read_b128 v[148:151], v23 offset:16
	s_waitcnt lgkmcnt(2)
	v_fma_f32 v125, v128, v156, 0
	v_fmac_f32_e32 v125, v129, v157
	v_fmac_f32_e32 v125, v130, v158
	v_fmac_f32_e32 v125, v131, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v132, v14, v152
	v_fmac_f32_e32 v133, v14, v153
	v_fmac_f32_e32 v134, v14, v154
	v_fmac_f32_e32 v135, v14, v155
	ds_read_b128 v[152:155], v22 offset:32
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v132, v148
	ds_read_b128 v[156:159], v23 offset:32
	v_fmac_f32_e32 v125, v133, v149
	v_fmac_f32_e32 v125, v134, v150
	v_fmac_f32_e32 v125, v135, v151
	ds_read_b128 v[148:151], v22 offset:48
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v136, v14, v152
	v_fmac_f32_e32 v137, v14, v153
	v_fmac_f32_e32 v138, v14, v154
	v_fmac_f32_e32 v139, v14, v155
	ds_read_b128 v[152:155], v23 offset:48
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v136, v156
	v_fmac_f32_e32 v125, v137, v157
	v_fmac_f32_e32 v125, v138, v158
	v_fmac_f32_e32 v125, v139, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v140, v14, v148
	v_fmac_f32_e32 v141, v14, v149
	v_fmac_f32_e32 v142, v14, v150
	v_fmac_f32_e32 v143, v14, v151
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v140, v152
	ds_read_b128 v[148:151], v22 offset:64
	v_fmac_f32_e32 v125, v141, v153
	ds_read_b128 v[156:159], v23 offset:64
	v_fmac_f32_e32 v125, v142, v154
	v_fmac_f32_e32 v125, v143, v155
	ds_read_b128 v[152:155], v22 offset:80
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v144, v14, v148
	v_fmac_f32_e32 v145, v14, v149
	v_fmac_f32_e32 v146, v14, v150
	v_fmac_f32_e32 v147, v14, v151
	ds_read_b128 v[148:151], v23 offset:80
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v144, v156
	v_fmac_f32_e32 v125, v145, v157
	global_store_dword v24, v128, s[12:13]
	global_store_dword v25, v129, s[12:13]
	global_store_dword v26, v130, s[12:13]
	global_store_dword v27, v131, s[12:13]
	global_store_dword v28, v132, s[12:13]
	global_store_dword v29, v133, s[12:13]
	global_store_dword v30, v134, s[12:13]
	global_store_dword v31, v135, s[12:13]
	global_store_dword v32, v136, s[12:13]
	global_store_dword v33, v137, s[12:13]
	global_store_dword v34, v138, s[12:13]
	global_store_dword v35, v139, s[12:13]
	global_store_dword v36, v140, s[12:13]
	global_store_dword v37, v141, s[12:13]
	global_store_dword v38, v142, s[12:13]
	global_store_dword v39, v143, s[12:13]
	global_store_dword v40, v144, s[12:13]
	global_store_dword v41, v145, s[12:13]
	global_store_dword v42, v146, s[12:13]
	global_store_dword v43, v147, s[12:13]
	v_fmac_f32_e32 v125, v146, v158
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v109, v14, v152
	v_fmac_f32_e32 v180, v14, v153
	v_fmac_f32_e32 v181, v14, v154
	v_fmac_f32_e32 v127, v14, v155
	ds_read_b128 v[128:131], v22 offset:96
	v_fmac_f32_e32 v125, v147, v159
	global_store_dword v44, v109, s[12:13]
	global_store_dword v45, v180, s[12:13]
	global_store_dword v46, v181, s[12:13]
	global_store_dword v47, v127, s[12:13]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v109, v148
	ds_read_b128 v[132:135], v23 offset:96
	ds_read_b128 v[136:139], v22 offset:112
	v_fmac_f32_e32 v125, v180, v149
	v_fmac_f32_e32 v125, v181, v150
	v_fmac_f32_e32 v125, v127, v151
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v112, v14, v128
	ds_read_b128 v[140:143], v23 offset:112
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v112, v132
	v_fmac_f32_e32 v108, v14, v129
	v_fmac_f32_e32 v125, v108, v133
	v_fmac_f32_e32 v107, v14, v130
	ds_read_b128 v[127:130], v23 offset:128
	v_fmac_f32_e32 v125, v107, v134
	v_fmac_f32_e32 v104, v14, v131
	ds_read_b128 v[131:134], v22 offset:128
	v_fmac_f32_e32 v125, v104, v135
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v98, v14, v136
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v98, v140
	v_fmac_f32_e32 v13, v14, v137
	v_fmac_f32_e32 v125, v13, v141
	v_fmac_f32_e32 v7, v14, v138
	ds_read_b128 v[135:138], v22 offset:144
	v_fmac_f32_e32 v125, v7, v142
	v_fmac_f32_e32 v4, v14, v139
	v_fmac_f32_e32 v125, v4, v143
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v120, v14, v131
	ds_read_b128 v[139:142], v23 offset:144
	v_fmac_f32_e32 v125, v120, v127
	v_fmac_f32_e32 v126, v14, v132
	v_fmac_f32_e32 v125, v126, v128
	v_fmac_f32_e32 v124, v14, v133
	v_fmac_f32_e32 v123, v14, v134
	global_store_dword v48, v112, s[12:13]
	global_store_dword v49, v108, s[12:13]
	global_store_dword v50, v107, s[12:13]
	global_store_dword v51, v104, s[12:13]
	global_store_dword v52, v98, s[12:13]
	global_store_dword v53, v13, s[12:13]
	global_store_dword v54, v7, s[12:13]
	global_store_dword v55, v4, s[12:13]
	global_store_dword v56, v120, s[12:13]
	global_store_dword v57, v126, s[12:13]
	global_store_dword v58, v124, s[12:13]
	v_fmac_f32_e32 v125, v124, v129
	global_store_dword v59, v123, s[12:13]
	v_fmac_f32_e32 v125, v123, v130
	ds_read_b128 v[126:129], v22 offset:160
	ds_read_b128 v[130:133], v22 offset:176
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v118, v14, v135
	v_fmac_f32_e32 v115, v14, v136
	v_fmac_f32_e32 v113, v14, v137
	ds_read_b128 v[134:137], v23 offset:160
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v125, v118, v139
	v_fmac_f32_e32 v125, v115, v140
	v_fmac_f32_e32 v125, v113, v141
	v_fmac_f32_e32 v111, v14, v138
	ds_read_b128 v[138:141], v23 offset:176
	v_fmac_f32_e32 v125, v111, v142
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v100, v14, v126
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v100, v134
	v_fmac_f32_e32 v101, v14, v127
	v_fmac_f32_e32 v125, v101, v135
	v_fmac_f32_e32 v99, v14, v128
	v_fmac_f32_e32 v125, v99, v136
	v_fmac_f32_e32 v15, v14, v129
	v_fmac_f32_e32 v125, v15, v137
	v_fmac_f32_e32 v10, v14, v130
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v10, v138
	v_fmac_f32_e32 v6, v14, v131
	global_store_dword v60, v118, s[12:13]
	global_store_dword v61, v115, s[12:13]
	global_store_dword v62, v113, s[12:13]
	global_store_dword v63, v111, s[12:13]
	global_store_dword v64, v100, s[12:13]
	global_store_dword v65, v101, s[12:13]
	global_store_dword v66, v99, s[12:13]
	global_store_dword v67, v15, s[12:13]
	global_store_dword v68, v10, s[12:13]
	v_fmac_f32_e32 v125, v6, v139
	v_fmac_f32_e32 v5, v14, v132
	ds_read_b128 v[98:101], v23 offset:192
	ds_read_b128 v[126:129], v23 offset:208
	global_store_dword v69, v6, s[12:13]
	global_store_dword v70, v5, s[12:13]
	v_fmac_f32_e32 v125, v5, v140
	ds_read_b128 v[4:7], v22 offset:192
	v_fmac_f32_e32 v3, v14, v133
	ds_read_b128 v[130:133], v22 offset:208
	v_fmac_f32_e32 v125, v3, v141
	global_store_dword v71, v3, s[12:13]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v2, v14, v4
	v_fmac_f32_e32 v125, v2, v98
	v_fmac_f32_e32 v122, v14, v5
	v_fmac_f32_e32 v125, v122, v99
	v_fmac_f32_e32 v121, v14, v6
	v_fmac_f32_e32 v125, v121, v100
	v_fmac_f32_e32 v117, v14, v7
	v_fmac_f32_e32 v125, v117, v101
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v119, v14, v130
	v_fmac_f32_e32 v125, v119, v126
	v_fmac_f32_e32 v116, v14, v131
	global_store_dword v72, v2, s[12:13]
	v_fmac_f32_e32 v125, v116, v127
	v_fmac_f32_e32 v114, v14, v132
	v_fmac_f32_e32 v110, v14, v133
	ds_read_b128 v[2:5], v22 offset:224
	global_store_dword v73, v122, s[12:13]
	global_store_dword v74, v121, s[12:13]
	global_store_dword v75, v117, s[12:13]
	global_store_dword v76, v119, s[12:13]
	global_store_dword v77, v116, s[12:13]
	global_store_dword v78, v114, s[12:13]
	v_fmac_f32_e32 v125, v114, v128
	global_store_dword v79, v110, s[12:13]
	v_fmac_f32_e32 v125, v110, v129
	ds_read_b128 v[98:101], v23 offset:224
	ds_read_b128 v[107:110], v22 offset:240
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v16, v14, v2
	ds_read_b128 v[111:114], v23 offset:240
	v_fmac_f32_e32 v106, v14, v3
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v16, v98
	v_fmac_f32_e32 v125, v106, v99
	v_fmac_f32_e32 v105, v14, v4
	v_fmac_f32_e32 v125, v105, v100
	v_fmac_f32_e32 v103, v14, v5
	v_fmac_f32_e32 v125, v103, v101
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v102, v14, v107
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v102, v111
	v_fmac_f32_e32 v97, v14, v108
	v_fmac_f32_e32 v125, v97, v112
	v_fmac_f32_e32 v12, v14, v109
	v_fmac_f32_e32 v125, v12, v113
	v_fmac_f32_e32 v1, v14, v110
	global_store_dword v87, v1, s[12:13]
	v_fmac_f32_e32 v125, v1, v114
	v_mov_b32_e32 v1, 0
	global_store_dword v80, v16, s[12:13]
	global_store_dword v81, v106, s[12:13]
	global_store_dword v82, v105, s[12:13]
	global_store_dword v83, v103, s[12:13]
	global_store_dword v84, v102, s[12:13]
	global_store_dword v85, v97, s[12:13]
	global_store_dword v86, v12, s[12:13]
	ds_write_b32 v21, v125
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[12:13], s[10:11]
	s_cbranch_execz .LBB0_21
; %bb.20:                               ;   in Loop: Header=BB0_3 Depth=1
	ds_read2st64_b32 v[1:2], v19 offset1:2
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v1, v1, v2
.LBB0_21:                               ;   in Loop: Header=BB0_3 Depth=1
	s_or_b64 exec, exec, s[12:13]
	v_mul_f32_e32 v2, v1, v1
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	v_fmac_f32_e32 v3, v1, v1
	s_nop 1
	v_add_f32_dpp v2, v3, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v3, 0
	s_nop 0
	v_add_f32_dpp v2, v2, v2 row_half_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:15 row_mask:0xa bank_mask:0xf
	v_add_f32_e32 v2, v2, v3
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_and_saveexec_b64 s[12:13], s[6:7]
	s_cbranch_execz .LBB0_23
; %bb.22:                               ;   in Loop: Header=BB0_3 Depth=1
	v_add_f32_e32 v2, v2, v3
	ds_write_b32 v20, v2
.LBB0_23:                               ;   in Loop: Header=BB0_3 Depth=1
	s_or_b64 exec, exec, s[12:13]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[12:13], s[10:11]
	s_cbranch_execz .LBB0_2
; %bb.24:                               ;   in Loop: Header=BB0_3 Depth=1
	v_or_b32_e32 v10, s50, v0
	v_lshlrev_b64 v[2:3], 2, v[10:11]
	v_mov_b32_e32 v4, s19
	v_add_co_u32_e32 v2, vcc, s18, v2
	v_addc_co_u32_e32 v3, vcc, v4, v3, vcc
	global_load_dword v4, v[2:3], off
	global_load_dword v5, v[8:9], off
	s_waitcnt vmcnt(1)
	v_mul_f32_e32 v2, 0xbfb8aa3b, v4
	v_exp_f32_e32 v2, v2
	v_add_f32_e32 v6, 1.0, v2
	v_div_scale_f32 v7, s[42:43], v6, v6, v4
	v_div_scale_f32 v12, vcc, v4, v6, v4
	ds_read_b64 v[2:3], v11 offset:2560
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_rcp_f32_e32 v13, v7
	v_fma_f32 v14, -v7, v13, 1.0
	v_fmac_f32_e32 v13, v14, v13
	v_mul_f32_e32 v14, v12, v13
	v_fma_f32 v15, -v7, v14, v12
	v_fmac_f32_e32 v14, v15, v13
	v_fma_f32 v7, -v7, v14, v12
	v_div_fmas_f32 v7, v7, v13, v14
	v_mov_b32_e32 v12, s33
	v_fmac_f32_e32 v12, 0x3c000000, v2
	v_mul_f32_e32 v2, 0x4b800000, v12
	v_cmp_gt_f32_e32 vcc, s44, v12
	v_cndmask_b32_e32 v2, v12, v2, vcc
	v_rsq_f32_e32 v12, v2
	v_mov_b32_e32 v2, s38
	v_mov_b32_e32 v3, s39
	v_mul_f32_e32 v13, 0x45800000, v12
	v_cndmask_b32_e32 v12, v12, v13, vcc
	v_mul_f32_e32 v1, v1, v12
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v1, v5, v1
	v_div_fixup_f32 v4, v7, v6, v4
	v_mul_f32_e32 v1, v4, v1
	flat_store_dword v[2:3], v1
	s_waitcnt vmcnt(0)
	flat_load_dword v3, v[2:3] glc
	s_waitcnt vmcnt(0)
	v_lshlrev_b64 v[1:2], 1, v[10:11]
	v_mov_b32_e32 v4, s41
	v_add_co_u32_e32 v1, vcc, s40, v1
	v_addc_co_u32_e32 v2, vcc, v4, v2, vcc
	s_waitcnt lgkmcnt(0)
	v_cvt_f16_f32_e32 v3, v3
	global_store_short v[1:2], v3, off
	s_branch .LBB0_2
.LBB0_25:
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel volatile_step
		.amdhsa_group_segment_fixed_size 2576
		.amdhsa_private_segment_fixed_size 8
		.amdhsa_kernarg_size 368
		.amdhsa_user_sgpr_count 8
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 1
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 1
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 182
		.amdhsa_next_free_sgpr 56
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	volatile_step, .Lfunc_end0-volatile_step
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 6264
; NumSgprs: 62
; NumVgprs: 182
; ScratchSize: 8
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 2576 bytes/workgroup (compile time only)
; SGPRBlocks: 7
; VGPRBlocks: 45
; NumSGPRsForWavesPerEU: 62
; NumVGPRsForWavesPerEU: 182
; Occupancy: 1
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 1
; COMPUTE_PGM_RSRC2:USER_SGPR: 8
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.text
	.protected	live_step               ; -- Begin function live_step
	.globl	live_step
	.p2align	8
	.type	live_step,@function
live_step:                              ; @live_step
; %bb.0:
	s_cmp_gt_u32 s6, 31
	s_cbranch_scc1 .LBB1_25
; %bb.1:
	s_load_dwordx16 s[12:27], s[4:5], 0x0
	s_load_dwordx4 s[28:31], s[4:5], 0x40
	s_load_dwordx2 s[10:11], s[4:5], 0x50
	v_and_b32_e32 v2, 63, v0
	s_load_dword s33, s[4:5], 0x60
	s_load_dwordx2 s[34:35], s[4:5], 0x68
	s_load_dword s36, s[4:5], 0x70
	v_and_b32_e32 v17, 0x7f, v0
	v_lshrrev_b32_e32 v1, 7, v0
	v_cmp_eq_u32_e64 s[2:3], 63, v2
	v_lshrrev_b32_e32 v2, 4, v0
	v_mov_b32_e32 v3, 0xa00
	v_lshlrev_b32_e32 v18, 2, v17
	v_and_or_b32 v20, v2, 12, v3
	v_lshlrev_b32_e32 v2, 13, v1
	v_rsq_f32_e32 v92, 0x43000000
	s_movk_i32 s8, 0x80
	v_lshlrev_b32_e32 v19, 2, v0
	v_lshl_or_b32 v21, v1, 9, v18
	v_or_b32_e32 v3, v2, v17
	v_lshlrev_b32_e32 v1, 8, v1
	v_or_b32_e32 v2, v2, v0
	s_movk_i32 s0, 0x7f
	v_or_b32_e32 v4, 0x80, v2
	v_or_b32_e32 v5, 0x180, v2
	v_or_b32_e32 v6, 0x280, v2
	v_or_b32_e32 v7, 0x380, v2
	v_or_b32_e32 v10, 0x480, v2
	v_or_b32_e32 v11, 0x580, v2
	v_or_b32_e32 v12, 0x680, v2
	v_or_b32_e32 v13, 0x780, v2
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v9, s31
	v_add_co_u32_e32 v8, vcc, s30, v19
	v_or_b32_e32 v14, 0x880, v2
	v_or_b32_e32 v15, 0x980, v2
	v_or_b32_e32 v16, 0xa80, v2
	v_or_b32_e32 v47, 0xb80, v2
	v_or_b32_e32 v49, 0xc80, v2
	v_or_b32_e32 v51, 0xd80, v2
	v_or_b32_e32 v53, 0xe80, v2
	v_or_b32_e32 v55, 0xf80, v2
	v_or_b32_e32 v57, 0x1080, v2
	v_or_b32_e32 v59, 0x1180, v2
	v_or_b32_e32 v61, 0x1280, v2
	v_or_b32_e32 v63, 0x1380, v2
	v_or_b32_e32 v65, 0x1480, v2
	v_or_b32_e32 v67, 0x1580, v2
	v_or_b32_e32 v69, 0x1680, v2
	v_or_b32_e32 v71, 0x1780, v2
	v_or_b32_e32 v73, 0x1880, v2
	v_or_b32_e32 v75, 0x1980, v2
	v_or_b32_e32 v77, 0x1a80, v2
	v_or_b32_e32 v79, 0x1b80, v2
	v_or_b32_e32 v81, 0x1c80, v2
	v_or_b32_e32 v83, 0x1d80, v2
	v_or_b32_e32 v85, 0x1e80, v2
	v_or_b32_e32 v2, 0x1f80, v2
	v_or_b32_e32 v22, 0x400, v1
	v_or_b32_e32 v23, 0x600, v1
	v_or_b32_e32 v1, 0x100, v3
	v_or_b32_e32 v28, 0x200, v3
	v_or_b32_e32 v30, 0x300, v3
	v_or_b32_e32 v32, 0x400, v3
	v_or_b32_e32 v34, 0x500, v3
	v_or_b32_e32 v36, 0x600, v3
	v_or_b32_e32 v38, 0x700, v3
	v_or_b32_e32 v40, 0x800, v3
	v_or_b32_e32 v42, 0x900, v3
	v_or_b32_e32 v44, 0xa00, v3
	v_or_b32_e32 v46, 0xb00, v3
	v_or_b32_e32 v48, 0xc00, v3
	v_or_b32_e32 v50, 0xd00, v3
	v_or_b32_e32 v52, 0xe00, v3
	v_or_b32_e32 v54, 0xf00, v3
	v_or_b32_e32 v56, 0x1000, v3
	v_or_b32_e32 v58, 0x1100, v3
	v_or_b32_e32 v60, 0x1200, v3
	v_or_b32_e32 v62, 0x1300, v3
	v_or_b32_e32 v64, 0x1400, v3
	v_or_b32_e32 v66, 0x1500, v3
	v_or_b32_e32 v68, 0x1600, v3
	v_or_b32_e32 v70, 0x1700, v3
	v_or_b32_e32 v72, 0x1800, v3
	v_or_b32_e32 v74, 0x1900, v3
	v_or_b32_e32 v76, 0x1a00, v3
	v_or_b32_e32 v78, 0x1b00, v3
	v_or_b32_e32 v80, 0x1c00, v3
	v_or_b32_e32 v82, 0x1d00, v3
	v_or_b32_e32 v84, 0x1e00, v3
	v_or_b32_e32 v86, 0x1f00, v3
	v_or_b32_e32 v88, 0x400, v18
	v_add_u32_e32 v89, 0x600, v19
	v_cmp_gt_u32_e64 s[4:5], s8, v0
	v_cmp_lt_u32_e64 s[0:1], s0, v0
	s_mov_b32 s7, 0
	v_addc_co_u32_e32 v9, vcc, 0, v9, vcc
	s_lshl_b32 s37, s6, 7
	s_lshl_b32 s38, s36, 7
	s_mov_b32 s39, 0x800000
	s_mov_b32 s40, 0x41a00000
	s_mov_b32 s41, 0x3f2aaaab
	s_mov_b32 s42, 0x3f317218
	s_mov_b32 s43, 0x7f800000
	s_mov_b32 s44, 0x33800000
	v_lshlrev_b32_e32 v24, 2, v3
	v_lshlrev_b32_e32 v25, 2, v4
	v_lshlrev_b32_e32 v26, 2, v1
	v_lshlrev_b32_e32 v27, 2, v5
	v_lshlrev_b32_e32 v28, 2, v28
	v_lshlrev_b32_e32 v29, 2, v6
	v_lshlrev_b32_e32 v30, 2, v30
	v_lshlrev_b32_e32 v31, 2, v7
	v_lshlrev_b32_e32 v32, 2, v32
	v_lshlrev_b32_e32 v33, 2, v10
	v_lshlrev_b32_e32 v34, 2, v34
	v_lshlrev_b32_e32 v35, 2, v11
	v_lshlrev_b32_e32 v36, 2, v36
	v_lshlrev_b32_e32 v37, 2, v12
	v_lshlrev_b32_e32 v38, 2, v38
	v_lshlrev_b32_e32 v39, 2, v13
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v41, 2, v14
	v_lshlrev_b32_e32 v42, 2, v42
	v_lshlrev_b32_e32 v43, 2, v15
	v_lshlrev_b32_e32 v44, 2, v44
	v_lshlrev_b32_e32 v45, 2, v16
	v_lshlrev_b32_e32 v46, 2, v46
	v_lshlrev_b32_e32 v47, 2, v47
	v_lshlrev_b32_e32 v48, 2, v48
	v_lshlrev_b32_e32 v49, 2, v49
	v_lshlrev_b32_e32 v50, 2, v50
	v_lshlrev_b32_e32 v51, 2, v51
	v_lshlrev_b32_e32 v52, 2, v52
	v_lshlrev_b32_e32 v53, 2, v53
	v_lshlrev_b32_e32 v54, 2, v54
	v_lshlrev_b32_e32 v55, 2, v55
	v_lshlrev_b32_e32 v56, 2, v56
	v_lshlrev_b32_e32 v57, 2, v57
	v_lshlrev_b32_e32 v58, 2, v58
	v_lshlrev_b32_e32 v59, 2, v59
	v_lshlrev_b32_e32 v60, 2, v60
	v_lshlrev_b32_e32 v61, 2, v61
	v_lshlrev_b32_e32 v62, 2, v62
	v_lshlrev_b32_e32 v63, 2, v63
	v_lshlrev_b32_e32 v64, 2, v64
	v_lshlrev_b32_e32 v65, 2, v65
	v_lshlrev_b32_e32 v66, 2, v66
	v_lshlrev_b32_e32 v67, 2, v67
	v_lshlrev_b32_e32 v68, 2, v68
	v_lshlrev_b32_e32 v69, 2, v69
	v_lshlrev_b32_e32 v70, 2, v70
	v_lshlrev_b32_e32 v71, 2, v71
	v_lshlrev_b32_e32 v72, 2, v72
	v_lshlrev_b32_e32 v73, 2, v73
	v_lshlrev_b32_e32 v74, 2, v74
	v_lshlrev_b32_e32 v75, 2, v75
	v_lshlrev_b32_e32 v76, 2, v76
	v_lshlrev_b32_e32 v77, 2, v77
	v_lshlrev_b32_e32 v78, 2, v78
	v_lshlrev_b32_e32 v79, 2, v79
	v_lshlrev_b32_e32 v80, 2, v80
	v_lshlrev_b32_e32 v81, 2, v81
	v_lshlrev_b32_e32 v82, 2, v82
	v_lshlrev_b32_e32 v83, 2, v83
	v_lshlrev_b32_e32 v84, 2, v84
	v_lshlrev_b32_e32 v85, 2, v85
	v_lshlrev_b32_e32 v86, 2, v86
	v_lshlrev_b32_e32 v87, 2, v2
	v_or_b32_e32 v90, 0x800, v19
	v_cndmask_b32_e64 v91, v88, v89, s[4:5]
	v_or_b32_e32 v93, 0x800, v18
	v_mov_b32_e32 v94, 0x3f2aaada
	v_mov_b32_e32 v95, 0x7fc00000
	v_mov_b32_e32 v96, 0xff800000
	v_mov_b32_e32 v11, 0
	s_branch .LBB1_3
.LBB1_2:                                ;   in Loop: Header=BB1_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_add_i32 s6, s6, s36
	s_add_i32 s37, s37, s38
	s_cmp_lt_u32 s6, 32
	s_waitcnt vmcnt(0)
	s_barrier
	s_cbranch_scc0 .LBB1_25
.LBB1_3:                                ; =>This Inner Loop Header: Depth=1
	s_cmp_lt_u32 s6, 16
	s_cselect_b64 s[8:9], -1, 0
	v_cndmask_b32_e64 v1, 0, 1, s[8:9]
	v_cmp_ne_u32_e64 s[8:9], 1, v1
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b64 s[30:31], s[0:1]
	s_xor_b64 s[30:31], exec, s[30:31]
	s_cbranch_execz .LBB1_7
; %bb.4:                                ;   in Loop: Header=BB1_3 Depth=1
	v_add_u32_e32 v1, s37, v17
	v_or_b32_e32 v1, 0x800, v1
	v_lshl_add_u32 v10, v1, 1, v1
	v_lshlrev_b64 v[14:15], 2, v[10:11]
	v_mov_b32_e32 v2, s23
	v_add_co_u32_e32 v12, vcc, s22, v14
	v_lshlrev_b32_e32 v10, 2, v1
	v_addc_co_u32_e32 v13, vcc, v2, v15, vcc
	v_lshlrev_b64 v[2:3], 2, v[10:11]
	v_mov_b32_e32 v4, s21
	v_add_co_u32_e32 v97, vcc, s20, v2
	v_mov_b32_e32 v2, v11
	v_lshlrev_b64 v[1:2], 2, v[1:2]
	v_addc_co_u32_e32 v98, vcc, v4, v3, vcc
	v_mov_b32_e32 v3, s13
	v_add_co_u32_e32 v99, vcc, s12, v1
	v_addc_co_u32_e32 v100, vcc, v3, v2, vcc
	global_load_dword v16, v[99:100], off
	global_load_dwordx4 v[1:4], v[97:98], off
	global_load_dwordx3 v[5:7], v[12:13], off
	s_and_b64 vcc, exec, s[8:9]
	s_cbranch_vccnz .LBB1_6
; %bb.5:                                ;   in Loop: Header=BB1_3 Depth=1
	v_mov_b32_e32 v10, s25
	v_add_co_u32_e32 v97, vcc, s24, v14
	v_addc_co_u32_e32 v98, vcc, v10, v15, vcc
	s_waitcnt vmcnt(0)
	global_store_dword v[97:98], v6, off
	global_load_dword v15, v[12:13], off offset:8
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v[97:98], v[15:16], off offset:4
.LBB1_6:                                ;   in Loop: Header=BB1_3 Depth=1
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v2, v2, v6
	v_fmac_f32_e32 v2, v1, v5
	v_fmac_f32_e32 v2, v3, v7
	v_fmac_f32_e32 v2, v16, v4
.LBB1_7:                                ;   in Loop: Header=BB1_3 Depth=1
	s_or_saveexec_b64 s[30:31], s[30:31]
	v_mov_b32_e32 v1, v88
	s_xor_b64 exec, exec, s[30:31]
	s_cbranch_execz .LBB1_11
; %bb.8:                                ;   in Loop: Header=BB1_3 Depth=1
	s_and_b32 s45, s37, 0x780
	v_or_b32_e32 v1, s45, v0
	v_mul_u32_u24_e32 v2, 3, v1
	v_lshlrev_b32_e32 v12, 2, v1
	v_lshlrev_b32_e32 v10, 2, v2
	v_lshlrev_b32_e32 v14, 4, v1
	global_load_dword v13, v12, s[12:13]
	global_load_dwordx4 v[1:4], v14, s[20:21]
	global_load_dwordx3 v[5:7], v10, s[22:23]
	s_and_b64 vcc, exec, s[8:9]
	s_cbranch_vccnz .LBB1_10
; %bb.9:                                ;   in Loop: Header=BB1_3 Depth=1
	v_mov_b32_e32 v12, s23
	v_add_co_u32_e32 v14, vcc, s22, v10
	v_addc_co_u32_e32 v15, vcc, 0, v12, vcc
	s_waitcnt vmcnt(0)
	global_store_dword v10, v6, s[24:25]
	global_load_dword v12, v[14:15], off offset:8
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v10, v[12:13], s[24:25] offset:4
.LBB1_10:                               ;   in Loop: Header=BB1_3 Depth=1
	v_add_u32_e32 v10, s37, v0
	v_or_b32_e32 v97, 0x1000, v10
	v_lshl_add_u32 v10, v97, 1, v97
	v_lshlrev_b64 v[101:102], 2, v[10:11]
	v_mov_b32_e32 v10, s23
	v_add_co_u32_e32 v103, vcc, s22, v101
	v_addc_co_u32_e32 v104, vcc, v10, v102, vcc
	global_load_dwordx3 v[14:16], v[103:104], off
	v_mov_b32_e32 v98, v11
	v_lshlrev_b64 v[98:99], 2, v[97:98]
	v_lshlrev_b32_e32 v10, 2, v97
	v_mov_b32_e32 v100, s13
	v_lshlrev_b64 v[105:106], 2, v[10:11]
	v_add_co_u32_e32 v97, vcc, s12, v98
	v_addc_co_u32_e32 v98, vcc, v100, v99, vcc
	v_mov_b32_e32 v12, s21
	global_load_dword v107, v[97:98], off
	v_add_co_u32_e32 v97, vcc, s20, v105
	v_addc_co_u32_e32 v98, vcc, v12, v106, vcc
	global_load_dwordx4 v[97:100], v[97:98], off
	v_mov_b32_e32 v108, s25
	v_add_co_u32_e32 v101, vcc, s24, v101
	v_addc_co_u32_e32 v102, vcc, v108, v102, vcc
	s_waitcnt vmcnt(3)
	v_mul_f32_e32 v2, v2, v6
	v_fmac_f32_e32 v2, v1, v5
	v_fmac_f32_e32 v2, v3, v7
	v_fmac_f32_e32 v2, v13, v4
	v_mul_f32_e32 v1, 0xbfb8aa3b, v2
	v_exp_f32_e32 v1, v1
	v_add_f32_e32 v1, 1.0, v1
	v_div_scale_f32 v3, s[8:9], v1, v1, v2
	v_div_scale_f32 v4, vcc, v2, v1, v2
	v_rcp_f32_e32 v5, v3
	v_fma_f32 v6, -v3, v5, 1.0
	v_fmac_f32_e32 v5, v6, v5
	v_mul_f32_e32 v6, v4, v5
	v_fma_f32 v7, -v3, v6, v4
	v_fmac_f32_e32 v6, v7, v5
	v_fma_f32 v3, -v3, v6, v4
	v_div_fmas_f32 v3, v3, v5, v6
	v_div_fixup_f32 v1, v3, v1, v2
	ds_write_b32 v89, v1
	v_mov_b32_e32 v1, v90
	s_waitcnt vmcnt(2)
	global_store_dword v[101:102], v15, off
	global_load_dword v106, v[103:104], off offset:8
	s_waitcnt vmcnt(2)
	v_mul_f32_e32 v2, v98, v15
	v_fmac_f32_e32 v2, v97, v14
	v_fmac_f32_e32 v2, v99, v16
	v_fmac_f32_e32 v2, v107, v100
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v[101:102], v[106:107], off offset:4
.LBB1_11:                               ;   in Loop: Header=BB1_3 Depth=1
	s_or_b64 exec, exec, s[30:31]
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2
	v_exp_f32_e32 v3, v3
	v_add_f32_e32 v3, 1.0, v3
	v_div_scale_f32 v4, s[8:9], v3, v3, v2
	v_div_scale_f32 v5, vcc, v2, v3, v2
	v_rcp_f32_e32 v6, v4
	v_fma_f32 v7, -v4, v6, 1.0
	v_fmac_f32_e32 v6, v7, v6
	v_mul_f32_e32 v7, v5, v6
	v_fma_f32 v10, -v4, v7, v5
	v_fmac_f32_e32 v7, v10, v6
	v_fma_f32 v4, -v4, v7, v5
	v_div_fmas_f32 v4, v4, v6, v7
	v_div_fixup_f32 v2, v4, v3, v2
	ds_write_b32 v1, v2
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	ds_read_b32 v1, v91
	v_mov_b32_e32 v2, v11
	v_mov_b32_e32 v3, v11
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v4, v1, v1
	s_nop 1
	v_mov_b32_dpp v2, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	v_fmac_f32_e32 v2, v1, v1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_half_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:15 row_mask:0xa bank_mask:0xf
	v_add_f32_e32 v2, v2, v3
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[2:3]
	s_cbranch_execz .LBB1_13
; %bb.12:                               ;   in Loop: Header=BB1_3 Depth=1
	v_add_f32_e32 v2, v2, v3
	ds_write_b32 v20, v2
.LBB1_13:                               ;   in Loop: Header=BB1_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], s[0:1]
	s_xor_b64 s[8:9], exec, s[8:9]
	s_cbranch_execz .LBB1_15
; %bb.14:                               ;   in Loop: Header=BB1_3 Depth=1
	ds_read_b64 v[2:3], v11 offset:2568
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v2, 0x358637bd, v2
	v_mul_f32_e32 v3, 0x4b800000, v2
	v_cmp_gt_f32_e32 vcc, s39, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_rsq_f32_e32 v2, v2
	v_mul_f32_e32 v3, 0x45800000, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_mul_f32_e32 v1, v1, v2
	ds_write_b32 v88, v1
                                        ; implicit-def: $vgpr1
.LBB1_15:                               ;   in Loop: Header=BB1_3 Depth=1
	s_andn2_saveexec_b64 s[8:9], s[8:9]
	s_cbranch_execz .LBB1_17
; %bb.16:                               ;   in Loop: Header=BB1_3 Depth=1
	ds_read_b64 v[2:3], v11 offset:2560
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v2, 0x358637bd, v2
	v_mul_f32_e32 v3, 0x4b800000, v2
	v_cmp_gt_f32_e32 vcc, s39, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_rsq_f32_e32 v2, v2
	v_mul_f32_e32 v3, 0x45800000, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_mul_f32_e32 v1, v1, v2
	v_mul_f32_e32 v1, v92, v1
	ds_write_b32 v89, v1
.LBB1_17:                               ;   in Loop: Header=BB1_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_lshl_b64 s[8:9], s[6:7], 2
	s_add_u32 s30, s18, s8
	s_addc_u32 s31, s19, s9
	s_add_u32 s46, s26, s8
	s_addc_u32 s47, s27, s9
	s_add_u32 s48, s16, s8
	s_addc_u32 s49, s17, s9
	s_add_u32 s8, s28, s8
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_addc_u32 s9, s29, s9
	global_load_dword v3, v11, s[48:49]
	global_load_dword v4, v11, s[8:9]
	global_load_dword v1, v11, s[30:31]
	global_load_dword v2, v11, s[46:47]
	s_waitcnt vmcnt(2)
	v_add_f32_e32 v3, v3, v4
	v_cmp_lt_f32_e32 vcc, s40, v3
	s_cbranch_vccnz .LBB1_19
; %bb.18:                               ;   in Loop: Header=BB1_3 Depth=1
	v_mul_f32_e32 v3, 0x3fb8aa3b, v3
	v_exp_f32_e32 v3, v3
	v_add_f32_e32 v4, 1.0, v3
	v_frexp_mant_f32_e32 v6, v4
	v_add_f32_e32 v5, -1.0, v4
	v_frexp_exp_i32_f32_e32 v7, v4
	v_cmp_gt_f32_e32 vcc, s41, v6
	v_sub_f32_e32 v10, v5, v4
	v_subbrev_co_u32_e32 v6, vcc, 0, v7, vcc
	v_sub_f32_e32 v5, v3, v5
	v_add_f32_e32 v10, 1.0, v10
	v_sub_u32_e32 v7, 0, v6
	v_add_f32_e32 v5, v5, v10
	v_ldexp_f32 v4, v4, v7
	v_ldexp_f32 v5, v5, v7
	v_add_f32_e32 v7, -1.0, v4
	v_add_f32_e32 v13, 1.0, v4
	v_add_f32_e32 v10, 1.0, v7
	v_add_f32_e32 v14, -1.0, v13
	v_sub_f32_e32 v10, v4, v10
	v_sub_f32_e32 v4, v4, v14
	v_add_f32_e32 v4, v5, v4
	v_add_f32_e32 v10, v5, v10
	v_add_f32_e32 v5, v13, v4
	v_rcp_f32_e32 v14, v5
	v_add_f32_e32 v12, v7, v10
	v_sub_f32_e32 v7, v12, v7
	v_sub_f32_e32 v7, v10, v7
	v_sub_f32_e32 v10, v5, v13
	v_sub_f32_e32 v4, v4, v10
	v_mul_f32_e32 v10, v12, v14
	v_mul_f32_e32 v13, v5, v10
	v_fma_f32 v15, v10, v5, -v13
	v_fmac_f32_e32 v15, v10, v4
	v_add_f32_e32 v16, v13, v15
	v_sub_f32_e32 v97, v12, v16
	v_sub_f32_e32 v12, v12, v97
	v_sub_f32_e32 v13, v16, v13
	v_sub_f32_e32 v12, v12, v16
	v_add_f32_e32 v7, v7, v12
	v_sub_f32_e32 v12, v13, v15
	v_add_f32_e32 v7, v12, v7
	v_add_f32_e32 v12, v97, v7
	v_mul_f32_e32 v13, v14, v12
	v_mul_f32_e32 v15, v5, v13
	v_fma_f32 v5, v13, v5, -v15
	v_fmac_f32_e32 v5, v13, v4
	v_sub_f32_e32 v4, v97, v12
	v_add_f32_e32 v4, v7, v4
	v_add_f32_e32 v7, v15, v5
	v_sub_f32_e32 v16, v12, v7
	v_sub_f32_e32 v12, v12, v16
	v_sub_f32_e32 v15, v7, v15
	v_sub_f32_e32 v7, v12, v7
	v_add_f32_e32 v4, v4, v7
	v_sub_f32_e32 v5, v15, v5
	v_cvt_f32_i32_e32 v6, v6
	v_add_f32_e32 v4, v5, v4
	v_add_f32_e32 v5, v10, v13
	v_add_f32_e32 v4, v16, v4
	v_sub_f32_e32 v7, v5, v10
	v_mul_f32_e32 v4, v14, v4
	v_sub_f32_e32 v7, v13, v7
	v_add_f32_e32 v4, v7, v4
	v_mul_f32_e32 v13, 0x3f317218, v6
	v_add_f32_e32 v7, v5, v4
	v_fma_f32 v14, v6, s42, -v13
	v_mul_f32_e32 v10, v7, v7
	v_mov_b32_e32 v12, 0x3ecc95a3
	v_fmac_f32_e32 v14, 0xb102e308, v6
	v_sub_f32_e32 v5, v7, v5
	v_fmac_f32_e32 v12, 0x3e9b6dac, v10
	v_sub_f32_e32 v4, v4, v5
	v_add_f32_e32 v5, v13, v14
	v_fma_f32 v12, v10, v12, v94
	v_sub_f32_e32 v6, v5, v13
	v_ldexp_f32 v13, v7, 1
	v_mul_f32_e32 v7, v7, v10
	v_mul_f32_e32 v7, v7, v12
	v_add_f32_e32 v10, v13, v7
	v_sub_f32_e32 v12, v10, v13
	v_ldexp_f32 v4, v4, 1
	v_sub_f32_e32 v7, v7, v12
	v_add_f32_e32 v4, v4, v7
	v_add_f32_e32 v7, v10, v4
	v_sub_f32_e32 v10, v7, v10
	v_sub_f32_e32 v4, v4, v10
	v_add_f32_e32 v10, v5, v7
	v_sub_f32_e32 v12, v10, v5
	v_sub_f32_e32 v13, v10, v12
	v_sub_f32_e32 v6, v14, v6
	v_sub_f32_e32 v5, v5, v13
	v_sub_f32_e32 v7, v7, v12
	v_add_f32_e32 v5, v7, v5
	v_add_f32_e32 v7, v6, v4
	v_sub_f32_e32 v12, v7, v6
	v_sub_f32_e32 v13, v7, v12
	v_sub_f32_e32 v6, v6, v13
	v_sub_f32_e32 v4, v4, v12
	v_add_f32_e32 v5, v7, v5
	v_add_f32_e32 v4, v4, v6
	v_add_f32_e32 v6, v10, v5
	v_sub_f32_e32 v7, v6, v10
	v_sub_f32_e32 v5, v5, v7
	v_add_f32_e32 v4, v4, v5
	v_add_f32_e32 v4, v6, v4
	v_cmp_eq_f32_e32 vcc, s43, v3
	v_cndmask_b32_e32 v4, v4, v3, vcc
	v_cmp_ngt_f32_e32 vcc, -1.0, v3
	v_cndmask_b32_e32 v4, v95, v4, vcc
	v_cmp_neq_f32_e32 vcc, -1.0, v3
	v_cndmask_b32_e32 v4, v96, v4, vcc
	v_cmp_lt_f32_e64 vcc, |v3|, s44
	v_cndmask_b32_e32 v3, v4, v3, vcc
.LBB1_19:                               ;   in Loop: Header=BB1_3 Depth=1
	s_lshl_b64 s[8:9], s[6:7], 16
	s_add_u32 s8, s10, s8
	s_addc_u32 s9, s11, s9
	global_load_dword v6, v24, s[8:9]
	global_load_dword v7, v25, s[8:9]
	global_load_dword v10, v26, s[8:9]
	global_load_dword v12, v27, s[8:9]
	global_load_dword v13, v28, s[8:9]
	global_load_dword v15, v29, s[8:9]
	global_load_dword v16, v30, s[8:9]
	global_load_dword v109, v31, s[8:9]
	global_load_dword v110, v32, s[8:9]
	global_load_dword v111, v33, s[8:9]
	global_load_dword v112, v34, s[8:9]
	global_load_dword v125, v35, s[8:9]
	global_load_dword v126, v36, s[8:9]
	global_load_dword v127, v37, s[8:9]
	global_load_dword v142, v38, s[8:9]
	global_load_dword v143, v39, s[8:9]
	global_load_dword v144, v40, s[8:9]
	global_load_dword v145, v41, s[8:9]
	global_load_dword v146, v42, s[8:9]
	global_load_dword v147, v43, s[8:9]
	global_load_dword v152, v44, s[8:9]
	global_load_dword v153, v45, s[8:9]
	global_load_dword v154, v46, s[8:9]
	global_load_dword v155, v47, s[8:9]
	global_load_dword v156, v48, s[8:9]
	global_load_dword v157, v49, s[8:9]
	global_load_dword v158, v50, s[8:9]
	global_load_dword v159, v51, s[8:9]
	global_load_dword v160, v52, s[8:9]
	global_load_dword v161, v53, s[8:9]
	global_load_dword v162, v54, s[8:9]
	global_load_dword v163, v55, s[8:9]
	s_waitcnt vmcnt(32)
	v_mul_f32_e32 v14, v2, v3
	v_mul_f32_e32 v14, 0x3fb8aa3b, v14
	v_exp_f32_e32 v14, v14
	ds_read_b128 v[2:5], v22
	ds_read_b128 v[97:100], v22 offset:16
	ds_read_b128 v[101:104], v22 offset:32
	ds_read_b128 v[105:108], v22 offset:48
	ds_read_b128 v[113:116], v22 offset:64
	ds_read_b128 v[117:120], v22 offset:80
	ds_read_b128 v[121:124], v22 offset:96
	ds_read_b128 v[148:151], v22 offset:112
	global_load_dword v164, v56, s[8:9]
	global_load_dword v165, v57, s[8:9]
	global_load_dword v166, v58, s[8:9]
	global_load_dword v167, v59, s[8:9]
	global_load_dword v168, v60, s[8:9]
	global_load_dword v169, v61, s[8:9]
	global_load_dword v170, v62, s[8:9]
	global_load_dword v171, v63, s[8:9]
	global_load_dword v172, v64, s[8:9]
	global_load_dword v173, v65, s[8:9]
	global_load_dword v174, v66, s[8:9]
	global_load_dword v175, v67, s[8:9]
	global_load_dword v176, v68, s[8:9]
	global_load_dword v177, v69, s[8:9]
	global_load_dword v178, v70, s[8:9]
	global_load_dword v179, v71, s[8:9]
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1
	v_exp_f32_e32 v1, v1
	s_waitcnt vmcnt(47)
	v_mul_f32_e32 v128, v6, v14
	s_waitcnt vmcnt(46)
	v_mul_f32_e32 v129, v14, v7
	s_waitcnt vmcnt(45)
	v_mul_f32_e32 v130, v14, v10
	s_waitcnt vmcnt(44)
	v_mul_f32_e32 v131, v14, v12
	s_waitcnt vmcnt(43)
	v_mul_f32_e32 v132, v14, v13
	s_waitcnt vmcnt(42)
	v_mul_f32_e32 v133, v14, v15
	s_waitcnt vmcnt(41)
	v_mul_f32_e32 v134, v14, v16
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v135, v14, v109
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v136, v14, v110
	s_waitcnt vmcnt(38)
	v_mul_f32_e32 v137, v14, v111
	s_waitcnt vmcnt(37)
	v_mul_f32_e32 v138, v14, v112
	s_waitcnt vmcnt(36)
	v_mul_f32_e32 v139, v14, v125
	s_waitcnt lgkmcnt(7)
	v_fma_f32 v125, v2, v128, 0
	global_load_dword v2, v72, s[8:9]
	global_load_dword v12, v73, s[8:9]
	global_load_dword v16, v74, s[8:9]
	v_fmac_f32_e32 v125, v129, v3
	v_fmac_f32_e32 v125, v130, v4
	v_fmac_f32_e32 v125, v131, v5
	s_waitcnt lgkmcnt(6)
	v_fmac_f32_e32 v125, v132, v97
	global_load_dword v97, v75, s[8:9]
	v_fmac_f32_e32 v125, v133, v98
	v_fmac_f32_e32 v125, v134, v99
	v_fmac_f32_e32 v125, v135, v100
	s_waitcnt lgkmcnt(5)
	v_fmac_f32_e32 v125, v136, v101
	v_fmac_f32_e32 v125, v137, v102
	v_fmac_f32_e32 v125, v138, v103
	global_load_dword v103, v76, s[8:9]
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v140, v14, v126
	v_fmac_f32_e32 v125, v139, v104
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v141, v14, v127
	s_waitcnt lgkmcnt(4)
	v_fmac_f32_e32 v125, v140, v105
	global_load_dword v105, v77, s[8:9]
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v142, v14, v142
	v_fmac_f32_e32 v125, v141, v106
	global_load_dword v106, v78, s[8:9]
	global_load_dword v110, v79, s[8:9]
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v143, v14, v143
	v_fmac_f32_e32 v125, v142, v107
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v144, v14, v144
	v_fmac_f32_e32 v125, v143, v108
	s_waitcnt vmcnt(38)
	v_mul_f32_e32 v145, v14, v145
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v125, v144, v113
	s_waitcnt vmcnt(37)
	v_mul_f32_e32 v146, v14, v146
	v_fmac_f32_e32 v125, v145, v114
	s_waitcnt vmcnt(36)
	v_mul_f32_e32 v147, v14, v147
	v_fmac_f32_e32 v125, v146, v115
	s_waitcnt vmcnt(35)
	v_mul_f32_e32 v109, v14, v152
	v_fmac_f32_e32 v125, v147, v116
	s_waitcnt vmcnt(34)
	v_mul_f32_e32 v180, v14, v153
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v112, v14, v156
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v109, v117
	global_load_dword v156, v80, s[8:9]
	v_mul_f32_e32 v181, v14, v154
	v_fmac_f32_e32 v125, v180, v118
	v_mul_f32_e32 v127, v14, v155
	v_fmac_f32_e32 v125, v181, v119
	v_fmac_f32_e32 v125, v127, v120
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v108, v14, v157
	global_load_dword v157, v81, s[8:9]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v112, v121
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v107, v14, v158
	global_load_dword v158, v82, s[8:9]
	v_fmac_f32_e32 v125, v108, v122
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v104, v14, v159
	global_load_dword v159, v83, s[8:9]
	v_fmac_f32_e32 v125, v107, v123
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v98, v14, v160
	v_fmac_f32_e32 v125, v104, v124
	s_waitcnt vmcnt(30)
	v_mul_f32_e32 v13, v14, v161
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v98, v148
	s_waitcnt vmcnt(29)
	v_mul_f32_e32 v7, v14, v162
	v_fmac_f32_e32 v125, v13, v149
	s_waitcnt vmcnt(28)
	v_mul_f32_e32 v4, v14, v163
	v_fmac_f32_e32 v125, v7, v150
	ds_read_b128 v[99:102], v22 offset:128
	v_fmac_f32_e32 v125, v4, v151
	ds_read_b128 v[148:151], v22 offset:144
	global_load_dword v160, v84, s[8:9]
	global_load_dword v161, v85, s[8:9]
	global_load_dword v162, v86, s[8:9]
	global_load_dword v163, v87, s[8:9]
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v120, v14, v164
	v_add_f32_e32 v164, 1.0, v1
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v120, v99
	s_waitcnt vmcnt(30)
	v_mul_f32_e32 v126, v14, v165
	v_div_scale_f32 v1, s[30:31], v164, v164, 1.0
	v_fmac_f32_e32 v125, v126, v100
	s_waitcnt vmcnt(29)
	v_mul_f32_e32 v124, v14, v166
	v_fmac_f32_e32 v125, v124, v101
	s_waitcnt vmcnt(28)
	v_mul_f32_e32 v123, v14, v167
	v_fmac_f32_e32 v125, v123, v102
	s_waitcnt vmcnt(27)
	v_mul_f32_e32 v118, v14, v168
	ds_read_b128 v[152:155], v22 offset:160
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v118, v148
	s_waitcnt vmcnt(26)
	v_mul_f32_e32 v115, v14, v169
	v_fmac_f32_e32 v125, v115, v149
	s_waitcnt vmcnt(25)
	v_mul_f32_e32 v113, v14, v170
	v_fmac_f32_e32 v125, v113, v150
	s_waitcnt vmcnt(24)
	v_mul_f32_e32 v111, v14, v171
	s_waitcnt vmcnt(14)
	v_mul_f32_e32 v122, v14, v12
	v_div_scale_f32 v12, vcc, 1.0, v164, 1.0
	v_fmac_f32_e32 v125, v111, v151
	ds_read_b128 v[148:151], v22 offset:176
	v_mul_f32_e32 v100, v14, v172
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v100, v152
	v_mul_f32_e32 v101, v14, v173
	v_fmac_f32_e32 v125, v101, v153
	v_mul_f32_e32 v99, v14, v174
	v_fmac_f32_e32 v125, v99, v154
	v_mul_f32_e32 v15, v14, v175
	v_fmac_f32_e32 v125, v15, v155
	v_mul_f32_e32 v10, v14, v176
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v10, v148
	v_mul_f32_e32 v6, v14, v177
	v_fmac_f32_e32 v125, v6, v149
	v_mul_f32_e32 v5, v14, v178
	v_fmac_f32_e32 v125, v5, v150
	v_mul_f32_e32 v3, v14, v179
	v_fmac_f32_e32 v125, v3, v151
	ds_read_b128 v[148:151], v22 offset:192
	ds_read_b128 v[152:155], v22 offset:208
	s_waitcnt vmcnt(12)
	v_mul_f32_e32 v117, v14, v97
	v_rcp_f32_e32 v97, v1
	v_mul_f32_e32 v2, v14, v2
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v2, v148
	v_fmac_f32_e32 v125, v122, v149
	v_fma_f32 v102, -v1, v97, 1.0
	v_mul_f32_e32 v121, v14, v16
	v_fmac_f32_e32 v97, v102, v97
	v_fmac_f32_e32 v125, v121, v150
	v_mul_f32_e32 v102, v12, v97
	v_fmac_f32_e32 v125, v117, v151
	s_waitcnt vmcnt(11)
	v_mul_f32_e32 v119, v14, v103
	v_fma_f32 v103, -v1, v102, v12
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v119, v152
	s_waitcnt vmcnt(10)
	v_mul_f32_e32 v116, v14, v105
	v_fmac_f32_e32 v102, v103, v97
	v_fmac_f32_e32 v125, v116, v153
	s_waitcnt vmcnt(9)
	v_mul_f32_e32 v114, v14, v106
	v_fma_f32 v1, -v1, v102, v12
	v_fmac_f32_e32 v125, v114, v154
	s_waitcnt vmcnt(8)
	v_mul_f32_e32 v110, v14, v110
	s_waitcnt vmcnt(7)
	v_mul_f32_e32 v16, v14, v156
	v_div_fmas_f32 v156, v1, v97, v102
	v_fmac_f32_e32 v125, v110, v155
	ds_read_b128 v[148:151], v22 offset:224
	ds_read_b128 v[152:155], v22 offset:240
	s_waitcnt vmcnt(6)
	v_mul_f32_e32 v106, v14, v157
	s_waitcnt vmcnt(5)
	v_mul_f32_e32 v105, v14, v158
	s_waitcnt vmcnt(4)
	v_mul_f32_e32 v103, v14, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v16, v148
	v_fmac_f32_e32 v125, v106, v149
	v_fmac_f32_e32 v125, v105, v150
	v_fmac_f32_e32 v125, v103, v151
	s_waitcnt vmcnt(3)
	v_mul_f32_e32 v102, v14, v160
	s_waitcnt vmcnt(2)
	v_mul_f32_e32 v97, v14, v161
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v102, v152
	s_waitcnt vmcnt(1)
	v_mul_f32_e32 v12, v14, v162
	v_fmac_f32_e32 v125, v97, v153
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v1, v14, v163
	v_fmac_f32_e32 v125, v12, v154
	v_fmac_f32_e32 v125, v1, v155
	ds_write_b32 v21, v125
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read2st64_b32 v[152:153], v18 offset1:2
	ds_read_b32 v125, v93
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b128 v[148:151], v22
	v_div_fixup_f32 v14, v156, v164, 1.0
	ds_read_b128 v[156:159], v23
	v_add_f32_e32 v152, v152, v153
	v_sub_f32_e32 v125, v125, v152
	v_mul_f32_e32 v14, v14, v125
	ds_read_b128 v[152:155], v22 offset:16
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v128, v14, v148
	v_fmac_f32_e32 v129, v14, v149
	v_fmac_f32_e32 v130, v14, v150
	v_fmac_f32_e32 v131, v14, v151
	ds_read_b128 v[148:151], v23 offset:16
	s_waitcnt lgkmcnt(2)
	v_fma_f32 v125, v128, v156, 0
	v_fmac_f32_e32 v125, v129, v157
	v_fmac_f32_e32 v125, v130, v158
	v_fmac_f32_e32 v125, v131, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v132, v14, v152
	v_fmac_f32_e32 v133, v14, v153
	v_fmac_f32_e32 v134, v14, v154
	v_fmac_f32_e32 v135, v14, v155
	ds_read_b128 v[152:155], v22 offset:32
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v132, v148
	ds_read_b128 v[156:159], v23 offset:32
	v_fmac_f32_e32 v125, v133, v149
	v_fmac_f32_e32 v125, v134, v150
	v_fmac_f32_e32 v125, v135, v151
	ds_read_b128 v[148:151], v22 offset:48
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v136, v14, v152
	v_fmac_f32_e32 v137, v14, v153
	v_fmac_f32_e32 v138, v14, v154
	v_fmac_f32_e32 v139, v14, v155
	ds_read_b128 v[152:155], v23 offset:48
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v136, v156
	v_fmac_f32_e32 v125, v137, v157
	v_fmac_f32_e32 v125, v138, v158
	v_fmac_f32_e32 v125, v139, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v140, v14, v148
	v_fmac_f32_e32 v141, v14, v149
	v_fmac_f32_e32 v142, v14, v150
	v_fmac_f32_e32 v143, v14, v151
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v140, v152
	ds_read_b128 v[148:151], v22 offset:64
	v_fmac_f32_e32 v125, v141, v153
	ds_read_b128 v[156:159], v23 offset:64
	v_fmac_f32_e32 v125, v142, v154
	v_fmac_f32_e32 v125, v143, v155
	ds_read_b128 v[152:155], v22 offset:80
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v144, v14, v148
	v_fmac_f32_e32 v145, v14, v149
	v_fmac_f32_e32 v146, v14, v150
	v_fmac_f32_e32 v147, v14, v151
	ds_read_b128 v[148:151], v23 offset:80
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v144, v156
	v_fmac_f32_e32 v125, v145, v157
	global_store_dword v24, v128, s[8:9]
	global_store_dword v25, v129, s[8:9]
	global_store_dword v26, v130, s[8:9]
	global_store_dword v27, v131, s[8:9]
	global_store_dword v28, v132, s[8:9]
	global_store_dword v29, v133, s[8:9]
	global_store_dword v30, v134, s[8:9]
	global_store_dword v31, v135, s[8:9]
	global_store_dword v32, v136, s[8:9]
	global_store_dword v33, v137, s[8:9]
	global_store_dword v34, v138, s[8:9]
	global_store_dword v35, v139, s[8:9]
	global_store_dword v36, v140, s[8:9]
	global_store_dword v37, v141, s[8:9]
	global_store_dword v38, v142, s[8:9]
	global_store_dword v39, v143, s[8:9]
	global_store_dword v40, v144, s[8:9]
	global_store_dword v41, v145, s[8:9]
	global_store_dword v42, v146, s[8:9]
	global_store_dword v43, v147, s[8:9]
	v_fmac_f32_e32 v125, v146, v158
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v109, v14, v152
	v_fmac_f32_e32 v180, v14, v153
	v_fmac_f32_e32 v181, v14, v154
	v_fmac_f32_e32 v127, v14, v155
	ds_read_b128 v[128:131], v22 offset:96
	v_fmac_f32_e32 v125, v147, v159
	global_store_dword v44, v109, s[8:9]
	global_store_dword v45, v180, s[8:9]
	global_store_dword v46, v181, s[8:9]
	global_store_dword v47, v127, s[8:9]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v109, v148
	ds_read_b128 v[132:135], v23 offset:96
	ds_read_b128 v[136:139], v22 offset:112
	v_fmac_f32_e32 v125, v180, v149
	v_fmac_f32_e32 v125, v181, v150
	v_fmac_f32_e32 v125, v127, v151
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v112, v14, v128
	ds_read_b128 v[140:143], v23 offset:112
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v112, v132
	v_fmac_f32_e32 v108, v14, v129
	v_fmac_f32_e32 v125, v108, v133
	v_fmac_f32_e32 v107, v14, v130
	ds_read_b128 v[127:130], v23 offset:128
	v_fmac_f32_e32 v125, v107, v134
	v_fmac_f32_e32 v104, v14, v131
	ds_read_b128 v[131:134], v22 offset:128
	v_fmac_f32_e32 v125, v104, v135
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v98, v14, v136
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v98, v140
	v_fmac_f32_e32 v13, v14, v137
	v_fmac_f32_e32 v125, v13, v141
	v_fmac_f32_e32 v7, v14, v138
	ds_read_b128 v[135:138], v22 offset:144
	v_fmac_f32_e32 v125, v7, v142
	v_fmac_f32_e32 v4, v14, v139
	v_fmac_f32_e32 v125, v4, v143
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v120, v14, v131
	ds_read_b128 v[139:142], v23 offset:144
	v_fmac_f32_e32 v125, v120, v127
	v_fmac_f32_e32 v126, v14, v132
	v_fmac_f32_e32 v125, v126, v128
	v_fmac_f32_e32 v124, v14, v133
	v_fmac_f32_e32 v123, v14, v134
	global_store_dword v48, v112, s[8:9]
	global_store_dword v49, v108, s[8:9]
	global_store_dword v50, v107, s[8:9]
	global_store_dword v51, v104, s[8:9]
	global_store_dword v52, v98, s[8:9]
	global_store_dword v53, v13, s[8:9]
	global_store_dword v54, v7, s[8:9]
	global_store_dword v55, v4, s[8:9]
	global_store_dword v56, v120, s[8:9]
	global_store_dword v57, v126, s[8:9]
	global_store_dword v58, v124, s[8:9]
	v_fmac_f32_e32 v125, v124, v129
	global_store_dword v59, v123, s[8:9]
	v_fmac_f32_e32 v125, v123, v130
	ds_read_b128 v[126:129], v22 offset:160
	ds_read_b128 v[130:133], v22 offset:176
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v118, v14, v135
	v_fmac_f32_e32 v115, v14, v136
	v_fmac_f32_e32 v113, v14, v137
	ds_read_b128 v[134:137], v23 offset:160
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v125, v118, v139
	v_fmac_f32_e32 v125, v115, v140
	v_fmac_f32_e32 v125, v113, v141
	v_fmac_f32_e32 v111, v14, v138
	ds_read_b128 v[138:141], v23 offset:176
	v_fmac_f32_e32 v125, v111, v142
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v100, v14, v126
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v100, v134
	v_fmac_f32_e32 v101, v14, v127
	v_fmac_f32_e32 v125, v101, v135
	v_fmac_f32_e32 v99, v14, v128
	v_fmac_f32_e32 v125, v99, v136
	v_fmac_f32_e32 v15, v14, v129
	v_fmac_f32_e32 v125, v15, v137
	v_fmac_f32_e32 v10, v14, v130
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v10, v138
	v_fmac_f32_e32 v6, v14, v131
	global_store_dword v60, v118, s[8:9]
	global_store_dword v61, v115, s[8:9]
	global_store_dword v62, v113, s[8:9]
	global_store_dword v63, v111, s[8:9]
	global_store_dword v64, v100, s[8:9]
	global_store_dword v65, v101, s[8:9]
	global_store_dword v66, v99, s[8:9]
	global_store_dword v67, v15, s[8:9]
	global_store_dword v68, v10, s[8:9]
	v_fmac_f32_e32 v125, v6, v139
	v_fmac_f32_e32 v5, v14, v132
	ds_read_b128 v[98:101], v23 offset:192
	ds_read_b128 v[126:129], v23 offset:208
	global_store_dword v69, v6, s[8:9]
	global_store_dword v70, v5, s[8:9]
	v_fmac_f32_e32 v125, v5, v140
	ds_read_b128 v[4:7], v22 offset:192
	v_fmac_f32_e32 v3, v14, v133
	ds_read_b128 v[130:133], v22 offset:208
	v_fmac_f32_e32 v125, v3, v141
	global_store_dword v71, v3, s[8:9]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v2, v14, v4
	v_fmac_f32_e32 v125, v2, v98
	v_fmac_f32_e32 v122, v14, v5
	v_fmac_f32_e32 v125, v122, v99
	v_fmac_f32_e32 v121, v14, v6
	v_fmac_f32_e32 v125, v121, v100
	v_fmac_f32_e32 v117, v14, v7
	v_fmac_f32_e32 v125, v117, v101
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v119, v14, v130
	v_fmac_f32_e32 v125, v119, v126
	v_fmac_f32_e32 v116, v14, v131
	global_store_dword v72, v2, s[8:9]
	v_fmac_f32_e32 v125, v116, v127
	v_fmac_f32_e32 v114, v14, v132
	v_fmac_f32_e32 v110, v14, v133
	ds_read_b128 v[2:5], v22 offset:224
	global_store_dword v73, v122, s[8:9]
	global_store_dword v74, v121, s[8:9]
	global_store_dword v75, v117, s[8:9]
	global_store_dword v76, v119, s[8:9]
	global_store_dword v77, v116, s[8:9]
	global_store_dword v78, v114, s[8:9]
	v_fmac_f32_e32 v125, v114, v128
	global_store_dword v79, v110, s[8:9]
	v_fmac_f32_e32 v125, v110, v129
	ds_read_b128 v[98:101], v23 offset:224
	ds_read_b128 v[107:110], v22 offset:240
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v16, v14, v2
	ds_read_b128 v[111:114], v23 offset:240
	v_fmac_f32_e32 v106, v14, v3
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v16, v98
	v_fmac_f32_e32 v125, v106, v99
	v_fmac_f32_e32 v105, v14, v4
	v_fmac_f32_e32 v125, v105, v100
	v_fmac_f32_e32 v103, v14, v5
	v_fmac_f32_e32 v125, v103, v101
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v102, v14, v107
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v102, v111
	v_fmac_f32_e32 v97, v14, v108
	v_fmac_f32_e32 v125, v97, v112
	v_fmac_f32_e32 v12, v14, v109
	v_fmac_f32_e32 v125, v12, v113
	v_fmac_f32_e32 v1, v14, v110
	global_store_dword v87, v1, s[8:9]
	v_fmac_f32_e32 v125, v1, v114
	v_mov_b32_e32 v1, 0
	global_store_dword v80, v16, s[8:9]
	global_store_dword v81, v106, s[8:9]
	global_store_dword v82, v105, s[8:9]
	global_store_dword v83, v103, s[8:9]
	global_store_dword v84, v102, s[8:9]
	global_store_dword v85, v97, s[8:9]
	global_store_dword v86, v12, s[8:9]
	ds_write_b32 v21, v125
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB1_21
; %bb.20:                               ;   in Loop: Header=BB1_3 Depth=1
	ds_read2st64_b32 v[1:2], v19 offset1:2
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v1, v1, v2
.LBB1_21:                               ;   in Loop: Header=BB1_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_mul_f32_e32 v2, v1, v1
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	v_fmac_f32_e32 v3, v1, v1
	s_nop 1
	v_add_f32_dpp v2, v3, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v3, 0
	s_nop 0
	v_add_f32_dpp v2, v2, v2 row_half_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:15 row_mask:0xa bank_mask:0xf
	v_add_f32_e32 v2, v2, v3
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[2:3]
	s_cbranch_execz .LBB1_23
; %bb.22:                               ;   in Loop: Header=BB1_3 Depth=1
	v_add_f32_e32 v2, v2, v3
	ds_write_b32 v20, v2
.LBB1_23:                               ;   in Loop: Header=BB1_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB1_2
; %bb.24:                               ;   in Loop: Header=BB1_3 Depth=1
	v_add_u32_e32 v10, s37, v0
	v_lshlrev_b64 v[2:3], 2, v[10:11]
	v_mov_b32_e32 v4, s15
	v_add_co_u32_e32 v2, vcc, s14, v2
	v_addc_co_u32_e32 v3, vcc, v4, v3, vcc
	global_load_dword v4, v[2:3], off
	global_load_dword v5, v[8:9], off
	s_waitcnt vmcnt(1)
	v_mul_f32_e32 v2, 0xbfb8aa3b, v4
	v_exp_f32_e32 v2, v2
	v_add_f32_e32 v6, 1.0, v2
	v_div_scale_f32 v7, s[30:31], v6, v6, v4
	v_div_scale_f32 v12, vcc, v4, v6, v4
	ds_read_b64 v[2:3], v11 offset:2560
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_rcp_f32_e32 v13, v7
	v_fma_f32 v14, -v7, v13, 1.0
	v_fmac_f32_e32 v13, v14, v13
	v_mul_f32_e32 v14, v12, v13
	v_fma_f32 v15, -v7, v14, v12
	v_fmac_f32_e32 v14, v15, v13
	v_fma_f32 v7, -v7, v14, v12
	v_div_fmas_f32 v7, v7, v13, v14
	v_mov_b32_e32 v12, s33
	v_fmac_f32_e32 v12, 0x3c000000, v2
	v_mul_f32_e32 v2, 0x4b800000, v12
	v_cmp_gt_f32_e32 vcc, s39, v12
	v_cndmask_b32_e32 v2, v12, v2, vcc
	v_rsq_f32_e32 v12, v2
	v_lshlrev_b64 v[2:3], 1, v[10:11]
	v_mov_b32_e32 v13, s35
	v_mul_f32_e32 v10, 0x45800000, v12
	v_cndmask_b32_e32 v10, v12, v10, vcc
	v_mul_f32_e32 v1, v1, v10
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v1, v5, v1
	v_div_fixup_f32 v4, v7, v6, v4
	v_fma_mixlo_f16 v4, v4, v1, 0
	v_add_co_u32_e32 v1, vcc, s34, v2
	v_addc_co_u32_e32 v2, vcc, v13, v3, vcc
	global_store_short v[1:2], v4, off
	s_branch .LBB1_2
.LBB1_25:
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel live_step
		.amdhsa_group_segment_fixed_size 2576
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 368
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 182
		.amdhsa_next_free_sgpr 50
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end1:
	.size	live_step, .Lfunc_end1-live_step
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 6196
; NumSgprs: 54
; NumVgprs: 182
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 2576 bytes/workgroup (compile time only)
; SGPRBlocks: 6
; VGPRBlocks: 45
; NumSGPRsForWavesPerEU: 54
; NumVGPRsForWavesPerEU: 182
; Occupancy: 1
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.text
	.protected	register_step           ; -- Begin function register_step
	.globl	register_step
	.p2align	8
	.type	register_step,@function
register_step:                          ; @register_step
; %bb.0:
	s_cmp_gt_u32 s6, 31
	s_cbranch_scc1 .LBB2_25
; %bb.1:
	v_and_b32_e32 v2, 63, v0
	v_and_b32_e32 v17, 0x7f, v0
	v_lshrrev_b32_e32 v1, 7, v0
	v_cmp_eq_u32_e64 s[2:3], 63, v2
	v_lshrrev_b32_e32 v2, 4, v0
	v_mov_b32_e32 v3, 0xa00
	s_load_dwordx16 s[12:27], s[4:5], 0x0
	s_load_dwordx4 s[28:31], s[4:5], 0x40
	s_load_dwordx2 s[10:11], s[4:5], 0x50
	s_load_dword s33, s[4:5], 0x60
	s_load_dwordx2 s[34:35], s[4:5], 0x68
	v_lshlrev_b32_e32 v18, 2, v17
	v_and_or_b32 v20, v2, 12, v3
	v_lshlrev_b32_e32 v2, 13, v1
	v_rsq_f32_e32 v92, 0x43000000
	s_movk_i32 s8, 0x80
	v_lshlrev_b32_e32 v19, 2, v0
	v_lshl_or_b32 v21, v1, 9, v18
	s_add_u32 s36, s4, 0x70
	v_or_b32_e32 v3, v2, v17
	v_lshlrev_b32_e32 v1, 8, v1
	v_or_b32_e32 v2, v2, v0
	s_movk_i32 s0, 0x7f
	s_addc_u32 s37, s5, 0
	v_or_b32_e32 v4, 0x80, v2
	v_or_b32_e32 v5, 0x180, v2
	v_or_b32_e32 v6, 0x280, v2
	v_or_b32_e32 v7, 0x380, v2
	v_or_b32_e32 v10, 0x480, v2
	v_or_b32_e32 v11, 0x580, v2
	v_or_b32_e32 v12, 0x680, v2
	v_or_b32_e32 v13, 0x780, v2
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v9, s31
	v_add_co_u32_e32 v8, vcc, s30, v19
	v_or_b32_e32 v14, 0x880, v2
	v_or_b32_e32 v15, 0x980, v2
	v_or_b32_e32 v16, 0xa80, v2
	v_or_b32_e32 v47, 0xb80, v2
	v_or_b32_e32 v49, 0xc80, v2
	v_or_b32_e32 v51, 0xd80, v2
	v_or_b32_e32 v53, 0xe80, v2
	v_or_b32_e32 v55, 0xf80, v2
	v_or_b32_e32 v57, 0x1080, v2
	v_or_b32_e32 v59, 0x1180, v2
	v_or_b32_e32 v61, 0x1280, v2
	v_or_b32_e32 v63, 0x1380, v2
	v_or_b32_e32 v65, 0x1480, v2
	v_or_b32_e32 v67, 0x1580, v2
	v_or_b32_e32 v69, 0x1680, v2
	v_or_b32_e32 v71, 0x1780, v2
	v_or_b32_e32 v73, 0x1880, v2
	v_or_b32_e32 v75, 0x1980, v2
	v_or_b32_e32 v77, 0x1a80, v2
	v_or_b32_e32 v79, 0x1b80, v2
	v_or_b32_e32 v81, 0x1c80, v2
	v_or_b32_e32 v83, 0x1d80, v2
	v_or_b32_e32 v85, 0x1e80, v2
	v_or_b32_e32 v2, 0x1f80, v2
	v_or_b32_e32 v22, 0x400, v1
	v_or_b32_e32 v23, 0x600, v1
	v_or_b32_e32 v1, 0x100, v3
	v_or_b32_e32 v28, 0x200, v3
	v_or_b32_e32 v30, 0x300, v3
	v_or_b32_e32 v32, 0x400, v3
	v_or_b32_e32 v34, 0x500, v3
	v_or_b32_e32 v36, 0x600, v3
	v_or_b32_e32 v38, 0x700, v3
	v_or_b32_e32 v40, 0x800, v3
	v_or_b32_e32 v42, 0x900, v3
	v_or_b32_e32 v44, 0xa00, v3
	v_or_b32_e32 v46, 0xb00, v3
	v_or_b32_e32 v48, 0xc00, v3
	v_or_b32_e32 v50, 0xd00, v3
	v_or_b32_e32 v52, 0xe00, v3
	v_or_b32_e32 v54, 0xf00, v3
	v_or_b32_e32 v56, 0x1000, v3
	v_or_b32_e32 v58, 0x1100, v3
	v_or_b32_e32 v60, 0x1200, v3
	v_or_b32_e32 v62, 0x1300, v3
	v_or_b32_e32 v64, 0x1400, v3
	v_or_b32_e32 v66, 0x1500, v3
	v_or_b32_e32 v68, 0x1600, v3
	v_or_b32_e32 v70, 0x1700, v3
	v_or_b32_e32 v72, 0x1800, v3
	v_or_b32_e32 v74, 0x1900, v3
	v_or_b32_e32 v76, 0x1a00, v3
	v_or_b32_e32 v78, 0x1b00, v3
	v_or_b32_e32 v80, 0x1c00, v3
	v_or_b32_e32 v82, 0x1d00, v3
	v_or_b32_e32 v84, 0x1e00, v3
	v_or_b32_e32 v86, 0x1f00, v3
	v_or_b32_e32 v88, 0x400, v18
	v_add_u32_e32 v89, 0x600, v19
	v_cmp_gt_u32_e64 s[4:5], s8, v0
	v_cmp_lt_u32_e64 s[0:1], s0, v0
	s_mov_b32 s7, 0
	v_addc_co_u32_e32 v9, vcc, 0, v9, vcc
	s_mov_b32 s38, 0x800000
	s_mov_b32 s39, 0x41a00000
	s_mov_b32 s40, 0x3f2aaaab
	s_mov_b32 s41, 0x3f317218
	s_mov_b32 s42, 0x7f800000
	s_mov_b32 s43, 0x33800000
	v_lshlrev_b32_e32 v24, 2, v3
	v_lshlrev_b32_e32 v25, 2, v4
	v_lshlrev_b32_e32 v26, 2, v1
	v_lshlrev_b32_e32 v27, 2, v5
	v_lshlrev_b32_e32 v28, 2, v28
	v_lshlrev_b32_e32 v29, 2, v6
	v_lshlrev_b32_e32 v30, 2, v30
	v_lshlrev_b32_e32 v31, 2, v7
	v_lshlrev_b32_e32 v32, 2, v32
	v_lshlrev_b32_e32 v33, 2, v10
	v_lshlrev_b32_e32 v34, 2, v34
	v_lshlrev_b32_e32 v35, 2, v11
	v_lshlrev_b32_e32 v36, 2, v36
	v_lshlrev_b32_e32 v37, 2, v12
	v_lshlrev_b32_e32 v38, 2, v38
	v_lshlrev_b32_e32 v39, 2, v13
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v41, 2, v14
	v_lshlrev_b32_e32 v42, 2, v42
	v_lshlrev_b32_e32 v43, 2, v15
	v_lshlrev_b32_e32 v44, 2, v44
	v_lshlrev_b32_e32 v45, 2, v16
	v_lshlrev_b32_e32 v46, 2, v46
	v_lshlrev_b32_e32 v47, 2, v47
	v_lshlrev_b32_e32 v48, 2, v48
	v_lshlrev_b32_e32 v49, 2, v49
	v_lshlrev_b32_e32 v50, 2, v50
	v_lshlrev_b32_e32 v51, 2, v51
	v_lshlrev_b32_e32 v52, 2, v52
	v_lshlrev_b32_e32 v53, 2, v53
	v_lshlrev_b32_e32 v54, 2, v54
	v_lshlrev_b32_e32 v55, 2, v55
	v_lshlrev_b32_e32 v56, 2, v56
	v_lshlrev_b32_e32 v57, 2, v57
	v_lshlrev_b32_e32 v58, 2, v58
	v_lshlrev_b32_e32 v59, 2, v59
	v_lshlrev_b32_e32 v60, 2, v60
	v_lshlrev_b32_e32 v61, 2, v61
	v_lshlrev_b32_e32 v62, 2, v62
	v_lshlrev_b32_e32 v63, 2, v63
	v_lshlrev_b32_e32 v64, 2, v64
	v_lshlrev_b32_e32 v65, 2, v65
	v_lshlrev_b32_e32 v66, 2, v66
	v_lshlrev_b32_e32 v67, 2, v67
	v_lshlrev_b32_e32 v68, 2, v68
	v_lshlrev_b32_e32 v69, 2, v69
	v_lshlrev_b32_e32 v70, 2, v70
	v_lshlrev_b32_e32 v71, 2, v71
	v_lshlrev_b32_e32 v72, 2, v72
	v_lshlrev_b32_e32 v73, 2, v73
	v_lshlrev_b32_e32 v74, 2, v74
	v_lshlrev_b32_e32 v75, 2, v75
	v_lshlrev_b32_e32 v76, 2, v76
	v_lshlrev_b32_e32 v77, 2, v77
	v_lshlrev_b32_e32 v78, 2, v78
	v_lshlrev_b32_e32 v79, 2, v79
	v_lshlrev_b32_e32 v80, 2, v80
	v_lshlrev_b32_e32 v81, 2, v81
	v_lshlrev_b32_e32 v82, 2, v82
	v_lshlrev_b32_e32 v83, 2, v83
	v_lshlrev_b32_e32 v84, 2, v84
	v_lshlrev_b32_e32 v85, 2, v85
	v_lshlrev_b32_e32 v86, 2, v86
	v_lshlrev_b32_e32 v87, 2, v2
	v_or_b32_e32 v90, 0x800, v19
	v_cndmask_b32_e64 v91, v88, v89, s[4:5]
	v_or_b32_e32 v93, 0x800, v18
	v_mov_b32_e32 v94, 0x3f2aaada
	v_mov_b32_e32 v95, 0x7fc00000
	v_mov_b32_e32 v96, 0xff800000
	v_mov_b32_e32 v11, 0
	s_branch .LBB2_3
.LBB2_2:                                ;   in Loop: Header=BB2_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt vmcnt(0)
	s_barrier
	s_load_dword s8, s[36:37], 0x0
	s_waitcnt lgkmcnt(0)
	s_add_i32 s6, s8, s6
	s_cmp_lt_u32 s6, 32
	s_cbranch_scc0 .LBB2_25
.LBB2_3:                                ; =>This Inner Loop Header: Depth=1
	s_cmp_lt_u32 s6, 16
	s_cselect_b64 s[8:9], -1, 0
	v_cndmask_b32_e64 v1, 0, 1, s[8:9]
	s_lshl_b32 s44, s6, 7
	v_cmp_ne_u32_e64 s[8:9], 1, v1
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b64 s[30:31], s[0:1]
	s_xor_b64 s[30:31], exec, s[30:31]
	s_cbranch_execz .LBB2_7
; %bb.4:                                ;   in Loop: Header=BB2_3 Depth=1
	v_or_b32_e32 v1, s44, v17
	v_or_b32_e32 v1, 0x800, v1
	v_lshl_add_u32 v10, v1, 1, v1
	v_lshlrev_b64 v[14:15], 2, v[10:11]
	v_mov_b32_e32 v2, s23
	v_add_co_u32_e32 v12, vcc, s22, v14
	v_lshlrev_b32_e32 v10, 2, v1
	v_addc_co_u32_e32 v13, vcc, v2, v15, vcc
	v_lshlrev_b64 v[2:3], 2, v[10:11]
	v_mov_b32_e32 v4, s21
	v_add_co_u32_e32 v97, vcc, s20, v2
	v_mov_b32_e32 v2, v11
	v_lshlrev_b64 v[1:2], 2, v[1:2]
	v_addc_co_u32_e32 v98, vcc, v4, v3, vcc
	v_mov_b32_e32 v3, s13
	v_add_co_u32_e32 v99, vcc, s12, v1
	v_addc_co_u32_e32 v100, vcc, v3, v2, vcc
	global_load_dword v16, v[99:100], off
	global_load_dwordx4 v[1:4], v[97:98], off
	global_load_dwordx3 v[5:7], v[12:13], off
	s_and_b64 vcc, exec, s[8:9]
	s_cbranch_vccnz .LBB2_6
; %bb.5:                                ;   in Loop: Header=BB2_3 Depth=1
	v_mov_b32_e32 v10, s25
	v_add_co_u32_e32 v97, vcc, s24, v14
	v_addc_co_u32_e32 v98, vcc, v10, v15, vcc
	s_waitcnt vmcnt(0)
	global_store_dword v[97:98], v6, off
	global_load_dword v15, v[12:13], off offset:8
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v[97:98], v[15:16], off offset:4
.LBB2_6:                                ;   in Loop: Header=BB2_3 Depth=1
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v2, v2, v6
	v_fmac_f32_e32 v2, v1, v5
	v_fmac_f32_e32 v2, v3, v7
	v_fmac_f32_e32 v2, v16, v4
.LBB2_7:                                ;   in Loop: Header=BB2_3 Depth=1
	s_or_saveexec_b64 s[30:31], s[30:31]
	v_mov_b32_e32 v1, v88
	s_xor_b64 exec, exec, s[30:31]
	s_cbranch_execz .LBB2_11
; %bb.8:                                ;   in Loop: Header=BB2_3 Depth=1
	s_and_b32 s45, s44, 0x780
	v_or_b32_e32 v1, s45, v0
	v_mul_u32_u24_e32 v2, 3, v1
	v_lshlrev_b32_e32 v12, 2, v1
	v_lshlrev_b32_e32 v10, 2, v2
	v_lshlrev_b32_e32 v14, 4, v1
	global_load_dword v13, v12, s[12:13]
	global_load_dwordx4 v[1:4], v14, s[20:21]
	global_load_dwordx3 v[5:7], v10, s[22:23]
	s_and_b64 vcc, exec, s[8:9]
	s_cbranch_vccnz .LBB2_10
; %bb.9:                                ;   in Loop: Header=BB2_3 Depth=1
	v_mov_b32_e32 v12, s23
	v_add_co_u32_e32 v14, vcc, s22, v10
	v_addc_co_u32_e32 v15, vcc, 0, v12, vcc
	s_waitcnt vmcnt(0)
	global_store_dword v10, v6, s[24:25]
	global_load_dword v12, v[14:15], off offset:8
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v10, v[12:13], s[24:25] offset:4
.LBB2_10:                               ;   in Loop: Header=BB2_3 Depth=1
	v_or_b32_e32 v10, s44, v0
	v_or_b32_e32 v97, 0x1000, v10
	v_lshl_add_u32 v10, v97, 1, v97
	v_lshlrev_b64 v[101:102], 2, v[10:11]
	v_mov_b32_e32 v10, s23
	v_add_co_u32_e32 v103, vcc, s22, v101
	v_addc_co_u32_e32 v104, vcc, v10, v102, vcc
	global_load_dwordx3 v[14:16], v[103:104], off
	v_mov_b32_e32 v98, v11
	v_lshlrev_b64 v[98:99], 2, v[97:98]
	v_lshlrev_b32_e32 v10, 2, v97
	v_mov_b32_e32 v100, s13
	v_lshlrev_b64 v[105:106], 2, v[10:11]
	v_add_co_u32_e32 v97, vcc, s12, v98
	v_addc_co_u32_e32 v98, vcc, v100, v99, vcc
	v_mov_b32_e32 v12, s21
	global_load_dword v107, v[97:98], off
	v_add_co_u32_e32 v97, vcc, s20, v105
	v_addc_co_u32_e32 v98, vcc, v12, v106, vcc
	global_load_dwordx4 v[97:100], v[97:98], off
	v_mov_b32_e32 v108, s25
	v_add_co_u32_e32 v101, vcc, s24, v101
	v_addc_co_u32_e32 v102, vcc, v108, v102, vcc
	s_waitcnt vmcnt(3)
	v_mul_f32_e32 v2, v2, v6
	v_fmac_f32_e32 v2, v1, v5
	v_fmac_f32_e32 v2, v3, v7
	v_fmac_f32_e32 v2, v13, v4
	v_mul_f32_e32 v1, 0xbfb8aa3b, v2
	v_exp_f32_e32 v1, v1
	v_add_f32_e32 v1, 1.0, v1
	v_div_scale_f32 v3, s[8:9], v1, v1, v2
	v_div_scale_f32 v4, vcc, v2, v1, v2
	v_rcp_f32_e32 v5, v3
	v_fma_f32 v6, -v3, v5, 1.0
	v_fmac_f32_e32 v5, v6, v5
	v_mul_f32_e32 v6, v4, v5
	v_fma_f32 v7, -v3, v6, v4
	v_fmac_f32_e32 v6, v7, v5
	v_fma_f32 v3, -v3, v6, v4
	v_div_fmas_f32 v3, v3, v5, v6
	v_div_fixup_f32 v1, v3, v1, v2
	ds_write_b32 v89, v1
	v_mov_b32_e32 v1, v90
	s_waitcnt vmcnt(2)
	global_store_dword v[101:102], v15, off
	global_load_dword v106, v[103:104], off offset:8
	s_waitcnt vmcnt(2)
	v_mul_f32_e32 v2, v98, v15
	v_fmac_f32_e32 v2, v97, v14
	v_fmac_f32_e32 v2, v99, v16
	v_fmac_f32_e32 v2, v107, v100
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v[101:102], v[106:107], off offset:4
.LBB2_11:                               ;   in Loop: Header=BB2_3 Depth=1
	s_or_b64 exec, exec, s[30:31]
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2
	v_exp_f32_e32 v3, v3
	v_add_f32_e32 v3, 1.0, v3
	v_div_scale_f32 v4, s[8:9], v3, v3, v2
	v_div_scale_f32 v5, vcc, v2, v3, v2
	v_rcp_f32_e32 v6, v4
	v_fma_f32 v7, -v4, v6, 1.0
	v_fmac_f32_e32 v6, v7, v6
	v_mul_f32_e32 v7, v5, v6
	v_fma_f32 v10, -v4, v7, v5
	v_fmac_f32_e32 v7, v10, v6
	v_fma_f32 v4, -v4, v7, v5
	v_div_fmas_f32 v4, v4, v6, v7
	v_div_fixup_f32 v2, v4, v3, v2
	ds_write_b32 v1, v2
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	ds_read_b32 v1, v91
	v_mov_b32_e32 v2, v11
	v_mov_b32_e32 v3, v11
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v4, v1, v1
	s_nop 1
	v_mov_b32_dpp v2, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	v_fmac_f32_e32 v2, v1, v1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_half_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:15 row_mask:0xa bank_mask:0xf
	v_add_f32_e32 v2, v2, v3
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[2:3]
	s_cbranch_execz .LBB2_13
; %bb.12:                               ;   in Loop: Header=BB2_3 Depth=1
	v_add_f32_e32 v2, v2, v3
	ds_write_b32 v20, v2
.LBB2_13:                               ;   in Loop: Header=BB2_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], s[0:1]
	s_xor_b64 s[8:9], exec, s[8:9]
	s_cbranch_execz .LBB2_15
; %bb.14:                               ;   in Loop: Header=BB2_3 Depth=1
	ds_read_b64 v[2:3], v11 offset:2568
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v2, 0x358637bd, v2
	v_mul_f32_e32 v3, 0x4b800000, v2
	v_cmp_gt_f32_e32 vcc, s38, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_rsq_f32_e32 v2, v2
	v_mul_f32_e32 v3, 0x45800000, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_mul_f32_e32 v1, v1, v2
	ds_write_b32 v88, v1
                                        ; implicit-def: $vgpr1
.LBB2_15:                               ;   in Loop: Header=BB2_3 Depth=1
	s_andn2_saveexec_b64 s[8:9], s[8:9]
	s_cbranch_execz .LBB2_17
; %bb.16:                               ;   in Loop: Header=BB2_3 Depth=1
	ds_read_b64 v[2:3], v11 offset:2560
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v2, 0x358637bd, v2
	v_mul_f32_e32 v3, 0x4b800000, v2
	v_cmp_gt_f32_e32 vcc, s38, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_rsq_f32_e32 v2, v2
	v_mul_f32_e32 v3, 0x45800000, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_mul_f32_e32 v1, v1, v2
	v_mul_f32_e32 v1, v92, v1
	ds_write_b32 v89, v1
.LBB2_17:                               ;   in Loop: Header=BB2_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_lshl_b64 s[8:9], s[6:7], 2
	s_add_u32 s30, s18, s8
	s_addc_u32 s31, s19, s9
	s_add_u32 s46, s26, s8
	s_addc_u32 s47, s27, s9
	s_add_u32 s48, s16, s8
	s_addc_u32 s49, s17, s9
	s_add_u32 s8, s28, s8
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_addc_u32 s9, s29, s9
	global_load_dword v3, v11, s[48:49]
	global_load_dword v4, v11, s[8:9]
	global_load_dword v1, v11, s[30:31]
	global_load_dword v2, v11, s[46:47]
	s_waitcnt vmcnt(2)
	v_add_f32_e32 v3, v3, v4
	v_cmp_lt_f32_e32 vcc, s39, v3
	s_cbranch_vccnz .LBB2_19
; %bb.18:                               ;   in Loop: Header=BB2_3 Depth=1
	v_mul_f32_e32 v3, 0x3fb8aa3b, v3
	v_exp_f32_e32 v3, v3
	v_add_f32_e32 v4, 1.0, v3
	v_frexp_mant_f32_e32 v6, v4
	v_add_f32_e32 v5, -1.0, v4
	v_frexp_exp_i32_f32_e32 v7, v4
	v_cmp_gt_f32_e32 vcc, s40, v6
	v_sub_f32_e32 v10, v5, v4
	v_subbrev_co_u32_e32 v6, vcc, 0, v7, vcc
	v_sub_f32_e32 v5, v3, v5
	v_add_f32_e32 v10, 1.0, v10
	v_sub_u32_e32 v7, 0, v6
	v_add_f32_e32 v5, v5, v10
	v_ldexp_f32 v4, v4, v7
	v_ldexp_f32 v5, v5, v7
	v_add_f32_e32 v7, -1.0, v4
	v_add_f32_e32 v13, 1.0, v4
	v_add_f32_e32 v10, 1.0, v7
	v_add_f32_e32 v14, -1.0, v13
	v_sub_f32_e32 v10, v4, v10
	v_sub_f32_e32 v4, v4, v14
	v_add_f32_e32 v4, v5, v4
	v_add_f32_e32 v10, v5, v10
	v_add_f32_e32 v5, v13, v4
	v_rcp_f32_e32 v14, v5
	v_add_f32_e32 v12, v7, v10
	v_sub_f32_e32 v7, v12, v7
	v_sub_f32_e32 v7, v10, v7
	v_sub_f32_e32 v10, v5, v13
	v_sub_f32_e32 v4, v4, v10
	v_mul_f32_e32 v10, v12, v14
	v_mul_f32_e32 v13, v5, v10
	v_fma_f32 v15, v10, v5, -v13
	v_fmac_f32_e32 v15, v10, v4
	v_add_f32_e32 v16, v13, v15
	v_sub_f32_e32 v97, v12, v16
	v_sub_f32_e32 v12, v12, v97
	v_sub_f32_e32 v13, v16, v13
	v_sub_f32_e32 v12, v12, v16
	v_add_f32_e32 v7, v7, v12
	v_sub_f32_e32 v12, v13, v15
	v_add_f32_e32 v7, v12, v7
	v_add_f32_e32 v12, v97, v7
	v_mul_f32_e32 v13, v14, v12
	v_mul_f32_e32 v15, v5, v13
	v_fma_f32 v5, v13, v5, -v15
	v_fmac_f32_e32 v5, v13, v4
	v_sub_f32_e32 v4, v97, v12
	v_add_f32_e32 v4, v7, v4
	v_add_f32_e32 v7, v15, v5
	v_sub_f32_e32 v16, v12, v7
	v_sub_f32_e32 v12, v12, v16
	v_sub_f32_e32 v15, v7, v15
	v_sub_f32_e32 v7, v12, v7
	v_add_f32_e32 v4, v4, v7
	v_sub_f32_e32 v5, v15, v5
	v_cvt_f32_i32_e32 v6, v6
	v_add_f32_e32 v4, v5, v4
	v_add_f32_e32 v5, v10, v13
	v_add_f32_e32 v4, v16, v4
	v_sub_f32_e32 v7, v5, v10
	v_mul_f32_e32 v4, v14, v4
	v_sub_f32_e32 v7, v13, v7
	v_add_f32_e32 v4, v7, v4
	v_mul_f32_e32 v13, 0x3f317218, v6
	v_add_f32_e32 v7, v5, v4
	v_fma_f32 v14, v6, s41, -v13
	v_mul_f32_e32 v10, v7, v7
	v_mov_b32_e32 v12, 0x3ecc95a3
	v_fmac_f32_e32 v14, 0xb102e308, v6
	v_sub_f32_e32 v5, v7, v5
	v_fmac_f32_e32 v12, 0x3e9b6dac, v10
	v_sub_f32_e32 v4, v4, v5
	v_add_f32_e32 v5, v13, v14
	v_fma_f32 v12, v10, v12, v94
	v_sub_f32_e32 v6, v5, v13
	v_ldexp_f32 v13, v7, 1
	v_mul_f32_e32 v7, v7, v10
	v_mul_f32_e32 v7, v7, v12
	v_add_f32_e32 v10, v13, v7
	v_sub_f32_e32 v12, v10, v13
	v_ldexp_f32 v4, v4, 1
	v_sub_f32_e32 v7, v7, v12
	v_add_f32_e32 v4, v4, v7
	v_add_f32_e32 v7, v10, v4
	v_sub_f32_e32 v10, v7, v10
	v_sub_f32_e32 v4, v4, v10
	v_add_f32_e32 v10, v5, v7
	v_sub_f32_e32 v12, v10, v5
	v_sub_f32_e32 v13, v10, v12
	v_sub_f32_e32 v6, v14, v6
	v_sub_f32_e32 v5, v5, v13
	v_sub_f32_e32 v7, v7, v12
	v_add_f32_e32 v5, v7, v5
	v_add_f32_e32 v7, v6, v4
	v_sub_f32_e32 v12, v7, v6
	v_sub_f32_e32 v13, v7, v12
	v_sub_f32_e32 v6, v6, v13
	v_sub_f32_e32 v4, v4, v12
	v_add_f32_e32 v5, v7, v5
	v_add_f32_e32 v4, v4, v6
	v_add_f32_e32 v6, v10, v5
	v_sub_f32_e32 v7, v6, v10
	v_sub_f32_e32 v5, v5, v7
	v_add_f32_e32 v4, v4, v5
	v_add_f32_e32 v4, v6, v4
	v_cmp_eq_f32_e32 vcc, s42, v3
	v_cndmask_b32_e32 v4, v4, v3, vcc
	v_cmp_ngt_f32_e32 vcc, -1.0, v3
	v_cndmask_b32_e32 v4, v95, v4, vcc
	v_cmp_neq_f32_e32 vcc, -1.0, v3
	v_cndmask_b32_e32 v4, v96, v4, vcc
	v_cmp_lt_f32_e64 vcc, |v3|, s43
	v_cndmask_b32_e32 v3, v4, v3, vcc
.LBB2_19:                               ;   in Loop: Header=BB2_3 Depth=1
	s_lshl_b64 s[8:9], s[6:7], 16
	s_add_u32 s8, s10, s8
	s_addc_u32 s9, s11, s9
	global_load_dword v6, v24, s[8:9]
	global_load_dword v7, v25, s[8:9]
	global_load_dword v10, v26, s[8:9]
	global_load_dword v12, v27, s[8:9]
	global_load_dword v13, v28, s[8:9]
	global_load_dword v15, v29, s[8:9]
	global_load_dword v16, v30, s[8:9]
	global_load_dword v109, v31, s[8:9]
	global_load_dword v110, v32, s[8:9]
	global_load_dword v111, v33, s[8:9]
	global_load_dword v112, v34, s[8:9]
	global_load_dword v125, v35, s[8:9]
	global_load_dword v126, v36, s[8:9]
	global_load_dword v127, v37, s[8:9]
	global_load_dword v142, v38, s[8:9]
	global_load_dword v143, v39, s[8:9]
	global_load_dword v144, v40, s[8:9]
	global_load_dword v145, v41, s[8:9]
	global_load_dword v146, v42, s[8:9]
	global_load_dword v147, v43, s[8:9]
	global_load_dword v152, v44, s[8:9]
	global_load_dword v153, v45, s[8:9]
	global_load_dword v154, v46, s[8:9]
	global_load_dword v155, v47, s[8:9]
	global_load_dword v156, v48, s[8:9]
	global_load_dword v157, v49, s[8:9]
	global_load_dword v158, v50, s[8:9]
	global_load_dword v159, v51, s[8:9]
	global_load_dword v160, v52, s[8:9]
	global_load_dword v161, v53, s[8:9]
	global_load_dword v162, v54, s[8:9]
	global_load_dword v163, v55, s[8:9]
	s_waitcnt vmcnt(32)
	v_mul_f32_e32 v14, v2, v3
	v_mul_f32_e32 v14, 0x3fb8aa3b, v14
	v_exp_f32_e32 v14, v14
	ds_read_b128 v[2:5], v22
	ds_read_b128 v[97:100], v22 offset:16
	ds_read_b128 v[101:104], v22 offset:32
	ds_read_b128 v[105:108], v22 offset:48
	ds_read_b128 v[113:116], v22 offset:64
	ds_read_b128 v[117:120], v22 offset:80
	ds_read_b128 v[121:124], v22 offset:96
	ds_read_b128 v[148:151], v22 offset:112
	global_load_dword v164, v56, s[8:9]
	global_load_dword v165, v57, s[8:9]
	global_load_dword v166, v58, s[8:9]
	global_load_dword v167, v59, s[8:9]
	global_load_dword v168, v60, s[8:9]
	global_load_dword v169, v61, s[8:9]
	global_load_dword v170, v62, s[8:9]
	global_load_dword v171, v63, s[8:9]
	global_load_dword v172, v64, s[8:9]
	global_load_dword v173, v65, s[8:9]
	global_load_dword v174, v66, s[8:9]
	global_load_dword v175, v67, s[8:9]
	global_load_dword v176, v68, s[8:9]
	global_load_dword v177, v69, s[8:9]
	global_load_dword v178, v70, s[8:9]
	global_load_dword v179, v71, s[8:9]
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1
	v_exp_f32_e32 v1, v1
	s_waitcnt vmcnt(47)
	v_mul_f32_e32 v128, v6, v14
	s_waitcnt vmcnt(46)
	v_mul_f32_e32 v129, v14, v7
	s_waitcnt vmcnt(45)
	v_mul_f32_e32 v130, v14, v10
	s_waitcnt vmcnt(44)
	v_mul_f32_e32 v131, v14, v12
	s_waitcnt vmcnt(43)
	v_mul_f32_e32 v132, v14, v13
	s_waitcnt vmcnt(42)
	v_mul_f32_e32 v133, v14, v15
	s_waitcnt vmcnt(41)
	v_mul_f32_e32 v134, v14, v16
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v135, v14, v109
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v136, v14, v110
	s_waitcnt vmcnt(38)
	v_mul_f32_e32 v137, v14, v111
	s_waitcnt vmcnt(37)
	v_mul_f32_e32 v138, v14, v112
	s_waitcnt vmcnt(36)
	v_mul_f32_e32 v139, v14, v125
	s_waitcnt lgkmcnt(7)
	v_fma_f32 v125, v2, v128, 0
	global_load_dword v2, v72, s[8:9]
	global_load_dword v12, v73, s[8:9]
	global_load_dword v16, v74, s[8:9]
	v_fmac_f32_e32 v125, v129, v3
	v_fmac_f32_e32 v125, v130, v4
	v_fmac_f32_e32 v125, v131, v5
	s_waitcnt lgkmcnt(6)
	v_fmac_f32_e32 v125, v132, v97
	global_load_dword v97, v75, s[8:9]
	v_fmac_f32_e32 v125, v133, v98
	v_fmac_f32_e32 v125, v134, v99
	v_fmac_f32_e32 v125, v135, v100
	s_waitcnt lgkmcnt(5)
	v_fmac_f32_e32 v125, v136, v101
	v_fmac_f32_e32 v125, v137, v102
	v_fmac_f32_e32 v125, v138, v103
	global_load_dword v103, v76, s[8:9]
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v140, v14, v126
	v_fmac_f32_e32 v125, v139, v104
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v141, v14, v127
	s_waitcnt lgkmcnt(4)
	v_fmac_f32_e32 v125, v140, v105
	global_load_dword v105, v77, s[8:9]
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v142, v14, v142
	v_fmac_f32_e32 v125, v141, v106
	global_load_dword v106, v78, s[8:9]
	global_load_dword v110, v79, s[8:9]
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v143, v14, v143
	v_fmac_f32_e32 v125, v142, v107
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v144, v14, v144
	v_fmac_f32_e32 v125, v143, v108
	s_waitcnt vmcnt(38)
	v_mul_f32_e32 v145, v14, v145
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v125, v144, v113
	s_waitcnt vmcnt(37)
	v_mul_f32_e32 v146, v14, v146
	v_fmac_f32_e32 v125, v145, v114
	s_waitcnt vmcnt(36)
	v_mul_f32_e32 v147, v14, v147
	v_fmac_f32_e32 v125, v146, v115
	s_waitcnt vmcnt(35)
	v_mul_f32_e32 v109, v14, v152
	v_fmac_f32_e32 v125, v147, v116
	s_waitcnt vmcnt(34)
	v_mul_f32_e32 v180, v14, v153
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v112, v14, v156
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v109, v117
	global_load_dword v156, v80, s[8:9]
	v_mul_f32_e32 v181, v14, v154
	v_fmac_f32_e32 v125, v180, v118
	v_mul_f32_e32 v127, v14, v155
	v_fmac_f32_e32 v125, v181, v119
	v_fmac_f32_e32 v125, v127, v120
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v108, v14, v157
	global_load_dword v157, v81, s[8:9]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v112, v121
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v107, v14, v158
	global_load_dword v158, v82, s[8:9]
	v_fmac_f32_e32 v125, v108, v122
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v104, v14, v159
	global_load_dword v159, v83, s[8:9]
	v_fmac_f32_e32 v125, v107, v123
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v98, v14, v160
	v_fmac_f32_e32 v125, v104, v124
	s_waitcnt vmcnt(30)
	v_mul_f32_e32 v13, v14, v161
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v98, v148
	s_waitcnt vmcnt(29)
	v_mul_f32_e32 v7, v14, v162
	v_fmac_f32_e32 v125, v13, v149
	s_waitcnt vmcnt(28)
	v_mul_f32_e32 v4, v14, v163
	v_fmac_f32_e32 v125, v7, v150
	ds_read_b128 v[99:102], v22 offset:128
	v_fmac_f32_e32 v125, v4, v151
	ds_read_b128 v[148:151], v22 offset:144
	global_load_dword v160, v84, s[8:9]
	global_load_dword v161, v85, s[8:9]
	global_load_dword v162, v86, s[8:9]
	global_load_dword v163, v87, s[8:9]
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v120, v14, v164
	v_add_f32_e32 v164, 1.0, v1
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v120, v99
	s_waitcnt vmcnt(30)
	v_mul_f32_e32 v126, v14, v165
	v_div_scale_f32 v1, s[30:31], v164, v164, 1.0
	v_fmac_f32_e32 v125, v126, v100
	s_waitcnt vmcnt(29)
	v_mul_f32_e32 v124, v14, v166
	v_fmac_f32_e32 v125, v124, v101
	s_waitcnt vmcnt(28)
	v_mul_f32_e32 v123, v14, v167
	v_fmac_f32_e32 v125, v123, v102
	s_waitcnt vmcnt(27)
	v_mul_f32_e32 v118, v14, v168
	ds_read_b128 v[152:155], v22 offset:160
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v118, v148
	s_waitcnt vmcnt(26)
	v_mul_f32_e32 v115, v14, v169
	v_fmac_f32_e32 v125, v115, v149
	s_waitcnt vmcnt(25)
	v_mul_f32_e32 v113, v14, v170
	v_fmac_f32_e32 v125, v113, v150
	s_waitcnt vmcnt(24)
	v_mul_f32_e32 v111, v14, v171
	s_waitcnt vmcnt(14)
	v_mul_f32_e32 v122, v14, v12
	v_div_scale_f32 v12, vcc, 1.0, v164, 1.0
	v_fmac_f32_e32 v125, v111, v151
	ds_read_b128 v[148:151], v22 offset:176
	v_mul_f32_e32 v100, v14, v172
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v100, v152
	v_mul_f32_e32 v101, v14, v173
	v_fmac_f32_e32 v125, v101, v153
	v_mul_f32_e32 v99, v14, v174
	v_fmac_f32_e32 v125, v99, v154
	v_mul_f32_e32 v15, v14, v175
	v_fmac_f32_e32 v125, v15, v155
	v_mul_f32_e32 v10, v14, v176
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v10, v148
	v_mul_f32_e32 v6, v14, v177
	v_fmac_f32_e32 v125, v6, v149
	v_mul_f32_e32 v5, v14, v178
	v_fmac_f32_e32 v125, v5, v150
	v_mul_f32_e32 v3, v14, v179
	v_fmac_f32_e32 v125, v3, v151
	ds_read_b128 v[148:151], v22 offset:192
	ds_read_b128 v[152:155], v22 offset:208
	s_waitcnt vmcnt(12)
	v_mul_f32_e32 v117, v14, v97
	v_rcp_f32_e32 v97, v1
	v_mul_f32_e32 v2, v14, v2
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v2, v148
	v_fmac_f32_e32 v125, v122, v149
	v_fma_f32 v102, -v1, v97, 1.0
	v_mul_f32_e32 v121, v14, v16
	v_fmac_f32_e32 v97, v102, v97
	v_fmac_f32_e32 v125, v121, v150
	v_mul_f32_e32 v102, v12, v97
	v_fmac_f32_e32 v125, v117, v151
	s_waitcnt vmcnt(11)
	v_mul_f32_e32 v119, v14, v103
	v_fma_f32 v103, -v1, v102, v12
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v119, v152
	s_waitcnt vmcnt(10)
	v_mul_f32_e32 v116, v14, v105
	v_fmac_f32_e32 v102, v103, v97
	v_fmac_f32_e32 v125, v116, v153
	s_waitcnt vmcnt(9)
	v_mul_f32_e32 v114, v14, v106
	v_fma_f32 v1, -v1, v102, v12
	v_fmac_f32_e32 v125, v114, v154
	s_waitcnt vmcnt(8)
	v_mul_f32_e32 v110, v14, v110
	s_waitcnt vmcnt(7)
	v_mul_f32_e32 v16, v14, v156
	v_div_fmas_f32 v156, v1, v97, v102
	v_fmac_f32_e32 v125, v110, v155
	ds_read_b128 v[148:151], v22 offset:224
	ds_read_b128 v[152:155], v22 offset:240
	s_waitcnt vmcnt(6)
	v_mul_f32_e32 v106, v14, v157
	s_waitcnt vmcnt(5)
	v_mul_f32_e32 v105, v14, v158
	s_waitcnt vmcnt(4)
	v_mul_f32_e32 v103, v14, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v16, v148
	v_fmac_f32_e32 v125, v106, v149
	v_fmac_f32_e32 v125, v105, v150
	v_fmac_f32_e32 v125, v103, v151
	s_waitcnt vmcnt(3)
	v_mul_f32_e32 v102, v14, v160
	s_waitcnt vmcnt(2)
	v_mul_f32_e32 v97, v14, v161
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v102, v152
	s_waitcnt vmcnt(1)
	v_mul_f32_e32 v12, v14, v162
	v_fmac_f32_e32 v125, v97, v153
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v1, v14, v163
	v_fmac_f32_e32 v125, v12, v154
	v_fmac_f32_e32 v125, v1, v155
	ds_write_b32 v21, v125
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read2st64_b32 v[152:153], v18 offset1:2
	ds_read_b32 v125, v93
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b128 v[148:151], v22
	v_div_fixup_f32 v14, v156, v164, 1.0
	ds_read_b128 v[156:159], v23
	v_add_f32_e32 v152, v152, v153
	v_sub_f32_e32 v125, v125, v152
	v_mul_f32_e32 v14, v14, v125
	ds_read_b128 v[152:155], v22 offset:16
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v128, v14, v148
	v_fmac_f32_e32 v129, v14, v149
	v_fmac_f32_e32 v130, v14, v150
	v_fmac_f32_e32 v131, v14, v151
	ds_read_b128 v[148:151], v23 offset:16
	s_waitcnt lgkmcnt(2)
	v_fma_f32 v125, v128, v156, 0
	v_fmac_f32_e32 v125, v129, v157
	v_fmac_f32_e32 v125, v130, v158
	v_fmac_f32_e32 v125, v131, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v132, v14, v152
	v_fmac_f32_e32 v133, v14, v153
	v_fmac_f32_e32 v134, v14, v154
	v_fmac_f32_e32 v135, v14, v155
	ds_read_b128 v[152:155], v22 offset:32
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v132, v148
	ds_read_b128 v[156:159], v23 offset:32
	v_fmac_f32_e32 v125, v133, v149
	v_fmac_f32_e32 v125, v134, v150
	v_fmac_f32_e32 v125, v135, v151
	ds_read_b128 v[148:151], v22 offset:48
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v136, v14, v152
	v_fmac_f32_e32 v137, v14, v153
	v_fmac_f32_e32 v138, v14, v154
	v_fmac_f32_e32 v139, v14, v155
	ds_read_b128 v[152:155], v23 offset:48
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v136, v156
	v_fmac_f32_e32 v125, v137, v157
	v_fmac_f32_e32 v125, v138, v158
	v_fmac_f32_e32 v125, v139, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v140, v14, v148
	v_fmac_f32_e32 v141, v14, v149
	v_fmac_f32_e32 v142, v14, v150
	v_fmac_f32_e32 v143, v14, v151
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v140, v152
	ds_read_b128 v[148:151], v22 offset:64
	v_fmac_f32_e32 v125, v141, v153
	ds_read_b128 v[156:159], v23 offset:64
	v_fmac_f32_e32 v125, v142, v154
	v_fmac_f32_e32 v125, v143, v155
	ds_read_b128 v[152:155], v22 offset:80
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v144, v14, v148
	v_fmac_f32_e32 v145, v14, v149
	v_fmac_f32_e32 v146, v14, v150
	v_fmac_f32_e32 v147, v14, v151
	ds_read_b128 v[148:151], v23 offset:80
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v144, v156
	v_fmac_f32_e32 v125, v145, v157
	global_store_dword v24, v128, s[8:9]
	global_store_dword v25, v129, s[8:9]
	global_store_dword v26, v130, s[8:9]
	global_store_dword v27, v131, s[8:9]
	global_store_dword v28, v132, s[8:9]
	global_store_dword v29, v133, s[8:9]
	global_store_dword v30, v134, s[8:9]
	global_store_dword v31, v135, s[8:9]
	global_store_dword v32, v136, s[8:9]
	global_store_dword v33, v137, s[8:9]
	global_store_dword v34, v138, s[8:9]
	global_store_dword v35, v139, s[8:9]
	global_store_dword v36, v140, s[8:9]
	global_store_dword v37, v141, s[8:9]
	global_store_dword v38, v142, s[8:9]
	global_store_dword v39, v143, s[8:9]
	global_store_dword v40, v144, s[8:9]
	global_store_dword v41, v145, s[8:9]
	global_store_dword v42, v146, s[8:9]
	global_store_dword v43, v147, s[8:9]
	v_fmac_f32_e32 v125, v146, v158
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v109, v14, v152
	v_fmac_f32_e32 v180, v14, v153
	v_fmac_f32_e32 v181, v14, v154
	v_fmac_f32_e32 v127, v14, v155
	ds_read_b128 v[128:131], v22 offset:96
	v_fmac_f32_e32 v125, v147, v159
	global_store_dword v44, v109, s[8:9]
	global_store_dword v45, v180, s[8:9]
	global_store_dword v46, v181, s[8:9]
	global_store_dword v47, v127, s[8:9]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v109, v148
	ds_read_b128 v[132:135], v23 offset:96
	ds_read_b128 v[136:139], v22 offset:112
	v_fmac_f32_e32 v125, v180, v149
	v_fmac_f32_e32 v125, v181, v150
	v_fmac_f32_e32 v125, v127, v151
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v112, v14, v128
	ds_read_b128 v[140:143], v23 offset:112
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v112, v132
	v_fmac_f32_e32 v108, v14, v129
	v_fmac_f32_e32 v125, v108, v133
	v_fmac_f32_e32 v107, v14, v130
	ds_read_b128 v[127:130], v23 offset:128
	v_fmac_f32_e32 v125, v107, v134
	v_fmac_f32_e32 v104, v14, v131
	ds_read_b128 v[131:134], v22 offset:128
	v_fmac_f32_e32 v125, v104, v135
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v98, v14, v136
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v98, v140
	v_fmac_f32_e32 v13, v14, v137
	v_fmac_f32_e32 v125, v13, v141
	v_fmac_f32_e32 v7, v14, v138
	ds_read_b128 v[135:138], v22 offset:144
	v_fmac_f32_e32 v125, v7, v142
	v_fmac_f32_e32 v4, v14, v139
	v_fmac_f32_e32 v125, v4, v143
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v120, v14, v131
	ds_read_b128 v[139:142], v23 offset:144
	v_fmac_f32_e32 v125, v120, v127
	v_fmac_f32_e32 v126, v14, v132
	v_fmac_f32_e32 v125, v126, v128
	v_fmac_f32_e32 v124, v14, v133
	v_fmac_f32_e32 v123, v14, v134
	global_store_dword v48, v112, s[8:9]
	global_store_dword v49, v108, s[8:9]
	global_store_dword v50, v107, s[8:9]
	global_store_dword v51, v104, s[8:9]
	global_store_dword v52, v98, s[8:9]
	global_store_dword v53, v13, s[8:9]
	global_store_dword v54, v7, s[8:9]
	global_store_dword v55, v4, s[8:9]
	global_store_dword v56, v120, s[8:9]
	global_store_dword v57, v126, s[8:9]
	global_store_dword v58, v124, s[8:9]
	v_fmac_f32_e32 v125, v124, v129
	global_store_dword v59, v123, s[8:9]
	v_fmac_f32_e32 v125, v123, v130
	ds_read_b128 v[126:129], v22 offset:160
	ds_read_b128 v[130:133], v22 offset:176
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v118, v14, v135
	v_fmac_f32_e32 v115, v14, v136
	v_fmac_f32_e32 v113, v14, v137
	ds_read_b128 v[134:137], v23 offset:160
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v125, v118, v139
	v_fmac_f32_e32 v125, v115, v140
	v_fmac_f32_e32 v125, v113, v141
	v_fmac_f32_e32 v111, v14, v138
	ds_read_b128 v[138:141], v23 offset:176
	v_fmac_f32_e32 v125, v111, v142
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v100, v14, v126
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v100, v134
	v_fmac_f32_e32 v101, v14, v127
	v_fmac_f32_e32 v125, v101, v135
	v_fmac_f32_e32 v99, v14, v128
	v_fmac_f32_e32 v125, v99, v136
	v_fmac_f32_e32 v15, v14, v129
	v_fmac_f32_e32 v125, v15, v137
	v_fmac_f32_e32 v10, v14, v130
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v10, v138
	v_fmac_f32_e32 v6, v14, v131
	global_store_dword v60, v118, s[8:9]
	global_store_dword v61, v115, s[8:9]
	global_store_dword v62, v113, s[8:9]
	global_store_dword v63, v111, s[8:9]
	global_store_dword v64, v100, s[8:9]
	global_store_dword v65, v101, s[8:9]
	global_store_dword v66, v99, s[8:9]
	global_store_dword v67, v15, s[8:9]
	global_store_dword v68, v10, s[8:9]
	v_fmac_f32_e32 v125, v6, v139
	v_fmac_f32_e32 v5, v14, v132
	ds_read_b128 v[98:101], v23 offset:192
	ds_read_b128 v[126:129], v23 offset:208
	global_store_dword v69, v6, s[8:9]
	global_store_dword v70, v5, s[8:9]
	v_fmac_f32_e32 v125, v5, v140
	ds_read_b128 v[4:7], v22 offset:192
	v_fmac_f32_e32 v3, v14, v133
	ds_read_b128 v[130:133], v22 offset:208
	v_fmac_f32_e32 v125, v3, v141
	global_store_dword v71, v3, s[8:9]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v2, v14, v4
	v_fmac_f32_e32 v125, v2, v98
	v_fmac_f32_e32 v122, v14, v5
	v_fmac_f32_e32 v125, v122, v99
	v_fmac_f32_e32 v121, v14, v6
	v_fmac_f32_e32 v125, v121, v100
	v_fmac_f32_e32 v117, v14, v7
	v_fmac_f32_e32 v125, v117, v101
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v119, v14, v130
	v_fmac_f32_e32 v125, v119, v126
	v_fmac_f32_e32 v116, v14, v131
	global_store_dword v72, v2, s[8:9]
	v_fmac_f32_e32 v125, v116, v127
	v_fmac_f32_e32 v114, v14, v132
	v_fmac_f32_e32 v110, v14, v133
	ds_read_b128 v[2:5], v22 offset:224
	global_store_dword v73, v122, s[8:9]
	global_store_dword v74, v121, s[8:9]
	global_store_dword v75, v117, s[8:9]
	global_store_dword v76, v119, s[8:9]
	global_store_dword v77, v116, s[8:9]
	global_store_dword v78, v114, s[8:9]
	v_fmac_f32_e32 v125, v114, v128
	global_store_dword v79, v110, s[8:9]
	v_fmac_f32_e32 v125, v110, v129
	ds_read_b128 v[98:101], v23 offset:224
	ds_read_b128 v[107:110], v22 offset:240
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v16, v14, v2
	ds_read_b128 v[111:114], v23 offset:240
	v_fmac_f32_e32 v106, v14, v3
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v16, v98
	v_fmac_f32_e32 v125, v106, v99
	v_fmac_f32_e32 v105, v14, v4
	v_fmac_f32_e32 v125, v105, v100
	v_fmac_f32_e32 v103, v14, v5
	v_fmac_f32_e32 v125, v103, v101
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v102, v14, v107
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v102, v111
	v_fmac_f32_e32 v97, v14, v108
	v_fmac_f32_e32 v125, v97, v112
	v_fmac_f32_e32 v12, v14, v109
	v_fmac_f32_e32 v125, v12, v113
	v_fmac_f32_e32 v1, v14, v110
	global_store_dword v87, v1, s[8:9]
	v_fmac_f32_e32 v125, v1, v114
	v_mov_b32_e32 v1, 0
	global_store_dword v80, v16, s[8:9]
	global_store_dword v81, v106, s[8:9]
	global_store_dword v82, v105, s[8:9]
	global_store_dword v83, v103, s[8:9]
	global_store_dword v84, v102, s[8:9]
	global_store_dword v85, v97, s[8:9]
	global_store_dword v86, v12, s[8:9]
	ds_write_b32 v21, v125
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB2_21
; %bb.20:                               ;   in Loop: Header=BB2_3 Depth=1
	ds_read2st64_b32 v[1:2], v19 offset1:2
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v1, v1, v2
.LBB2_21:                               ;   in Loop: Header=BB2_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_mul_f32_e32 v2, v1, v1
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	v_fmac_f32_e32 v3, v1, v1
	s_nop 1
	v_add_f32_dpp v2, v3, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v3, 0
	s_nop 0
	v_add_f32_dpp v2, v2, v2 row_half_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:15 row_mask:0xa bank_mask:0xf
	v_add_f32_e32 v2, v2, v3
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[2:3]
	s_cbranch_execz .LBB2_23
; %bb.22:                               ;   in Loop: Header=BB2_3 Depth=1
	v_add_f32_e32 v2, v2, v3
	ds_write_b32 v20, v2
.LBB2_23:                               ;   in Loop: Header=BB2_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB2_2
; %bb.24:                               ;   in Loop: Header=BB2_3 Depth=1
	v_or_b32_e32 v10, s44, v0
	v_lshlrev_b64 v[2:3], 2, v[10:11]
	v_mov_b32_e32 v4, s15
	v_add_co_u32_e32 v2, vcc, s14, v2
	v_addc_co_u32_e32 v3, vcc, v4, v3, vcc
	global_load_dword v4, v[2:3], off
	global_load_dword v5, v[8:9], off
	s_waitcnt vmcnt(1)
	v_mul_f32_e32 v2, 0xbfb8aa3b, v4
	v_exp_f32_e32 v2, v2
	v_add_f32_e32 v6, 1.0, v2
	v_div_scale_f32 v7, s[30:31], v6, v6, v4
	v_div_scale_f32 v12, vcc, v4, v6, v4
	ds_read_b64 v[2:3], v11 offset:2560
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_rcp_f32_e32 v13, v7
	v_fma_f32 v14, -v7, v13, 1.0
	v_fmac_f32_e32 v13, v14, v13
	v_mul_f32_e32 v14, v12, v13
	v_fma_f32 v15, -v7, v14, v12
	v_fmac_f32_e32 v14, v15, v13
	v_fma_f32 v7, -v7, v14, v12
	v_div_fmas_f32 v7, v7, v13, v14
	v_mov_b32_e32 v12, s33
	v_fmac_f32_e32 v12, 0x3c000000, v2
	v_mul_f32_e32 v2, 0x4b800000, v12
	v_cmp_gt_f32_e32 vcc, s38, v12
	v_cndmask_b32_e32 v2, v12, v2, vcc
	v_rsq_f32_e32 v12, v2
	v_lshlrev_b64 v[2:3], 1, v[10:11]
	v_mov_b32_e32 v13, s35
	v_mul_f32_e32 v10, 0x45800000, v12
	v_cndmask_b32_e32 v10, v12, v10, vcc
	v_mul_f32_e32 v1, v1, v10
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v1, v5, v1
	v_div_fixup_f32 v4, v7, v6, v4
	v_mul_f32_e32 v1, v4, v1
	;;#ASMSTART
	;;#ASMEND
	v_cvt_f16_f32_e32 v4, v1
	v_add_co_u32_e32 v1, vcc, s34, v2
	v_addc_co_u32_e32 v2, vcc, v13, v3, vcc
	global_store_short v[1:2], v4, off
	s_branch .LBB2_2
.LBB2_25:
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel register_step
		.amdhsa_group_segment_fixed_size 2576
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 368
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 182
		.amdhsa_next_free_sgpr 50
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end2:
	.size	register_step, .Lfunc_end2-register_step
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 6204
; NumSgprs: 54
; NumVgprs: 182
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 2576 bytes/workgroup (compile time only)
; SGPRBlocks: 6
; VGPRBlocks: 45
; NumSGPRsForWavesPerEU: 54
; NumVGPRsForWavesPerEU: 182
; Occupancy: 1
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.text
	.protected	baseline_step           ; -- Begin function baseline_step
	.globl	baseline_step
	.p2align	8
	.type	baseline_step,@function
baseline_step:                          ; @baseline_step
; %bb.0:
	s_cmp_gt_u32 s6, 31
	s_cbranch_scc1 .LBB3_25
; %bb.1:
	s_load_dwordx16 s[12:27], s[4:5], 0x0
	s_load_dwordx8 s[36:43], s[4:5], 0x40
	v_and_b32_e32 v2, 63, v0
	s_load_dword s28, s[4:5], 0x60
	s_load_dword s29, s[4:5], 0x68
	v_and_b32_e32 v17, 0x7f, v0
	v_lshrrev_b32_e32 v1, 7, v0
	v_cmp_eq_u32_e64 s[2:3], 63, v2
	v_lshrrev_b32_e32 v2, 4, v0
	v_mov_b32_e32 v3, 0xa00
	v_lshlrev_b32_e32 v18, 2, v17
	v_and_or_b32 v20, v2, 12, v3
	v_lshlrev_b32_e32 v2, 13, v1
	v_rsq_f32_e32 v92, 0x43000000
	s_movk_i32 s8, 0x80
	v_lshlrev_b32_e32 v19, 2, v0
	v_lshl_or_b32 v21, v1, 9, v18
	v_or_b32_e32 v3, v2, v17
	v_lshlrev_b32_e32 v1, 8, v1
	v_or_b32_e32 v2, v2, v0
	s_movk_i32 s0, 0x7f
	v_or_b32_e32 v4, 0x80, v2
	v_or_b32_e32 v5, 0x180, v2
	v_or_b32_e32 v6, 0x280, v2
	v_or_b32_e32 v7, 0x380, v2
	v_or_b32_e32 v10, 0x480, v2
	v_or_b32_e32 v11, 0x580, v2
	v_or_b32_e32 v12, 0x680, v2
	v_or_b32_e32 v13, 0x780, v2
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v9, s39
	v_add_co_u32_e32 v8, vcc, s38, v19
	v_or_b32_e32 v14, 0x880, v2
	v_or_b32_e32 v15, 0x980, v2
	v_or_b32_e32 v16, 0xa80, v2
	v_or_b32_e32 v47, 0xb80, v2
	v_or_b32_e32 v49, 0xc80, v2
	v_or_b32_e32 v51, 0xd80, v2
	v_or_b32_e32 v53, 0xe80, v2
	v_or_b32_e32 v55, 0xf80, v2
	v_or_b32_e32 v57, 0x1080, v2
	v_or_b32_e32 v59, 0x1180, v2
	v_or_b32_e32 v61, 0x1280, v2
	v_or_b32_e32 v63, 0x1380, v2
	v_or_b32_e32 v65, 0x1480, v2
	v_or_b32_e32 v67, 0x1580, v2
	v_or_b32_e32 v69, 0x1680, v2
	v_or_b32_e32 v71, 0x1780, v2
	v_or_b32_e32 v73, 0x1880, v2
	v_or_b32_e32 v75, 0x1980, v2
	v_or_b32_e32 v77, 0x1a80, v2
	v_or_b32_e32 v79, 0x1b80, v2
	v_or_b32_e32 v81, 0x1c80, v2
	v_or_b32_e32 v83, 0x1d80, v2
	v_or_b32_e32 v85, 0x1e80, v2
	v_or_b32_e32 v2, 0x1f80, v2
	v_or_b32_e32 v22, 0x400, v1
	v_or_b32_e32 v23, 0x600, v1
	v_or_b32_e32 v1, 0x100, v3
	v_or_b32_e32 v28, 0x200, v3
	v_or_b32_e32 v30, 0x300, v3
	v_or_b32_e32 v32, 0x400, v3
	v_or_b32_e32 v34, 0x500, v3
	v_or_b32_e32 v36, 0x600, v3
	v_or_b32_e32 v38, 0x700, v3
	v_or_b32_e32 v40, 0x800, v3
	v_or_b32_e32 v42, 0x900, v3
	v_or_b32_e32 v44, 0xa00, v3
	v_or_b32_e32 v46, 0xb00, v3
	v_or_b32_e32 v48, 0xc00, v3
	v_or_b32_e32 v50, 0xd00, v3
	v_or_b32_e32 v52, 0xe00, v3
	v_or_b32_e32 v54, 0xf00, v3
	v_or_b32_e32 v56, 0x1000, v3
	v_or_b32_e32 v58, 0x1100, v3
	v_or_b32_e32 v60, 0x1200, v3
	v_or_b32_e32 v62, 0x1300, v3
	v_or_b32_e32 v64, 0x1400, v3
	v_or_b32_e32 v66, 0x1500, v3
	v_or_b32_e32 v68, 0x1600, v3
	v_or_b32_e32 v70, 0x1700, v3
	v_or_b32_e32 v72, 0x1800, v3
	v_or_b32_e32 v74, 0x1900, v3
	v_or_b32_e32 v76, 0x1a00, v3
	v_or_b32_e32 v78, 0x1b00, v3
	v_or_b32_e32 v80, 0x1c00, v3
	v_or_b32_e32 v82, 0x1d00, v3
	v_or_b32_e32 v84, 0x1e00, v3
	v_or_b32_e32 v86, 0x1f00, v3
	v_or_b32_e32 v88, 0x400, v18
	v_add_u32_e32 v89, 0x600, v19
	v_cmp_gt_u32_e64 s[4:5], s8, v0
	v_cmp_lt_u32_e64 s[0:1], s0, v0
	s_mov_b32 s7, 0
	v_addc_co_u32_e32 v9, vcc, 0, v9, vcc
	s_lshl_b32 s30, s6, 7
	s_lshl_b32 s31, s29, 7
	s_mov_b32 s33, 0x800000
	s_mov_b32 s34, 0x41a00000
	s_mov_b32 s35, 0x3f2aaaab
	s_mov_b32 s38, 0x3f317218
	s_mov_b32 s39, 0x7f800000
	s_mov_b32 s44, 0x33800000
	v_lshlrev_b32_e32 v24, 2, v3
	v_lshlrev_b32_e32 v25, 2, v4
	v_lshlrev_b32_e32 v26, 2, v1
	v_lshlrev_b32_e32 v27, 2, v5
	v_lshlrev_b32_e32 v28, 2, v28
	v_lshlrev_b32_e32 v29, 2, v6
	v_lshlrev_b32_e32 v30, 2, v30
	v_lshlrev_b32_e32 v31, 2, v7
	v_lshlrev_b32_e32 v32, 2, v32
	v_lshlrev_b32_e32 v33, 2, v10
	v_lshlrev_b32_e32 v34, 2, v34
	v_lshlrev_b32_e32 v35, 2, v11
	v_lshlrev_b32_e32 v36, 2, v36
	v_lshlrev_b32_e32 v37, 2, v12
	v_lshlrev_b32_e32 v38, 2, v38
	v_lshlrev_b32_e32 v39, 2, v13
	v_lshlrev_b32_e32 v40, 2, v40
	v_lshlrev_b32_e32 v41, 2, v14
	v_lshlrev_b32_e32 v42, 2, v42
	v_lshlrev_b32_e32 v43, 2, v15
	v_lshlrev_b32_e32 v44, 2, v44
	v_lshlrev_b32_e32 v45, 2, v16
	v_lshlrev_b32_e32 v46, 2, v46
	v_lshlrev_b32_e32 v47, 2, v47
	v_lshlrev_b32_e32 v48, 2, v48
	v_lshlrev_b32_e32 v49, 2, v49
	v_lshlrev_b32_e32 v50, 2, v50
	v_lshlrev_b32_e32 v51, 2, v51
	v_lshlrev_b32_e32 v52, 2, v52
	v_lshlrev_b32_e32 v53, 2, v53
	v_lshlrev_b32_e32 v54, 2, v54
	v_lshlrev_b32_e32 v55, 2, v55
	v_lshlrev_b32_e32 v56, 2, v56
	v_lshlrev_b32_e32 v57, 2, v57
	v_lshlrev_b32_e32 v58, 2, v58
	v_lshlrev_b32_e32 v59, 2, v59
	v_lshlrev_b32_e32 v60, 2, v60
	v_lshlrev_b32_e32 v61, 2, v61
	v_lshlrev_b32_e32 v62, 2, v62
	v_lshlrev_b32_e32 v63, 2, v63
	v_lshlrev_b32_e32 v64, 2, v64
	v_lshlrev_b32_e32 v65, 2, v65
	v_lshlrev_b32_e32 v66, 2, v66
	v_lshlrev_b32_e32 v67, 2, v67
	v_lshlrev_b32_e32 v68, 2, v68
	v_lshlrev_b32_e32 v69, 2, v69
	v_lshlrev_b32_e32 v70, 2, v70
	v_lshlrev_b32_e32 v71, 2, v71
	v_lshlrev_b32_e32 v72, 2, v72
	v_lshlrev_b32_e32 v73, 2, v73
	v_lshlrev_b32_e32 v74, 2, v74
	v_lshlrev_b32_e32 v75, 2, v75
	v_lshlrev_b32_e32 v76, 2, v76
	v_lshlrev_b32_e32 v77, 2, v77
	v_lshlrev_b32_e32 v78, 2, v78
	v_lshlrev_b32_e32 v79, 2, v79
	v_lshlrev_b32_e32 v80, 2, v80
	v_lshlrev_b32_e32 v81, 2, v81
	v_lshlrev_b32_e32 v82, 2, v82
	v_lshlrev_b32_e32 v83, 2, v83
	v_lshlrev_b32_e32 v84, 2, v84
	v_lshlrev_b32_e32 v85, 2, v85
	v_lshlrev_b32_e32 v86, 2, v86
	v_lshlrev_b32_e32 v87, 2, v2
	v_or_b32_e32 v90, 0x800, v19
	v_cndmask_b32_e64 v91, v88, v89, s[4:5]
	v_or_b32_e32 v93, 0x800, v18
	v_mov_b32_e32 v94, 0x3f2aaada
	v_mov_b32_e32 v95, 0x7fc00000
	v_mov_b32_e32 v96, 0xff800000
	v_mov_b32_e32 v11, 0
	s_branch .LBB3_3
.LBB3_2:                                ;   in Loop: Header=BB3_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_add_i32 s6, s6, s29
	s_add_i32 s30, s30, s31
	s_cmp_lt_u32 s6, 32
	s_waitcnt vmcnt(0)
	s_barrier
	s_cbranch_scc0 .LBB3_25
.LBB3_3:                                ; =>This Inner Loop Header: Depth=1
	s_cmp_lt_u32 s6, 16
	s_cselect_b64 s[8:9], -1, 0
	v_cndmask_b32_e64 v1, 0, 1, s[8:9]
	v_cmp_ne_u32_e64 s[8:9], 1, v1
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b64 s[10:11], s[0:1]
	s_xor_b64 s[10:11], exec, s[10:11]
	s_cbranch_execz .LBB3_7
; %bb.4:                                ;   in Loop: Header=BB3_3 Depth=1
	v_add_u32_e32 v1, s30, v17
	v_or_b32_e32 v1, 0x800, v1
	v_lshl_add_u32 v10, v1, 1, v1
	v_lshlrev_b64 v[14:15], 2, v[10:11]
	v_mov_b32_e32 v2, s23
	v_add_co_u32_e32 v12, vcc, s22, v14
	v_lshlrev_b32_e32 v10, 2, v1
	v_addc_co_u32_e32 v13, vcc, v2, v15, vcc
	v_lshlrev_b64 v[2:3], 2, v[10:11]
	v_mov_b32_e32 v4, s21
	v_add_co_u32_e32 v97, vcc, s20, v2
	v_mov_b32_e32 v2, v11
	v_lshlrev_b64 v[1:2], 2, v[1:2]
	v_addc_co_u32_e32 v98, vcc, v4, v3, vcc
	v_mov_b32_e32 v3, s13
	v_add_co_u32_e32 v99, vcc, s12, v1
	v_addc_co_u32_e32 v100, vcc, v3, v2, vcc
	global_load_dword v16, v[99:100], off
	global_load_dwordx4 v[1:4], v[97:98], off
	global_load_dwordx3 v[5:7], v[12:13], off
	s_and_b64 vcc, exec, s[8:9]
	s_cbranch_vccnz .LBB3_6
; %bb.5:                                ;   in Loop: Header=BB3_3 Depth=1
	v_mov_b32_e32 v10, s25
	v_add_co_u32_e32 v97, vcc, s24, v14
	v_addc_co_u32_e32 v98, vcc, v10, v15, vcc
	s_waitcnt vmcnt(0)
	global_store_dword v[97:98], v6, off
	global_load_dword v15, v[12:13], off offset:8
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v[97:98], v[15:16], off offset:4
.LBB3_6:                                ;   in Loop: Header=BB3_3 Depth=1
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v2, v2, v6
	v_fmac_f32_e32 v2, v1, v5
	v_fmac_f32_e32 v2, v3, v7
	v_fmac_f32_e32 v2, v16, v4
.LBB3_7:                                ;   in Loop: Header=BB3_3 Depth=1
	s_or_saveexec_b64 s[10:11], s[10:11]
	v_mov_b32_e32 v1, v88
	s_xor_b64 exec, exec, s[10:11]
	s_cbranch_execz .LBB3_11
; %bb.8:                                ;   in Loop: Header=BB3_3 Depth=1
	s_and_b32 s45, s30, 0x780
	v_or_b32_e32 v1, s45, v0
	v_mul_u32_u24_e32 v2, 3, v1
	v_lshlrev_b32_e32 v12, 2, v1
	v_lshlrev_b32_e32 v10, 2, v2
	v_lshlrev_b32_e32 v14, 4, v1
	global_load_dword v13, v12, s[12:13]
	global_load_dwordx4 v[1:4], v14, s[20:21]
	global_load_dwordx3 v[5:7], v10, s[22:23]
	s_and_b64 vcc, exec, s[8:9]
	s_cbranch_vccnz .LBB3_10
; %bb.9:                                ;   in Loop: Header=BB3_3 Depth=1
	v_mov_b32_e32 v12, s23
	v_add_co_u32_e32 v14, vcc, s22, v10
	v_addc_co_u32_e32 v15, vcc, 0, v12, vcc
	s_waitcnt vmcnt(0)
	global_store_dword v10, v6, s[24:25]
	global_load_dword v12, v[14:15], off offset:8
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v10, v[12:13], s[24:25] offset:4
.LBB3_10:                               ;   in Loop: Header=BB3_3 Depth=1
	v_add_u32_e32 v10, s30, v0
	v_or_b32_e32 v97, 0x1000, v10
	v_lshl_add_u32 v10, v97, 1, v97
	v_lshlrev_b64 v[101:102], 2, v[10:11]
	v_mov_b32_e32 v10, s23
	v_add_co_u32_e32 v103, vcc, s22, v101
	v_addc_co_u32_e32 v104, vcc, v10, v102, vcc
	global_load_dwordx3 v[14:16], v[103:104], off
	v_mov_b32_e32 v98, v11
	v_lshlrev_b64 v[98:99], 2, v[97:98]
	v_lshlrev_b32_e32 v10, 2, v97
	v_mov_b32_e32 v100, s13
	v_lshlrev_b64 v[105:106], 2, v[10:11]
	v_add_co_u32_e32 v97, vcc, s12, v98
	v_addc_co_u32_e32 v98, vcc, v100, v99, vcc
	v_mov_b32_e32 v12, s21
	global_load_dword v107, v[97:98], off
	v_add_co_u32_e32 v97, vcc, s20, v105
	v_addc_co_u32_e32 v98, vcc, v12, v106, vcc
	global_load_dwordx4 v[97:100], v[97:98], off
	v_mov_b32_e32 v108, s25
	v_add_co_u32_e32 v101, vcc, s24, v101
	v_addc_co_u32_e32 v102, vcc, v108, v102, vcc
	s_waitcnt vmcnt(3)
	v_mul_f32_e32 v2, v2, v6
	v_fmac_f32_e32 v2, v1, v5
	v_fmac_f32_e32 v2, v3, v7
	v_fmac_f32_e32 v2, v13, v4
	v_mul_f32_e32 v1, 0xbfb8aa3b, v2
	v_exp_f32_e32 v1, v1
	v_add_f32_e32 v1, 1.0, v1
	v_div_scale_f32 v3, s[8:9], v1, v1, v2
	v_div_scale_f32 v4, vcc, v2, v1, v2
	v_rcp_f32_e32 v5, v3
	v_fma_f32 v6, -v3, v5, 1.0
	v_fmac_f32_e32 v5, v6, v5
	v_mul_f32_e32 v6, v4, v5
	v_fma_f32 v7, -v3, v6, v4
	v_fmac_f32_e32 v6, v7, v5
	v_fma_f32 v3, -v3, v6, v4
	v_div_fmas_f32 v3, v3, v5, v6
	v_div_fixup_f32 v1, v3, v1, v2
	ds_write_b32 v89, v1
	v_mov_b32_e32 v1, v90
	s_waitcnt vmcnt(2)
	global_store_dword v[101:102], v15, off
	global_load_dword v106, v[103:104], off offset:8
	s_waitcnt vmcnt(2)
	v_mul_f32_e32 v2, v98, v15
	v_fmac_f32_e32 v2, v97, v14
	v_fmac_f32_e32 v2, v99, v16
	v_fmac_f32_e32 v2, v107, v100
	s_waitcnt vmcnt(0)
	global_store_dwordx2 v[101:102], v[106:107], off offset:4
.LBB3_11:                               ;   in Loop: Header=BB3_3 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2
	v_exp_f32_e32 v3, v3
	v_add_f32_e32 v3, 1.0, v3
	v_div_scale_f32 v4, s[8:9], v3, v3, v2
	v_div_scale_f32 v5, vcc, v2, v3, v2
	v_rcp_f32_e32 v6, v4
	v_fma_f32 v7, -v4, v6, 1.0
	v_fmac_f32_e32 v6, v7, v6
	v_mul_f32_e32 v7, v5, v6
	v_fma_f32 v10, -v4, v7, v5
	v_fmac_f32_e32 v7, v10, v6
	v_fma_f32 v4, -v4, v7, v5
	v_div_fmas_f32 v4, v4, v6, v7
	v_div_fixup_f32 v2, v4, v3, v2
	ds_write_b32 v1, v2
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	ds_read_b32 v1, v91
	v_mov_b32_e32 v2, v11
	v_mov_b32_e32 v3, v11
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v4, v1, v1
	s_nop 1
	v_mov_b32_dpp v2, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	v_fmac_f32_e32 v2, v1, v1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_half_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:15 row_mask:0xa bank_mask:0xf
	v_add_f32_e32 v2, v2, v3
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[2:3]
	s_cbranch_execz .LBB3_13
; %bb.12:                               ;   in Loop: Header=BB3_3 Depth=1
	v_add_f32_e32 v2, v2, v3
	ds_write_b32 v20, v2
.LBB3_13:                               ;   in Loop: Header=BB3_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], s[0:1]
	s_xor_b64 s[8:9], exec, s[8:9]
	s_cbranch_execz .LBB3_15
; %bb.14:                               ;   in Loop: Header=BB3_3 Depth=1
	ds_read_b64 v[2:3], v11 offset:2568
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v2, 0x358637bd, v2
	v_mul_f32_e32 v3, 0x4b800000, v2
	v_cmp_gt_f32_e32 vcc, s33, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_rsq_f32_e32 v2, v2
	v_mul_f32_e32 v3, 0x45800000, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_mul_f32_e32 v1, v1, v2
	ds_write_b32 v88, v1
                                        ; implicit-def: $vgpr1
.LBB3_15:                               ;   in Loop: Header=BB3_3 Depth=1
	s_andn2_saveexec_b64 s[8:9], s[8:9]
	s_cbranch_execz .LBB3_17
; %bb.16:                               ;   in Loop: Header=BB3_3 Depth=1
	ds_read_b64 v[2:3], v11 offset:2560
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v2, 0x358637bd, v2
	v_mul_f32_e32 v3, 0x4b800000, v2
	v_cmp_gt_f32_e32 vcc, s33, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_rsq_f32_e32 v2, v2
	v_mul_f32_e32 v3, 0x45800000, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_mul_f32_e32 v1, v1, v2
	v_mul_f32_e32 v1, v92, v1
	ds_write_b32 v89, v1
.LBB3_17:                               ;   in Loop: Header=BB3_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_lshl_b64 s[8:9], s[6:7], 2
	s_add_u32 s10, s18, s8
	s_addc_u32 s11, s19, s9
	s_add_u32 s46, s26, s8
	s_addc_u32 s47, s27, s9
	s_add_u32 s48, s16, s8
	s_addc_u32 s49, s17, s9
	s_add_u32 s8, s36, s8
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_addc_u32 s9, s37, s9
	global_load_dword v3, v11, s[48:49]
	global_load_dword v4, v11, s[8:9]
	global_load_dword v1, v11, s[10:11]
	global_load_dword v2, v11, s[46:47]
	s_waitcnt vmcnt(2)
	v_add_f32_e32 v3, v3, v4
	v_cmp_lt_f32_e32 vcc, s34, v3
	s_cbranch_vccnz .LBB3_19
; %bb.18:                               ;   in Loop: Header=BB3_3 Depth=1
	v_mul_f32_e32 v3, 0x3fb8aa3b, v3
	v_exp_f32_e32 v3, v3
	v_add_f32_e32 v4, 1.0, v3
	v_frexp_mant_f32_e32 v6, v4
	v_add_f32_e32 v5, -1.0, v4
	v_frexp_exp_i32_f32_e32 v7, v4
	v_cmp_gt_f32_e32 vcc, s35, v6
	v_sub_f32_e32 v10, v5, v4
	v_subbrev_co_u32_e32 v6, vcc, 0, v7, vcc
	v_sub_f32_e32 v5, v3, v5
	v_add_f32_e32 v10, 1.0, v10
	v_sub_u32_e32 v7, 0, v6
	v_add_f32_e32 v5, v5, v10
	v_ldexp_f32 v4, v4, v7
	v_ldexp_f32 v5, v5, v7
	v_add_f32_e32 v7, -1.0, v4
	v_add_f32_e32 v13, 1.0, v4
	v_add_f32_e32 v10, 1.0, v7
	v_add_f32_e32 v14, -1.0, v13
	v_sub_f32_e32 v10, v4, v10
	v_sub_f32_e32 v4, v4, v14
	v_add_f32_e32 v4, v5, v4
	v_add_f32_e32 v10, v5, v10
	v_add_f32_e32 v5, v13, v4
	v_rcp_f32_e32 v14, v5
	v_add_f32_e32 v12, v7, v10
	v_sub_f32_e32 v7, v12, v7
	v_sub_f32_e32 v7, v10, v7
	v_sub_f32_e32 v10, v5, v13
	v_sub_f32_e32 v4, v4, v10
	v_mul_f32_e32 v10, v12, v14
	v_mul_f32_e32 v13, v5, v10
	v_fma_f32 v15, v10, v5, -v13
	v_fmac_f32_e32 v15, v10, v4
	v_add_f32_e32 v16, v13, v15
	v_sub_f32_e32 v97, v12, v16
	v_sub_f32_e32 v12, v12, v97
	v_sub_f32_e32 v13, v16, v13
	v_sub_f32_e32 v12, v12, v16
	v_add_f32_e32 v7, v7, v12
	v_sub_f32_e32 v12, v13, v15
	v_add_f32_e32 v7, v12, v7
	v_add_f32_e32 v12, v97, v7
	v_mul_f32_e32 v13, v14, v12
	v_mul_f32_e32 v15, v5, v13
	v_fma_f32 v5, v13, v5, -v15
	v_fmac_f32_e32 v5, v13, v4
	v_sub_f32_e32 v4, v97, v12
	v_add_f32_e32 v4, v7, v4
	v_add_f32_e32 v7, v15, v5
	v_sub_f32_e32 v16, v12, v7
	v_sub_f32_e32 v12, v12, v16
	v_sub_f32_e32 v15, v7, v15
	v_sub_f32_e32 v7, v12, v7
	v_add_f32_e32 v4, v4, v7
	v_sub_f32_e32 v5, v15, v5
	v_cvt_f32_i32_e32 v6, v6
	v_add_f32_e32 v4, v5, v4
	v_add_f32_e32 v5, v10, v13
	v_add_f32_e32 v4, v16, v4
	v_sub_f32_e32 v7, v5, v10
	v_mul_f32_e32 v4, v14, v4
	v_sub_f32_e32 v7, v13, v7
	v_add_f32_e32 v4, v7, v4
	v_mul_f32_e32 v13, 0x3f317218, v6
	v_add_f32_e32 v7, v5, v4
	v_fma_f32 v14, v6, s38, -v13
	v_mul_f32_e32 v10, v7, v7
	v_mov_b32_e32 v12, 0x3ecc95a3
	v_fmac_f32_e32 v14, 0xb102e308, v6
	v_sub_f32_e32 v5, v7, v5
	v_fmac_f32_e32 v12, 0x3e9b6dac, v10
	v_sub_f32_e32 v4, v4, v5
	v_add_f32_e32 v5, v13, v14
	v_fma_f32 v12, v10, v12, v94
	v_sub_f32_e32 v6, v5, v13
	v_ldexp_f32 v13, v7, 1
	v_mul_f32_e32 v7, v7, v10
	v_mul_f32_e32 v7, v7, v12
	v_add_f32_e32 v10, v13, v7
	v_sub_f32_e32 v12, v10, v13
	v_ldexp_f32 v4, v4, 1
	v_sub_f32_e32 v7, v7, v12
	v_add_f32_e32 v4, v4, v7
	v_add_f32_e32 v7, v10, v4
	v_sub_f32_e32 v10, v7, v10
	v_sub_f32_e32 v4, v4, v10
	v_add_f32_e32 v10, v5, v7
	v_sub_f32_e32 v12, v10, v5
	v_sub_f32_e32 v13, v10, v12
	v_sub_f32_e32 v6, v14, v6
	v_sub_f32_e32 v5, v5, v13
	v_sub_f32_e32 v7, v7, v12
	v_add_f32_e32 v5, v7, v5
	v_add_f32_e32 v7, v6, v4
	v_sub_f32_e32 v12, v7, v6
	v_sub_f32_e32 v13, v7, v12
	v_sub_f32_e32 v6, v6, v13
	v_sub_f32_e32 v4, v4, v12
	v_add_f32_e32 v5, v7, v5
	v_add_f32_e32 v4, v4, v6
	v_add_f32_e32 v6, v10, v5
	v_sub_f32_e32 v7, v6, v10
	v_sub_f32_e32 v5, v5, v7
	v_add_f32_e32 v4, v4, v5
	v_add_f32_e32 v4, v6, v4
	v_cmp_eq_f32_e32 vcc, s39, v3
	v_cndmask_b32_e32 v4, v4, v3, vcc
	v_cmp_ngt_f32_e32 vcc, -1.0, v3
	v_cndmask_b32_e32 v4, v95, v4, vcc
	v_cmp_neq_f32_e32 vcc, -1.0, v3
	v_cndmask_b32_e32 v4, v96, v4, vcc
	v_cmp_lt_f32_e64 vcc, |v3|, s44
	v_cndmask_b32_e32 v3, v4, v3, vcc
.LBB3_19:                               ;   in Loop: Header=BB3_3 Depth=1
	s_lshl_b64 s[8:9], s[6:7], 16
	s_add_u32 s8, s40, s8
	s_addc_u32 s9, s41, s9
	global_load_dword v6, v24, s[8:9]
	global_load_dword v7, v25, s[8:9]
	global_load_dword v10, v26, s[8:9]
	global_load_dword v12, v27, s[8:9]
	global_load_dword v13, v28, s[8:9]
	global_load_dword v15, v29, s[8:9]
	global_load_dword v16, v30, s[8:9]
	global_load_dword v109, v31, s[8:9]
	global_load_dword v110, v32, s[8:9]
	global_load_dword v111, v33, s[8:9]
	global_load_dword v112, v34, s[8:9]
	global_load_dword v125, v35, s[8:9]
	global_load_dword v126, v36, s[8:9]
	global_load_dword v127, v37, s[8:9]
	global_load_dword v142, v38, s[8:9]
	global_load_dword v143, v39, s[8:9]
	global_load_dword v144, v40, s[8:9]
	global_load_dword v145, v41, s[8:9]
	global_load_dword v146, v42, s[8:9]
	global_load_dword v147, v43, s[8:9]
	global_load_dword v152, v44, s[8:9]
	global_load_dword v153, v45, s[8:9]
	global_load_dword v154, v46, s[8:9]
	global_load_dword v155, v47, s[8:9]
	global_load_dword v156, v48, s[8:9]
	global_load_dword v157, v49, s[8:9]
	global_load_dword v158, v50, s[8:9]
	global_load_dword v159, v51, s[8:9]
	global_load_dword v160, v52, s[8:9]
	global_load_dword v161, v53, s[8:9]
	global_load_dword v162, v54, s[8:9]
	global_load_dword v163, v55, s[8:9]
	s_waitcnt vmcnt(32)
	v_mul_f32_e32 v14, v2, v3
	v_mul_f32_e32 v14, 0x3fb8aa3b, v14
	v_exp_f32_e32 v14, v14
	ds_read_b128 v[2:5], v22
	ds_read_b128 v[97:100], v22 offset:16
	ds_read_b128 v[101:104], v22 offset:32
	ds_read_b128 v[105:108], v22 offset:48
	ds_read_b128 v[113:116], v22 offset:64
	ds_read_b128 v[117:120], v22 offset:80
	ds_read_b128 v[121:124], v22 offset:96
	ds_read_b128 v[148:151], v22 offset:112
	global_load_dword v164, v56, s[8:9]
	global_load_dword v165, v57, s[8:9]
	global_load_dword v166, v58, s[8:9]
	global_load_dword v167, v59, s[8:9]
	global_load_dword v168, v60, s[8:9]
	global_load_dword v169, v61, s[8:9]
	global_load_dword v170, v62, s[8:9]
	global_load_dword v171, v63, s[8:9]
	global_load_dword v172, v64, s[8:9]
	global_load_dword v173, v65, s[8:9]
	global_load_dword v174, v66, s[8:9]
	global_load_dword v175, v67, s[8:9]
	global_load_dword v176, v68, s[8:9]
	global_load_dword v177, v69, s[8:9]
	global_load_dword v178, v70, s[8:9]
	global_load_dword v179, v71, s[8:9]
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1
	v_exp_f32_e32 v1, v1
	s_waitcnt vmcnt(47)
	v_mul_f32_e32 v128, v6, v14
	s_waitcnt vmcnt(46)
	v_mul_f32_e32 v129, v14, v7
	s_waitcnt vmcnt(45)
	v_mul_f32_e32 v130, v14, v10
	s_waitcnt vmcnt(44)
	v_mul_f32_e32 v131, v14, v12
	s_waitcnt vmcnt(43)
	v_mul_f32_e32 v132, v14, v13
	s_waitcnt vmcnt(42)
	v_mul_f32_e32 v133, v14, v15
	s_waitcnt vmcnt(41)
	v_mul_f32_e32 v134, v14, v16
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v135, v14, v109
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v136, v14, v110
	s_waitcnt vmcnt(38)
	v_mul_f32_e32 v137, v14, v111
	s_waitcnt vmcnt(37)
	v_mul_f32_e32 v138, v14, v112
	s_waitcnt vmcnt(36)
	v_mul_f32_e32 v139, v14, v125
	s_waitcnt lgkmcnt(7)
	v_fma_f32 v125, v2, v128, 0
	global_load_dword v2, v72, s[8:9]
	global_load_dword v12, v73, s[8:9]
	global_load_dword v16, v74, s[8:9]
	v_fmac_f32_e32 v125, v129, v3
	v_fmac_f32_e32 v125, v130, v4
	v_fmac_f32_e32 v125, v131, v5
	s_waitcnt lgkmcnt(6)
	v_fmac_f32_e32 v125, v132, v97
	global_load_dword v97, v75, s[8:9]
	v_fmac_f32_e32 v125, v133, v98
	v_fmac_f32_e32 v125, v134, v99
	v_fmac_f32_e32 v125, v135, v100
	s_waitcnt lgkmcnt(5)
	v_fmac_f32_e32 v125, v136, v101
	v_fmac_f32_e32 v125, v137, v102
	v_fmac_f32_e32 v125, v138, v103
	global_load_dword v103, v76, s[8:9]
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v140, v14, v126
	v_fmac_f32_e32 v125, v139, v104
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v141, v14, v127
	s_waitcnt lgkmcnt(4)
	v_fmac_f32_e32 v125, v140, v105
	global_load_dword v105, v77, s[8:9]
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v142, v14, v142
	v_fmac_f32_e32 v125, v141, v106
	global_load_dword v106, v78, s[8:9]
	global_load_dword v110, v79, s[8:9]
	s_waitcnt vmcnt(40)
	v_mul_f32_e32 v143, v14, v143
	v_fmac_f32_e32 v125, v142, v107
	s_waitcnt vmcnt(39)
	v_mul_f32_e32 v144, v14, v144
	v_fmac_f32_e32 v125, v143, v108
	s_waitcnt vmcnt(38)
	v_mul_f32_e32 v145, v14, v145
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v125, v144, v113
	s_waitcnt vmcnt(37)
	v_mul_f32_e32 v146, v14, v146
	v_fmac_f32_e32 v125, v145, v114
	s_waitcnt vmcnt(36)
	v_mul_f32_e32 v147, v14, v147
	v_fmac_f32_e32 v125, v146, v115
	s_waitcnt vmcnt(35)
	v_mul_f32_e32 v109, v14, v152
	v_fmac_f32_e32 v125, v147, v116
	s_waitcnt vmcnt(34)
	v_mul_f32_e32 v180, v14, v153
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v112, v14, v156
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v109, v117
	global_load_dword v156, v80, s[8:9]
	v_mul_f32_e32 v181, v14, v154
	v_fmac_f32_e32 v125, v180, v118
	v_mul_f32_e32 v127, v14, v155
	v_fmac_f32_e32 v125, v181, v119
	v_fmac_f32_e32 v125, v127, v120
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v108, v14, v157
	global_load_dword v157, v81, s[8:9]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v112, v121
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v107, v14, v158
	global_load_dword v158, v82, s[8:9]
	v_fmac_f32_e32 v125, v108, v122
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v104, v14, v159
	global_load_dword v159, v83, s[8:9]
	v_fmac_f32_e32 v125, v107, v123
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v98, v14, v160
	v_fmac_f32_e32 v125, v104, v124
	s_waitcnt vmcnt(30)
	v_mul_f32_e32 v13, v14, v161
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v98, v148
	s_waitcnt vmcnt(29)
	v_mul_f32_e32 v7, v14, v162
	v_fmac_f32_e32 v125, v13, v149
	s_waitcnt vmcnt(28)
	v_mul_f32_e32 v4, v14, v163
	v_fmac_f32_e32 v125, v7, v150
	ds_read_b128 v[99:102], v22 offset:128
	v_fmac_f32_e32 v125, v4, v151
	ds_read_b128 v[148:151], v22 offset:144
	global_load_dword v160, v84, s[8:9]
	global_load_dword v161, v85, s[8:9]
	global_load_dword v162, v86, s[8:9]
	global_load_dword v163, v87, s[8:9]
	s_waitcnt vmcnt(31)
	v_mul_f32_e32 v120, v14, v164
	v_add_f32_e32 v164, 1.0, v1
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v120, v99
	s_waitcnt vmcnt(30)
	v_mul_f32_e32 v126, v14, v165
	v_div_scale_f32 v1, s[10:11], v164, v164, 1.0
	v_fmac_f32_e32 v125, v126, v100
	s_waitcnt vmcnt(29)
	v_mul_f32_e32 v124, v14, v166
	v_fmac_f32_e32 v125, v124, v101
	s_waitcnt vmcnt(28)
	v_mul_f32_e32 v123, v14, v167
	v_fmac_f32_e32 v125, v123, v102
	s_waitcnt vmcnt(27)
	v_mul_f32_e32 v118, v14, v168
	ds_read_b128 v[152:155], v22 offset:160
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v118, v148
	s_waitcnt vmcnt(26)
	v_mul_f32_e32 v115, v14, v169
	v_fmac_f32_e32 v125, v115, v149
	s_waitcnt vmcnt(25)
	v_mul_f32_e32 v113, v14, v170
	v_fmac_f32_e32 v125, v113, v150
	s_waitcnt vmcnt(24)
	v_mul_f32_e32 v111, v14, v171
	s_waitcnt vmcnt(14)
	v_mul_f32_e32 v122, v14, v12
	v_div_scale_f32 v12, vcc, 1.0, v164, 1.0
	v_fmac_f32_e32 v125, v111, v151
	ds_read_b128 v[148:151], v22 offset:176
	v_mul_f32_e32 v100, v14, v172
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v100, v152
	v_mul_f32_e32 v101, v14, v173
	v_fmac_f32_e32 v125, v101, v153
	v_mul_f32_e32 v99, v14, v174
	v_fmac_f32_e32 v125, v99, v154
	v_mul_f32_e32 v15, v14, v175
	v_fmac_f32_e32 v125, v15, v155
	v_mul_f32_e32 v10, v14, v176
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v10, v148
	v_mul_f32_e32 v6, v14, v177
	v_fmac_f32_e32 v125, v6, v149
	v_mul_f32_e32 v5, v14, v178
	v_fmac_f32_e32 v125, v5, v150
	v_mul_f32_e32 v3, v14, v179
	v_fmac_f32_e32 v125, v3, v151
	ds_read_b128 v[148:151], v22 offset:192
	ds_read_b128 v[152:155], v22 offset:208
	s_waitcnt vmcnt(12)
	v_mul_f32_e32 v117, v14, v97
	v_rcp_f32_e32 v97, v1
	v_mul_f32_e32 v2, v14, v2
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v2, v148
	v_fmac_f32_e32 v125, v122, v149
	v_fma_f32 v102, -v1, v97, 1.0
	v_mul_f32_e32 v121, v14, v16
	v_fmac_f32_e32 v97, v102, v97
	v_fmac_f32_e32 v125, v121, v150
	v_mul_f32_e32 v102, v12, v97
	v_fmac_f32_e32 v125, v117, v151
	s_waitcnt vmcnt(11)
	v_mul_f32_e32 v119, v14, v103
	v_fma_f32 v103, -v1, v102, v12
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v119, v152
	s_waitcnt vmcnt(10)
	v_mul_f32_e32 v116, v14, v105
	v_fmac_f32_e32 v102, v103, v97
	v_fmac_f32_e32 v125, v116, v153
	s_waitcnt vmcnt(9)
	v_mul_f32_e32 v114, v14, v106
	v_fma_f32 v1, -v1, v102, v12
	v_fmac_f32_e32 v125, v114, v154
	s_waitcnt vmcnt(8)
	v_mul_f32_e32 v110, v14, v110
	s_waitcnt vmcnt(7)
	v_mul_f32_e32 v16, v14, v156
	v_div_fmas_f32 v156, v1, v97, v102
	v_fmac_f32_e32 v125, v110, v155
	ds_read_b128 v[148:151], v22 offset:224
	ds_read_b128 v[152:155], v22 offset:240
	s_waitcnt vmcnt(6)
	v_mul_f32_e32 v106, v14, v157
	s_waitcnt vmcnt(5)
	v_mul_f32_e32 v105, v14, v158
	s_waitcnt vmcnt(4)
	v_mul_f32_e32 v103, v14, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v16, v148
	v_fmac_f32_e32 v125, v106, v149
	v_fmac_f32_e32 v125, v105, v150
	v_fmac_f32_e32 v125, v103, v151
	s_waitcnt vmcnt(3)
	v_mul_f32_e32 v102, v14, v160
	s_waitcnt vmcnt(2)
	v_mul_f32_e32 v97, v14, v161
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v102, v152
	s_waitcnt vmcnt(1)
	v_mul_f32_e32 v12, v14, v162
	v_fmac_f32_e32 v125, v97, v153
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v1, v14, v163
	v_fmac_f32_e32 v125, v12, v154
	v_fmac_f32_e32 v125, v1, v155
	ds_write_b32 v21, v125
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read2st64_b32 v[152:153], v18 offset1:2
	ds_read_b32 v125, v93
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b128 v[148:151], v22
	v_div_fixup_f32 v14, v156, v164, 1.0
	ds_read_b128 v[156:159], v23
	v_add_f32_e32 v152, v152, v153
	v_sub_f32_e32 v125, v125, v152
	v_mul_f32_e32 v14, v14, v125
	ds_read_b128 v[152:155], v22 offset:16
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v128, v14, v148
	v_fmac_f32_e32 v129, v14, v149
	v_fmac_f32_e32 v130, v14, v150
	v_fmac_f32_e32 v131, v14, v151
	ds_read_b128 v[148:151], v23 offset:16
	s_waitcnt lgkmcnt(2)
	v_fma_f32 v125, v128, v156, 0
	v_fmac_f32_e32 v125, v129, v157
	v_fmac_f32_e32 v125, v130, v158
	v_fmac_f32_e32 v125, v131, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v132, v14, v152
	v_fmac_f32_e32 v133, v14, v153
	v_fmac_f32_e32 v134, v14, v154
	v_fmac_f32_e32 v135, v14, v155
	ds_read_b128 v[152:155], v22 offset:32
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v132, v148
	ds_read_b128 v[156:159], v23 offset:32
	v_fmac_f32_e32 v125, v133, v149
	v_fmac_f32_e32 v125, v134, v150
	v_fmac_f32_e32 v125, v135, v151
	ds_read_b128 v[148:151], v22 offset:48
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v136, v14, v152
	v_fmac_f32_e32 v137, v14, v153
	v_fmac_f32_e32 v138, v14, v154
	v_fmac_f32_e32 v139, v14, v155
	ds_read_b128 v[152:155], v23 offset:48
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v136, v156
	v_fmac_f32_e32 v125, v137, v157
	v_fmac_f32_e32 v125, v138, v158
	v_fmac_f32_e32 v125, v139, v159
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v140, v14, v148
	v_fmac_f32_e32 v141, v14, v149
	v_fmac_f32_e32 v142, v14, v150
	v_fmac_f32_e32 v143, v14, v151
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v140, v152
	ds_read_b128 v[148:151], v22 offset:64
	v_fmac_f32_e32 v125, v141, v153
	ds_read_b128 v[156:159], v23 offset:64
	v_fmac_f32_e32 v125, v142, v154
	v_fmac_f32_e32 v125, v143, v155
	ds_read_b128 v[152:155], v22 offset:80
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v144, v14, v148
	v_fmac_f32_e32 v145, v14, v149
	v_fmac_f32_e32 v146, v14, v150
	v_fmac_f32_e32 v147, v14, v151
	ds_read_b128 v[148:151], v23 offset:80
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v144, v156
	v_fmac_f32_e32 v125, v145, v157
	global_store_dword v24, v128, s[8:9]
	global_store_dword v25, v129, s[8:9]
	global_store_dword v26, v130, s[8:9]
	global_store_dword v27, v131, s[8:9]
	global_store_dword v28, v132, s[8:9]
	global_store_dword v29, v133, s[8:9]
	global_store_dword v30, v134, s[8:9]
	global_store_dword v31, v135, s[8:9]
	global_store_dword v32, v136, s[8:9]
	global_store_dword v33, v137, s[8:9]
	global_store_dword v34, v138, s[8:9]
	global_store_dword v35, v139, s[8:9]
	global_store_dword v36, v140, s[8:9]
	global_store_dword v37, v141, s[8:9]
	global_store_dword v38, v142, s[8:9]
	global_store_dword v39, v143, s[8:9]
	global_store_dword v40, v144, s[8:9]
	global_store_dword v41, v145, s[8:9]
	global_store_dword v42, v146, s[8:9]
	global_store_dword v43, v147, s[8:9]
	v_fmac_f32_e32 v125, v146, v158
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v109, v14, v152
	v_fmac_f32_e32 v180, v14, v153
	v_fmac_f32_e32 v181, v14, v154
	v_fmac_f32_e32 v127, v14, v155
	ds_read_b128 v[128:131], v22 offset:96
	v_fmac_f32_e32 v125, v147, v159
	global_store_dword v44, v109, s[8:9]
	global_store_dword v45, v180, s[8:9]
	global_store_dword v46, v181, s[8:9]
	global_store_dword v47, v127, s[8:9]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v109, v148
	ds_read_b128 v[132:135], v23 offset:96
	ds_read_b128 v[136:139], v22 offset:112
	v_fmac_f32_e32 v125, v180, v149
	v_fmac_f32_e32 v125, v181, v150
	v_fmac_f32_e32 v125, v127, v151
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v112, v14, v128
	ds_read_b128 v[140:143], v23 offset:112
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v112, v132
	v_fmac_f32_e32 v108, v14, v129
	v_fmac_f32_e32 v125, v108, v133
	v_fmac_f32_e32 v107, v14, v130
	ds_read_b128 v[127:130], v23 offset:128
	v_fmac_f32_e32 v125, v107, v134
	v_fmac_f32_e32 v104, v14, v131
	ds_read_b128 v[131:134], v22 offset:128
	v_fmac_f32_e32 v125, v104, v135
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v98, v14, v136
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v98, v140
	v_fmac_f32_e32 v13, v14, v137
	v_fmac_f32_e32 v125, v13, v141
	v_fmac_f32_e32 v7, v14, v138
	ds_read_b128 v[135:138], v22 offset:144
	v_fmac_f32_e32 v125, v7, v142
	v_fmac_f32_e32 v4, v14, v139
	v_fmac_f32_e32 v125, v4, v143
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v120, v14, v131
	ds_read_b128 v[139:142], v23 offset:144
	v_fmac_f32_e32 v125, v120, v127
	v_fmac_f32_e32 v126, v14, v132
	v_fmac_f32_e32 v125, v126, v128
	v_fmac_f32_e32 v124, v14, v133
	v_fmac_f32_e32 v123, v14, v134
	global_store_dword v48, v112, s[8:9]
	global_store_dword v49, v108, s[8:9]
	global_store_dword v50, v107, s[8:9]
	global_store_dword v51, v104, s[8:9]
	global_store_dword v52, v98, s[8:9]
	global_store_dword v53, v13, s[8:9]
	global_store_dword v54, v7, s[8:9]
	global_store_dword v55, v4, s[8:9]
	global_store_dword v56, v120, s[8:9]
	global_store_dword v57, v126, s[8:9]
	global_store_dword v58, v124, s[8:9]
	v_fmac_f32_e32 v125, v124, v129
	global_store_dword v59, v123, s[8:9]
	v_fmac_f32_e32 v125, v123, v130
	ds_read_b128 v[126:129], v22 offset:160
	ds_read_b128 v[130:133], v22 offset:176
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v118, v14, v135
	v_fmac_f32_e32 v115, v14, v136
	v_fmac_f32_e32 v113, v14, v137
	ds_read_b128 v[134:137], v23 offset:160
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v125, v118, v139
	v_fmac_f32_e32 v125, v115, v140
	v_fmac_f32_e32 v125, v113, v141
	v_fmac_f32_e32 v111, v14, v138
	ds_read_b128 v[138:141], v23 offset:176
	v_fmac_f32_e32 v125, v111, v142
	s_waitcnt lgkmcnt(3)
	v_fmac_f32_e32 v100, v14, v126
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v125, v100, v134
	v_fmac_f32_e32 v101, v14, v127
	v_fmac_f32_e32 v125, v101, v135
	v_fmac_f32_e32 v99, v14, v128
	v_fmac_f32_e32 v125, v99, v136
	v_fmac_f32_e32 v15, v14, v129
	v_fmac_f32_e32 v125, v15, v137
	v_fmac_f32_e32 v10, v14, v130
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v10, v138
	v_fmac_f32_e32 v6, v14, v131
	global_store_dword v60, v118, s[8:9]
	global_store_dword v61, v115, s[8:9]
	global_store_dword v62, v113, s[8:9]
	global_store_dword v63, v111, s[8:9]
	global_store_dword v64, v100, s[8:9]
	global_store_dword v65, v101, s[8:9]
	global_store_dword v66, v99, s[8:9]
	global_store_dword v67, v15, s[8:9]
	global_store_dword v68, v10, s[8:9]
	v_fmac_f32_e32 v125, v6, v139
	v_fmac_f32_e32 v5, v14, v132
	ds_read_b128 v[98:101], v23 offset:192
	ds_read_b128 v[126:129], v23 offset:208
	global_store_dword v69, v6, s[8:9]
	global_store_dword v70, v5, s[8:9]
	v_fmac_f32_e32 v125, v5, v140
	ds_read_b128 v[4:7], v22 offset:192
	v_fmac_f32_e32 v3, v14, v133
	ds_read_b128 v[130:133], v22 offset:208
	v_fmac_f32_e32 v125, v3, v141
	global_store_dword v71, v3, s[8:9]
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v2, v14, v4
	v_fmac_f32_e32 v125, v2, v98
	v_fmac_f32_e32 v122, v14, v5
	v_fmac_f32_e32 v125, v122, v99
	v_fmac_f32_e32 v121, v14, v6
	v_fmac_f32_e32 v125, v121, v100
	v_fmac_f32_e32 v117, v14, v7
	v_fmac_f32_e32 v125, v117, v101
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v119, v14, v130
	v_fmac_f32_e32 v125, v119, v126
	v_fmac_f32_e32 v116, v14, v131
	global_store_dword v72, v2, s[8:9]
	v_fmac_f32_e32 v125, v116, v127
	v_fmac_f32_e32 v114, v14, v132
	v_fmac_f32_e32 v110, v14, v133
	ds_read_b128 v[2:5], v22 offset:224
	global_store_dword v73, v122, s[8:9]
	global_store_dword v74, v121, s[8:9]
	global_store_dword v75, v117, s[8:9]
	global_store_dword v76, v119, s[8:9]
	global_store_dword v77, v116, s[8:9]
	global_store_dword v78, v114, s[8:9]
	v_fmac_f32_e32 v125, v114, v128
	global_store_dword v79, v110, s[8:9]
	v_fmac_f32_e32 v125, v110, v129
	ds_read_b128 v[98:101], v23 offset:224
	ds_read_b128 v[107:110], v22 offset:240
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v16, v14, v2
	ds_read_b128 v[111:114], v23 offset:240
	v_fmac_f32_e32 v106, v14, v3
	s_waitcnt lgkmcnt(2)
	v_fmac_f32_e32 v125, v16, v98
	v_fmac_f32_e32 v125, v106, v99
	v_fmac_f32_e32 v105, v14, v4
	v_fmac_f32_e32 v125, v105, v100
	v_fmac_f32_e32 v103, v14, v5
	v_fmac_f32_e32 v125, v103, v101
	s_waitcnt lgkmcnt(1)
	v_fmac_f32_e32 v102, v14, v107
	s_waitcnt lgkmcnt(0)
	v_fmac_f32_e32 v125, v102, v111
	v_fmac_f32_e32 v97, v14, v108
	v_fmac_f32_e32 v125, v97, v112
	v_fmac_f32_e32 v12, v14, v109
	v_fmac_f32_e32 v125, v12, v113
	v_fmac_f32_e32 v1, v14, v110
	global_store_dword v87, v1, s[8:9]
	v_fmac_f32_e32 v125, v1, v114
	v_mov_b32_e32 v1, 0
	global_store_dword v80, v16, s[8:9]
	global_store_dword v81, v106, s[8:9]
	global_store_dword v82, v105, s[8:9]
	global_store_dword v83, v103, s[8:9]
	global_store_dword v84, v102, s[8:9]
	global_store_dword v85, v97, s[8:9]
	global_store_dword v86, v12, s[8:9]
	ds_write_b32 v21, v125
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB3_21
; %bb.20:                               ;   in Loop: Header=BB3_3 Depth=1
	ds_read2st64_b32 v[1:2], v19 offset1:2
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v1, v1, v2
.LBB3_21:                               ;   in Loop: Header=BB3_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_mul_f32_e32 v2, v1, v1
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	v_fmac_f32_e32 v3, v1, v1
	s_nop 1
	v_add_f32_dpp v2, v3, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v3, 0
	s_nop 0
	v_add_f32_dpp v2, v2, v2 row_half_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_mirror row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:15 row_mask:0xa bank_mask:0xf
	v_add_f32_e32 v2, v2, v3
	v_mov_b32_e32 v3, 0
	s_nop 1
	v_mov_b32_dpp v3, v2 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[2:3]
	s_cbranch_execz .LBB3_23
; %bb.22:                               ;   in Loop: Header=BB3_3 Depth=1
	v_add_f32_e32 v2, v2, v3
	ds_write_b32 v20, v2
.LBB3_23:                               ;   in Loop: Header=BB3_3 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB3_2
; %bb.24:                               ;   in Loop: Header=BB3_3 Depth=1
	v_add_u32_e32 v10, s30, v0
	v_lshlrev_b64 v[2:3], 2, v[10:11]
	v_mov_b32_e32 v5, s15
	v_add_co_u32_e32 v4, vcc, s14, v2
	v_addc_co_u32_e32 v5, vcc, v5, v3, vcc
	global_load_dword v6, v[4:5], off
	global_load_dword v7, v[8:9], off
	s_waitcnt vmcnt(1)
	v_mul_f32_e32 v4, 0xbfb8aa3b, v6
	v_exp_f32_e32 v4, v4
	v_add_f32_e32 v10, 1.0, v4
	v_div_scale_f32 v12, s[10:11], v10, v10, v6
	v_div_scale_f32 v13, vcc, v6, v10, v6
	ds_read_b64 v[4:5], v11 offset:2560
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v5
	v_mov_b32_e32 v5, s43
	v_rcp_f32_e32 v14, v12
	v_fma_f32 v15, -v12, v14, 1.0
	v_fmac_f32_e32 v14, v15, v14
	v_mul_f32_e32 v15, v13, v14
	v_fma_f32 v16, -v12, v15, v13
	v_fmac_f32_e32 v15, v16, v14
	v_fma_f32 v12, -v12, v15, v13
	v_div_fmas_f32 v12, v12, v14, v15
	v_mov_b32_e32 v13, s28
	v_fmac_f32_e32 v13, 0x3c000000, v4
	v_mul_f32_e32 v4, 0x4b800000, v13
	v_cmp_gt_f32_e32 vcc, s33, v13
	v_cndmask_b32_e32 v4, v13, v4, vcc
	v_rsq_f32_e32 v4, v4
	v_mul_f32_e32 v13, 0x45800000, v4
	v_cndmask_b32_e32 v4, v4, v13, vcc
	v_mul_f32_e32 v1, v1, v4
	s_waitcnt vmcnt(0)
	v_mul_f32_e32 v1, v7, v1
	v_div_fixup_f32 v4, v12, v10, v6
	v_mul_f32_e32 v4, v4, v1
	v_add_co_u32_e32 v1, vcc, s42, v2
	v_addc_co_u32_e32 v2, vcc, v5, v3, vcc
	global_store_dword v[1:2], v4, off
	s_branch .LBB3_2
.LBB3_25:
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel baseline_step
		.amdhsa_group_segment_fixed_size 2576
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 360
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 182
		.amdhsa_next_free_sgpr 50
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end3:
	.size	baseline_step, .Lfunc_end3-baseline_step
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 6168
; NumSgprs: 54
; NumVgprs: 182
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 2576 bytes/workgroup (compile time only)
; SGPRBlocks: 6
; VGPRBlocks: 45
; NumSGPRsForWavesPerEU: 54
; NumVGPRsForWavesPerEU: 182
; Occupancy: 1
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.type	__hip_cuid_bcfefe92a066c6ab,@object ; @__hip_cuid_bcfefe92a066c6ab
	.section	.bss,"aw",@nobits
	.globl	__hip_cuid_bcfefe92a066c6ab
__hip_cuid_bcfefe92a066c6ab:
	.byte	0                               ; 0x0
	.size	__hip_cuid_bcfefe92a066c6ab, 1

	.ident	"AMD clang version 18.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-6.3.4 25012 e5bf7e55c91490b07c49d8960fa7983d864936c4)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __hip_cuid_bcfefe92a066c6ab
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .offset:         0
        .size:           112
        .value_kind:     by_value
      - .offset:         112
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         116
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         120
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         124
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         126
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         128
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         130
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         132
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         134
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         152
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         160
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         168
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         176
        .size:           2
        .value_kind:     hidden_grid_dims
    .group_segment_fixed_size: 2576
    .kernarg_segment_align: 8
    .kernarg_segment_size: 368
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           volatile_step
    .private_segment_fixed_size: 8
    .sgpr_count:     62
    .sgpr_spill_count: 0
    .symbol:         volatile_step.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     182
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .offset:         0
        .size:           112
        .value_kind:     by_value
      - .offset:         112
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         116
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         120
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         124
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         126
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         128
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         130
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         132
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         134
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         152
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         160
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         168
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         176
        .size:           2
        .value_kind:     hidden_grid_dims
    .group_segment_fixed_size: 2576
    .kernarg_segment_align: 8
    .kernarg_segment_size: 368
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           live_step
    .private_segment_fixed_size: 0
    .sgpr_count:     54
    .sgpr_spill_count: 0
    .symbol:         live_step.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     182
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .offset:         0
        .size:           112
        .value_kind:     by_value
      - .offset:         112
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         116
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         120
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         124
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         126
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         128
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         130
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         132
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         134
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         152
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         160
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         168
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         176
        .size:           2
        .value_kind:     hidden_grid_dims
    .group_segment_fixed_size: 2576
    .kernarg_segment_align: 8
    .kernarg_segment_size: 368
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           register_step
    .private_segment_fixed_size: 0
    .sgpr_count:     54
    .sgpr_spill_count: 0
    .symbol:         register_step.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     182
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .offset:         0
        .size:           104
        .value_kind:     by_value
      - .offset:         104
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         108
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         112
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         116
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         118
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         120
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         122
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         124
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         126
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         144
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         152
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         160
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         168
        .size:           2
        .value_kind:     hidden_grid_dims
    .group_segment_fixed_size: 2576
    .kernarg_segment_align: 8
    .kernarg_segment_size: 360
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           baseline_step
    .private_segment_fixed_size: 0
    .sgpr_count:     54
    .sgpr_spill_count: 0
    .symbol:         baseline_step.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     182
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx906
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
